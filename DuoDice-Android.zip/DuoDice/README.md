# DuoDice

Application Android native en Kotlin + Jetpack Compose avec rendu 3D OpenGL ES.

## Fonctionnement

- Dé 1 : associe chaque face à une action.
- Dé 2 : associe chaque face à une partie du corps.
- Le dé 2 n'est lançable qu'après le dé 1.
- Résultat final : `Action · Partie du corps`.
- Les réglages sont enregistrés localement sur le téléphone.
- Chaque type de dé conserve ses propres libellés.
- Les dés peuvent aussi être tournés au doigt dans la vue 3D.

## Dés disponibles

Uniquement des formes de dés réelles :

- D4 : tétraèdre
- D6 : cube
- D8 : octaèdre
- D10 : trapézoèdre pentagonal
- D12 : dodécaèdre
- D20 : icosaèdre

## Ouvrir le projet

1. Ouvrir le dossier `DuoDice` dans Android Studio.
2. Laisser Android Studio synchroniser Gradle et télécharger les dépendances.
3. Sélectionner un téléphone Android ou un émulateur.
4. Cliquer sur **Run**.

Pour générer un APK : **Build > Build APK(s)**.

Le projet cible Android API 37, avec minSdk 26.
