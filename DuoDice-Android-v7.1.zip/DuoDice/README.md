# DuoDice v7 — Duo Quest

Application Android hors ligne pour couples.

## Nouveautés v7
- 4 univers : Détente, Fun, Romantique, Extra Hot
- Duo Quest en 5, 10 ou 20 manches
- intensité 1 à 5
- cartes Tentation à conserver
- Roue du destin
- questions « Qui connaît mieux l'autre ? »
- Souvenirs de nous
- Mode Secret 18+ caché derrière 5 pressions sur le titre + PIN
- cartes Kama Sutra dans le Mode Secret
- Mode libre avec D4/D6/D8/D10/D12/D20 personnalisables
- thèmes graphiques et dés colorés selon l'univers
- données stockées localement

Le Mode Secret est volontairement absent de l'écran d'accueil.
