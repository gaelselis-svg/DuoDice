package be.gael.duodice

import kotlin.random.Random

enum class GameMode(
    val title: String,
    val subtitle: String,
    val emoji: String,
    val adultOnly: Boolean = false
) {
    RELAX("Détente", "Calme, massages et petites attentions", "☁"),
    FUN("Fun", "Défis, surprises et fous rires", "★"),
    ROMANTIC("Romantique", "Complicité, compliments et tendresse", "♥"),
    HOT("Extra Hot", "Une ambiance plus sensuelle, réservée aux adultes", "🔥", true),
    SECRET("Secret", "Bonus cachés et Kama Sutra", "◆", true)
}

enum class CardKind {
    CHALLENGE,
    TENTATION,
    DESTINY,
    QUESTION,
    MEMORY,
    SECRET_POSITION
}

data class GameCard(
    val kind: CardKind,
    val title: String,
    val text: String,
    val detail: String = "",
    val canSave: Boolean = false
)

data class SecretPosition(
    val name: String,
    val difficulty: Int
)

object GameEngine {
    private val relaxActions = listOf(
        "Masser", "Caresser", "Effleurer", "Presser doucement", "Réchauffer avec les mains", "Faire des mouvements lents"
    )
    private val relaxZones = listOf("Nuque", "Épaules", "Mains", "Dos", "Mollets", "Pieds")

    private val funActions = listOf(
        "Chatouiller", "Faire un mini massage", "Donner trois petits bisous", "Faire un compliment absurde",
        "Imiter l'autre pendant 10 secondes", "Inventer un mini défi"
    )
    private val funZones = listOf("Bras", "Joues", "Mains", "Épaules", "Dos", "Pieds")

    private val romanticActions = listOf(
        "Embrasser", "Caresser", "Enlacer", "Murmurer un compliment", "Garder le contact", "Faire une petite surprise"
    )
    private val romanticZones = listOf("Lèvres", "Cou", "Visage", "Mains", "Dos", "Taille")

    private val hotActions = listOf(
        "Embrasser lentement", "Caresser", "Mordiller doucement", "Murmurer un désir",
        "Prolonger le contact", "Laisser l'autre choisir le geste"
    )
    private val hotZones = listOf("Lèvres", "Cou", "Torse", "Ventre", "Hanches", "Cuisses")

    private val secretPositions = listOf(
        SecretPosition("Missionnaire", 1),
        SecretPosition("Cuillère", 1),
        SecretPosition("Amazone", 2),
        SecretPosition("Andromaque", 2),
        SecretPosition("Lotus", 2),
        SecretPosition("Levrette", 2),
        SecretPosition("Chaise", 3),
        SecretPosition("Ciseaux", 3),
        SecretPosition("Pont", 4),
        SecretPosition("Union du lotus", 3),
        SecretPosition("Étreinte debout", 4),
        SecretPosition("Position libre choisie à deux", 1)
    )

    private val destinyEvents = listOf(
        "Inversez les rôles pour cette manche.",
        "Double durée : le prochain défi dure deux fois plus longtemps.",
        "Joker : l'un de vous peut modifier un élément du défi.",
        "Choix du partenaire : l'autre personne choisit la zone.",
        "Mystère : fermez les yeux pendant les 10 premières secondes.",
        "Revanche : rejouez votre défi préféré de la partie.",
        "Pause douceur : transformez le prochain défi en version très lente.",
        "Carte libre : inventez ensemble un défi compatible avec votre mode."
    )

    private val genericQuestions = listOf(
        "Quel petit détail chez moi te fait sourire le plus ?",
        "Quel moment récent aimerais-tu revivre avec moi ?",
        "Quelle attention de ma part te fait le plus plaisir ?",
        "Quel endroit aimerais-tu découvrir à deux ?",
        "Qu'est-ce que je fais mieux que je ne le pense ?",
        "Quel souvenir de nous te revient immédiatement en tête ?"
    )

    private val funQuestions = listOf(
        "Quelle est ma manie la plus drôle ?",
        "Quel défi ridicule serais-je le plus susceptible d'accepter ?",
        "Si notre couple était une série, quel serait son titre ?",
        "Quel surnom absurde me conviendrait le mieux ?"
    )

    private val romanticQuestions = listOf(
        "Quand t'es-tu senti(e) particulièrement proche de moi ?",
        "Quel compliment venant de moi t'a marqué ?",
        "Quelle soirée parfaite imagines-tu pour nous deux ?",
        "Quel geste romantique aimerais-tu recevoir plus souvent ?"
    )

    private val hotQuestions = listOf(
        "Quelle ambiance te met le plus à l'aise pour une soirée sensuelle ?",
        "Préfères-tu la spontanéité ou faire durer l'attente ?",
        "Quel type d'attention sensuelle apprécies-tu le plus ?",
        "Y a-t-il une chose que tu aimerais essayer seulement si nous en parlons d'abord ?"
    )

    fun actions(mode: GameMode): List<String> = when (mode) {
        GameMode.RELAX -> relaxActions
        GameMode.FUN -> funActions
        GameMode.ROMANTIC -> romanticActions
        GameMode.HOT -> hotActions
        GameMode.SECRET -> hotActions
    }

    fun zones(mode: GameMode): List<String> = when (mode) {
        GameMode.RELAX -> relaxZones
        GameMode.FUN -> funZones
        GameMode.ROMANTIC -> romanticZones
        GameMode.HOT -> hotZones
        GameMode.SECRET -> hotZones
    }

    fun durationFor(intensity: Int): Int = when (intensity.coerceIn(1, 5)) {
        1 -> 15
        2 -> 20
        3 -> 30
        4 -> 45
        else -> 60
    }

    fun intensityWord(intensity: Int): String = when (intensity.coerceIn(1, 5)) {
        1 -> "très doucement"
        2 -> "doucement"
        3 -> "à votre rythme"
        4 -> "avec plus d'intensité"
        else -> "version intense, seulement si vous êtes tous les deux d'accord"
    }

    fun chooseKind(mode: GameMode, round: Int, memories: List<String>): CardKind {
        if (mode == GameMode.SECRET && round % 3 == 0) return CardKind.SECRET_POSITION
        if (round % 5 == 0) return CardKind.QUESTION
        if (round % 4 == 0) return CardKind.DESTINY
        if (memories.any { it.isNotBlank() } && round % 7 == 0) return CardKind.MEMORY
        return if (Random.nextFloat() < 0.18f) CardKind.TENTATION else CardKind.CHALLENGE
    }

    fun challenge(mode: GameMode, intensity: Int, actionRoll: Int, zoneRoll: Int): GameCard {
        val action = actions(mode)[(actionRoll - 1).coerceIn(0, 5)]
        val zone = zones(mode)[(zoneRoll - 1).coerceIn(0, 5)]
        val seconds = durationFor(intensity)
        return GameCard(
            kind = CardKind.CHALLENGE,
            title = "Défi",
            text = "$action · $zone",
            detail = "$seconds secondes · ${intensityWord(intensity)}"
        )
    }

    fun specialCard(
        kind: CardKind,
        mode: GameMode,
        intensity: Int,
        memories: List<String>
    ): GameCard {
        return when (kind) {
            CardKind.TENTATION -> {
                val temptations = when (mode) {
                    GameMode.RELAX -> listOf(
                        "Garde cette carte : réclame plus tard un massage de 2 minutes.",
                        "Garde cette carte : choisis plus tard une pause calme à deux.",
                        "Garde cette carte : transforme un prochain défi en version détente."
                    )
                    GameMode.FUN -> listOf(
                        "Garde cette carte : impose plus tard un mini défi surprise.",
                        "Garde cette carte : demande une revanche immédiate.",
                        "Garde cette carte : échangez les rôles quand tu le souhaites."
                    )
                    GameMode.ROMANTIC -> listOf(
                        "Garde cette carte : réclame plus tard un long câlin.",
                        "Garde cette carte : demande un compliment très précis.",
                        "Garde cette carte : choisis un prochain défi romantique."
                    )
                    GameMode.HOT, GameMode.SECRET -> listOf(
                        "Garde cette carte : choisis plus tard la durée d'un défi.",
                        "Garde cette carte : transforme un prochain défi en choix du partenaire.",
                        "Garde cette carte : demande un défi sensuel libre, accepté par les deux."
                    )
                }
                GameCard(
                    kind = kind,
                    title = "Carte Tentation",
                    text = temptations.random(),
                    detail = "Tu peux la jouer maintenant ou la conserver.",
                    canSave = true
                )
            }

            CardKind.DESTINY -> GameCard(
                kind = kind,
                title = "Roue du destin",
                text = destinyEvents.random(),
                detail = "Événement spécial de la manche."
            )

            CardKind.QUESTION -> {
                val pool = when (mode) {
                    GameMode.FUN -> genericQuestions + funQuestions
                    GameMode.ROMANTIC -> genericQuestions + romanticQuestions
                    GameMode.HOT, GameMode.SECRET -> genericQuestions + hotQuestions
                    else -> genericQuestions
                }
                GameCard(
                    kind = kind,
                    title = "Qui connaît mieux l'autre ?",
                    text = pool.random(),
                    detail = "Répondez séparément, puis comparez vos réponses."
                )
            }

            CardKind.MEMORY -> {
                val memory = memories.filter { it.isNotBlank() }.randomOrNull() ?: "un de vos meilleurs souvenirs"
                GameCard(
                    kind = kind,
                    title = "Souvenir de nous",
                    text = "Parlez chacun de ce que vous retenez de : « $memory ».",
                    detail = "Pas de bonne réponse : le but est de redécouvrir le souvenir à deux."
                )
            }

            CardKind.SECRET_POSITION -> {
                val maxDifficulty = when (intensity.coerceIn(1, 5)) {
                    1 -> 1
                    2 -> 2
                    3 -> 3
                    else -> 4
                }
                val candidates = secretPositions.filter { it.difficulty <= maxDifficulty }
                val p = candidates.random()
                GameCard(
                    kind = kind,
                    title = "Kama Sutra",
                    text = p.name,
                    detail = "Difficulté ${p.difficulty}/4 · adaptez, changez ou passez si l'un de vous n'est pas à l'aise."
                )
            }

            CardKind.CHALLENGE -> error("Use challenge() for CHALLENGE")
        }
    }
}
