package be.gael.duodice

import kotlin.math.max
import kotlin.random.Random

enum class GameMode(val title:String,val subtitle:String,val emoji:String,val adultOnly:Boolean=false){
    RELAX("Détente","Calme, respiration et petites attentions","☁"),
    FUN("Fun","Défis, jeux et fous rires","★"),
    ROMANTIC("Romantique","Connexion, douceur et complicité","♥"),
    HOT("Extra Hot","Montée progressive, flirt et tension","🔥",true),
    SECRET("Secret","Privé, assumé et beaucoup plus intense","◆",true)
}

enum class CardKind{CHALLENGE,TENTATION,DESTINY,QUESTION,SITUATION,MEMORY,SECRET_POSITION}

data class GameCard(
    val kind:CardKind,
    val title:String,
    val text:String,
    val detail:String="",
    val canSave:Boolean=false,
    val visualKey:Int=-1
)

data class SecretPosition(
    val name:String,
    val difficulty:Int,
    val category:String,
    val description:String,
    val poseId:Int
)

private data class CardTemplate(
    val title:String,
    val text:String,
    val detail:String="",
    val canSave:Boolean=false
)

private data class ChallengeTemplate(
    val title:String,
    val pattern:String,
    val detail:String=""
)

private data class ModeDeck(
    val questions:List<CardTemplate>,
    val situations:List<CardTemplate>,
    val temptations:List<CardTemplate>,
    val challenges:List<ChallengeTemplate>
)

object GameEngine {
    private val relaxActions = listOf("Effleure", "Masse", "Réchauffe", "Presse", "Enlace", "Apaise")
    private val relaxZones = listOf("nuque", "épaules", "mains", "dos", "jambes", "pieds")

    private val funActions = listOf("Mime", "Imite", "Invente", "Devine", "Défie", "Joue")
    private val funZones = listOf("voix", "regard", "gestes", "souvenir", "objet", "imagination")

    private val romanticActions = listOf("Embrasse", "Complimente", "Regarde", "Rapproche", "Remercie", "Surprends")
    private val romanticZones = listOf("lèvres", "cou", "mains", "visage", "dos", "taille")

    private val hotActions = listOf("Embrasse", "Effleure", "Murmure", "Guide", "Ralentis", "Provoque")
    private val hotZones = listOf("lèvres", "cou", "torse", "ventre", "hanches", "cuisses")

    private val destinyCards = listOf(
        CardTemplate("Roue du destin", "La prochaine carte est jouée en silence pendant 30 secondes.", "Vous pouvez ne garder que les gestes, ou seulement les regards selon le mode."),
        CardTemplate("Roue du destin", "Inverser les rôles sur la prochaine carte.", "La personne qui mène devient celle qui reçoit — et inversement."),
        CardTemplate("Roue du destin", "Vous avez droit à une version plus douce ou plus osée de la prochaine carte. Décidez à deux.", "Choisissez ensemble avant de révéler la carte suivante."),
        CardTemplate("Événement", "Ajoutez un élément d'ambiance avant la prochaine manche : musique, lumière ou position plus confortable.", "Une petite mise en scène vaut mieux qu'un défi bâclé."),
        CardTemplate("Wildcard", "La prochaine réponse doit commencer par : “Ce que j'aime vraiment chez toi, c'est…”", "Idéal avant une question, un souvenir ou une tentation."),
        CardTemplate("Twist", "La prochaine carte se joue deux fois : d'abord 20 secondes, puis une deuxième fois en mieux.", "Objectif : corriger, affiner, améliorer."),
        CardTemplate("Twist", "Choisissez maintenant un mot secret. Si l'un de vous le place naturellement avant la fin de la session, vous gagnez une carte bonus.", "Le mot doit rester discret et réalisable."),
        CardTemplate("Pause active", "Avant de continuer, prenez 20 secondes pour vous rapprocher sans parler.", "Respirez, regardez-vous ou touchez-vous selon le mode."),
        CardTemplate("Bonus Duo", "Chacun donne une note sur 10 à la dernière manche. Si l'écart est inférieur ou égal à 2, piochez une carte bonus en fin de session.", "Le but n'est pas de juger, mais d'ajuster."),
        CardTemplate("Choix rapide", "Décidez immédiatement : plus tendre, plus drôle ou plus intense pour la prochaine manche.", "Le jeu s'adapte à votre envie du moment.")
    )

    private val memoryTemplates = listOf(
        "Racontez chacun votre version de : %s. Commencez par le détail que l'autre a probablement oublié.",
        "À propos de : %s, chacun dit d'abord l'émotion principale ressentie à ce moment-là, puis le souvenir précis.",
        "Choisissez dans : %s le moment exact où vous vous êtes sentis “ensemble” comme une vraie équipe.",
        "Pour : %s, l'un raconte la scène, l'autre raconte ce qu'il ou elle ne disait pas à ce moment-là.",
        "Rejouez verbalement : %s. Qui se souvient le mieux du décor, de la musique ou de l'ambiance ?",
        "À partir de : %s, dites chacun ce que vous aimeriez revivre presque à l'identique — et ce que vous changeriez légèrement."
    )

    private val decks = mapOf(
        GameMode.RELAX to ModeDeck(
            questions = listOf(
                CardTemplate("Question douce", "Qu'est-ce qui t'apaise vraiment quand une journée a été trop lourde ?", "Réponse courte, puis un exemple concret."),
                CardTemplate("Question douce", "Quel geste simple te fait te sentir immédiatement pris(e) en compte ?"),
                CardTemplate("Question douce", "Si on inventait un rituel de 5 minutes pour se retrouver le soir, à quoi ressemblerait-il ?"),
                CardTemplate("Question douce", "Dans notre quotidien, quel moment mérite qu'on le ralentisse un peu plus souvent ?"),
                CardTemplate("Question douce", "Quel type de contact te détend le plus : mains, nuque, épaules, dos ou jambes ?"),
                CardTemplate("Question douce", "Qu'est-ce que je fais sans y penser et qui te rassure ?"),
                CardTemplate("Question douce", "De quoi aurais-tu besoin ce soir pour sentir que la pression redescend ?"),
                CardTemplate("Question douce", "Quel environnement te relaxe le plus : lumière tamisée, silence, musique ou conversation légère ?"),
                CardTemplate("Question douce", "Quel petit soin te ferait du bien cette semaine et qu'on repousse toujours ?"),
                CardTemplate("Question douce", "Quand tu as envie de décompresser avec moi, tu préfères quoi : parler, rire, bouger ou juste te poser ?"),
                CardTemplate("À cœur ouvert", "Termine cette phrase : “Je me sens vraiment bien avec toi quand…”"),
                CardTemplate("À cœur ouvert", "Quelle habitude à deux te donne une vraie sensation de stabilité ?"),
                CardTemplate("Question duo", "Quel détail de notre maison ou de notre ambiance aide le plus à te détendre ?"),
                CardTemplate("Question duo", "Quel serait pour toi le mini-programme parfait de 20 minutes pour décompresser à deux ?"),
                CardTemplate("Question duo", "Quelle attention silencieuse a souvent plus de valeur qu'un grand discours ?")
            ),
            situations = listOf(
                CardTemplate("Situation", "Vous avez 3 minutes pour transformer l'endroit où vous êtes en coin détente improvisé.", "Ajoutez un coussin, une lumière, une position confortable ou une musique."),
                CardTemplate("Situation", "Imaginez que le reste de la soirée doit être plus doux que le début. Que changez-vous maintenant ?"),
                CardTemplate("Situation", "L'un de vous vient de rentrer d'une journée épuisante. L'autre a une minute pour créer un sas de décompression."),
                CardTemplate("Situation", "Vous n'avez droit qu'à des gestes lents pendant la prochaine minute. Décidez ensemble lesquels."),
                CardTemplate("Situation", "Choisissez une partie du corps qui a travaillé aujourd'hui. La prochaine minute sert uniquement à en prendre soin."),
                CardTemplate("Situation", "Sans parler fort, mettez-vous d'accord sur la manière la plus simple de vous rapprocher maintenant."),
                CardTemplate("Situation", "Créez un mini rituel : un mot, un geste et une respiration commune à refaire plus tard dans la semaine."),
                CardTemplate("Situation", "Supposons que vous ne disposiez que de 10 minutes pour faire redescendre la tension. Que gardez-vous ?"),
                CardTemplate("Situation", "Vous devez chacun choisir une seule chose qui vous ferait du bien tout de suite. Comparez puis faites le point commun.")
            ),
            temptations = listOf(
                CardTemplate("Tentation", "Gardez cette carte : avant de dormir cette semaine, accordez-vous 2 minutes de contact sans téléphone.", "Le but n'est pas la performance, juste la présence.", true),
                CardTemplate("Tentation", "Gardez cette carte : l'un prépare une vraie pause détente de 10 minutes pour l'autre dans les 3 prochains jours.", true),
                CardTemplate("Tentation", "Gardez cette carte : envoyez demain un message qui n'a qu'un but — faire souffler l'autre.", true),
                CardTemplate("Tentation", "Gardez cette carte : choisissez un soir sans écran pour créer votre mini rituel détente.", true),
                CardTemplate("Tentation", "Gardez cette carte : promettez-vous un massage des mains, des épaules ou des pieds avant la fin de semaine.", true),
                CardTemplate("Tentation", "Gardez cette carte : organisez un retour au calme ensemble après une journée chargée.", true)
            ),
            challenges = listOf(
                ChallengeTemplate("Défi détente", "Pendant {duration} secondes, {action} lentement la zone {zone} sans changer de rythme.", "Cherchez le rythme le plus agréable, pas le plus spectaculaire."),
                ChallengeTemplate("Défi détente", "Choisissez un rythme respiratoire commun, puis {action} la zone {zone} pendant {duration} secondes.", "Si le rythme ne convient pas, ralentissez encore."),
                ChallengeTemplate("Défi détente", "Commencez par 5 secondes d'immobilité, puis {action} la zone {zone} pendant {duration} secondes.", "L'immobilité au départ rend le geste plus perceptible."),
                ChallengeTemplate("Défi détente", "Pendant {duration} secondes, une personne guide uniquement avec les mots “plus lent”, “pareil” ou “stop” pendant que l'autre {action} la zone {zone}.", "Simple, clair, confortable."),
                ChallengeTemplate("Défi détente", "Utilisez seulement vos mains : {action} la zone {zone} pendant {duration} secondes puis inversez les rôles.", "Même durée pour les deux si vous le souhaitez."),
                ChallengeTemplate("Défi détente", "Votre mission : faire baisser la tension dans la zone {zone}. {action} pendant {duration} secondes puis demandez un retour honnête.", "Le retour compte autant que le geste.")
            )
        ),
        GameMode.FUN to ModeDeck(
            questions = listOf(
                CardTemplate("Question fun", "Quel faux titre de film décrirait parfaitement notre dernière semaine ?"),
                CardTemplate("Question fun", "Si notre couple avait une mascotte absurde, ce serait quoi et pourquoi ?"),
                CardTemplate("Question fun", "Quelle petite manie chez moi t'amuse plus qu'elle ne t'agace ?"),
                CardTemplate("Question fun", "Quel objet de la pièce pourrait devenir le héros ridicule d'une pub ?"),
                CardTemplate("Question fun", "Quel talent complètement inutile mais spectaculaire devrais-je apprendre ?"),
                CardTemplate("Question fun", "Si on ouvrait un resto catastrophique, quel serait son nom ?"),
                CardTemplate("Question fun", "Quel surnom aurait ma version super-héros à très petit budget ?"),
                CardTemplate("Question fun", "Quel concours étrange aurions-nous une vraie chance de gagner ?"),
                CardTemplate("Question fun", "Quelle phrase de tous les jours pourrait devenir notre slogan officiel ?"),
                CardTemplate("Question fun", "Quelle scène banale de notre vie ferait un bon sketch si on l'exagérait ?"),
                CardTemplate("Devine ma réponse", "Choisissez chacun mentalement le pire cadeau drôle que l'autre pourrait vous offrir. Devinez puis révélez.", "Le plus absurde gagne."),
                CardTemplate("Devine ma réponse", "À ton avis, quel animal me représenterait le mieux un lundi matin ?"),
                CardTemplate("Question fun", "Quel bruit ou imitation te fait rire presque à tous les coups ?"),
                CardTemplate("Question fun", "Si notre journée devait être racontée par un commentateur sportif, quel serait le meilleur moment ?"),
                CardTemplate("Question fun", "Quel serait le nom de notre groupe si on devait monter sur scène dans 10 minutes ?")
            ),
            situations = listOf(
                CardTemplate("Situation", "Vous avez 30 secondes pour inventer une publicité ridicule pour un objet à portée de main."),
                CardTemplate("Situation", "L'un raconte une fausse histoire très sérieuse pendant 20 secondes. L'autre doit deviner le premier détail inventé."),
                CardTemplate("Situation", "Choisissez une émotion exagérée. Rejouez une scène banale du quotidien comme si elle était dramatique à l'extrême."),
                CardTemplate("Situation", "Créez en duo le pire concept d'émission télé possible. Donnez-lui un titre et un slogan."),
                CardTemplate("Situation", "Transformez une corvée domestique en discipline olympique. Décrivez l'épreuve et le commentaire du public."),
                CardTemplate("Situation", "Faites un mini concours : lequel de vous sait faire rire l'autre en moins de 20 secondes ?"),
                CardTemplate("Situation", "Vous devez vendre votre partenaire comme s'il s'agissait d'un produit de luxe… avec au moins un défaut drôle assumé."),
                CardTemplate("Situation", "Inventez un langage secret à deux : un mot, un geste et une traduction totalement inutile."),
                CardTemplate("Situation", "En 1 minute, créez le pire thème de soirée possible et expliquez pourquoi personne ne devrait venir.")
            ),
            temptations = listOf(
                CardTemplate("Tentation", "Gardez cette carte : cette semaine, l'un devra envoyer à l'autre un défi fun totalement improvisé par message.", true),
                CardTemplate("Tentation", "Gardez cette carte : organisez une mini compétition ridicule à la maison avec score officiel.", true),
                CardTemplate("Tentation", "Gardez cette carte : choisissez un code secret absurde à utiliser en public sans rire.", true),
                CardTemplate("Tentation", "Gardez cette carte : prenez une photo volontairement ratée mais mémorable avant la fin de semaine.", true),
                CardTemplate("Tentation", "Gardez cette carte : inventez un trophée maison pour la plus grande bêtise du mois.", true),
                CardTemplate("Tentation", "Gardez cette carte : créez un surnom de duo à utiliser pendant 24 heures.", true)
            ),
            challenges = listOf(
                ChallengeTemplate("Défi fun", "Pendant {duration} secondes, {action} quelque chose lié à la {zone} pendant que l'autre essaie de deviner.", "Plus c'est assumé, mieux c'est."),
                ChallengeTemplate("Défi fun", "Lance-toi : {action} en utilisant la {zone} comme thème principal pendant {duration} secondes.", "Exemple : voix = imitation, gestes = mime."),
                ChallengeTemplate("Défi fun", "Mission chrono : {action} autour du thème {zone} pendant {duration} secondes sans répéter deux fois la même idée.", "Improvisation pure."),
                ChallengeTemplate("Défi fun", "Choisis une mini mise en scène et {action} autour de la {zone} pendant {duration} secondes. Puis inversez.", "L'autre note la créativité, pas la perfection."),
                ChallengeTemplate("Défi fun", "Défi duo : l'un commence à {action}, l'autre doit suivre immédiatement avec une idée liée à la {zone}. Tenez {duration} secondes.", "Objectif : ne pas casser le rythme."),
                ChallengeTemplate("Défi fun", "Vous avez {duration} secondes pour {action} avec le thème {zone}, mais sans prononcer le mot principal.", "Silence partiel autorisé.")
            )
        ),
        GameMode.ROMANTIC to ModeDeck(
            questions = listOf(
                CardTemplate("À cœur ouvert", "Quel moment récent t'a donné la sensation qu'on formait vraiment une équipe ?"),
                CardTemplate("À cœur ouvert", "Quel geste tendre aimerais-tu recevoir plus souvent, même très simple ?"),
                CardTemplate("À cœur ouvert", "Quelle qualité chez moi te rassure le plus dans notre relation ?"),
                CardTemplate("À cœur ouvert", "Quel souvenir de nos débuts te revient avec le plus de netteté ?"),
                CardTemplate("À cœur ouvert", "Qu'est-ce qui te fait te sentir “chez toi” avec moi ?"),
                CardTemplate("À cœur ouvert", "Quel projet de couple te fait vraiment envie, même s'il est modeste ?"),
                CardTemplate("À cœur ouvert", "Quelle petite attention vaut plus pour toi qu'un gros cadeau ?"),
                CardTemplate("À cœur ouvert", "À quel moment t'es-tu senti(e) profondément compris(e) par moi ?"),
                CardTemplate("À cœur ouvert", "Quelle chose chez moi t'est devenue plus attirante avec le temps ?"),
                CardTemplate("À cœur ouvert", "Quelle phrase ou quel compliment aimerais-tu entendre plus souvent ?"),
                CardTemplate("Devine ma réponse", "Devine d'abord : quel souvenir banal j'aimerais revivre avec toi juste pour l'ambiance ?"),
                CardTemplate("Devine ma réponse", "Quel rendez-vous simple me ferait probablement le plus plaisir cette semaine ?"),
                CardTemplate("Question duo", "Quelle habitude à deux devons-nous protéger absolument ?"),
                CardTemplate("Question duo", "Quelle petite promesse réaliste renforcerait notre lien ce mois-ci ?"),
                CardTemplate("Question duo", "Si on devait préserver une seule qualité de notre relation quoi qu'il arrive, laquelle serait-ce ?")
            ),
            situations = listOf(
                CardTemplate("Situation", "Vous avez 2 minutes pour recréer l'ambiance d'un petit rendez-vous, là où vous êtes, avec ce que vous avez."),
                CardTemplate("Situation", "L'un de vous organise un mini moment romantique de 60 secondes. L'autre n'a pas le droit de critiquer, seulement d'entrer dans le jeu."),
                CardTemplate("Situation", "Imaginez que vous vous revoyez après une longue absence. Comment se passe la première minute ?"),
                CardTemplate("Situation", "Chacun choisit discrètement un souvenir heureux à deux. Tentez de choisir le même sans vous consulter."),
                CardTemplate("Situation", "Vous devez chacun dire une chose que vous admirez chez l'autre, mais sous forme de scène précise, pas de mot vague."),
                CardTemplate("Situation", "Préparez ensemble le plus petit rendez-vous possible pour cette semaine : lieu, durée et intention."),
                CardTemplate("Situation", "Vous ne pouvez utiliser que des mots doux ou utiles pendant la prochaine minute. Commencez maintenant."),
                CardTemplate("Situation", "Faites comme si vous écriviez la quatrième de couverture de votre histoire : quelle phrase y figurerait ?"),
                CardTemplate("Situation", "Offrez-vous 30 secondes de regard et 30 secondes de mots choisis. L'ordre est libre.")
            ),
            temptations = listOf(
                CardTemplate("Tentation", "Gardez cette carte : l'un prépare dans les 7 jours un mini rendez-vous de moins d'une heure, simple mais pensé.", true),
                CardTemplate("Tentation", "Gardez cette carte : écrivez ou envoyez demain un message qui rappelle un vrai souvenir heureux.", true),
                CardTemplate("Tentation", "Gardez cette carte : promettez-vous un moment sans distraction pour vous raconter votre journée en vrai.", true),
                CardTemplate("Tentation", "Gardez cette carte : avant la fin de semaine, faites une attention silencieuse que l'autre remarquera sans explication.", true),
                CardTemplate("Tentation", "Gardez cette carte : rejouez un petit rituel du début de votre relation, même en version courte.", true),
                CardTemplate("Tentation", "Gardez cette carte : laissez quelque part un mot simple que l'autre découvrira plus tard.", true)
            ),
            challenges = listOf(
                ChallengeTemplate("Défi romantique", "Pendant {duration} secondes, {action} autour de la zone {zone} avec une intention claire : rassurer, rapprocher ou remercier.", "Choisissez une seule intention et tenez-la jusqu'au bout."),
                ChallengeTemplate("Défi romantique", "Pendant {duration} secondes, {action} la zone {zone} puis terminez par un compliment précis.", "Précis vaut mieux que grandiose."),
                ChallengeTemplate("Défi romantique", "Votre mission : {action} près de la zone {zone} pendant {duration} secondes en gardant le contact visuel quand c'est possible.", "Le regard change beaucoup la carte."),
                ChallengeTemplate("Défi romantique", "Commencez par dire ce que vous aimez le plus en ce moment chez l'autre, puis {action} la zone {zone} pendant {duration} secondes.", "Le mot et le geste se répondent."),
                ChallengeTemplate("Défi romantique", "Une personne reçoit. L'autre {action} la zone {zone} pendant {duration} secondes, puis demande : “Tu préfères pareil, plus doux ou différent ?”", "L'ajustement fait partie du défi."),
                ChallengeTemplate("Défi romantique", "Pendant {duration} secondes, {action} la zone {zone} comme si vous vouliez faire passer un message sans parler.", "L'autre dit ensuite quel message a été perçu.")
            )
        ),
        GameMode.HOT to ModeDeck(
            questions = listOf(
                CardTemplate("Préférence", "Qu'est-ce qui te fait monter le désir plus sûrement : l'attente, les mots, le regard, le rythme ou la surprise ?"),
                CardTemplate("Préférence", "Quel type de teasing te plaît le plus quand il reste élégant mais assumé ?"),
                CardTemplate("Préférence", "Tu préfères généralement quand l'autre guide franchement ou quand il/elle te laisse prendre l'initiative ?"),
                CardTemplate("Préférence", "Qu'est-ce qui fait vraiment la différence entre “agréable” et “très excitant” pour toi ?"),
                CardTemplate("Préférence", "Quel rythme te plaît le plus au début : lent, variable ou direct ?"),
                CardTemplate("Préférence", "Quel geste sensuel gagne le plus à être ralenti volontairement ?"),
                CardTemplate("Préférence", "Quelle ambiance rend les choses immédiatement plus intenses pour toi ?"),
                CardTemplate("Préférence", "Qu'est-ce qui te met le plus en confiance pour aller plus loin : parole, regard, humour ou toucher ?"),
                CardTemplate("Devine ma réponse", "Devine ce qui me fait le plus d'effet entre : anticipation, mots doux, contact prolongé, regard tenu."),
                CardTemplate("Devine ma réponse", "À ton avis, quel type d'initiative me plaît le plus quand elle est bien amenée ?"),
                CardTemplate("Préférence", "Y a-t-il une chose simple que tu aimerais qu'on fasse plus souvent, mais mieux ?"),
                CardTemplate("Préférence", "Quelle différence fais-tu entre une carte “chaude” et une carte “trop rapide” ?"),
                CardTemplate("Préférence", "Quand la tension monte, quel détail ne doit surtout pas être négligé ?"),
                CardTemplate("Préférence", "Quelle est selon toi la bonne manière de faire durer le plaisir dans une séance courte ?"),
                CardTemplate("Préférence", "Quel mot, phrase ou ton de voix peut suffire à faire monter la température ?")
            ),
            situations = listOf(
                CardTemplate("Situation", "Vous n'avez droit qu'à des gestes lents pendant la prochaine minute. Tout le reste doit attendre."),
                CardTemplate("Situation", "L'un prend l'initiative de créer l'attente. L'autre ne peut répondre qu'avec “encore”, “pareil” ou “stop”."),
                CardTemplate("Situation", "Imaginez que vous avez seulement 90 secondes pour faire monter la tension sans vous précipiter. Que gardez-vous ?"),
                CardTemplate("Situation", "Chacun choisit en secret une ambiance : douce, provocante ou très tendue. Révélez puis prenez le point commun."),
                CardTemplate("Situation", "Vous devez faire monter la température sans passer trop vite à l'étape suivante : que faites-vous rester ?"),
                CardTemplate("Situation", "L'un de vous guide la prochaine minute comme une montée très progressive. L'autre donne un retour minimal mais honnête."),
                CardTemplate("Situation", "Vous rejouez une action appréciée plus tôt dans la session, mais avec deux fois plus de lenteur."),
                CardTemplate("Situation", "Choisissez une zone autorisée et restez fidèles à celle-ci pendant toute la prochaine carte."),
                CardTemplate("Situation", "Décidez maintenant si la prochaine carte doit être plus frustrante, plus tendre ou plus directe.")
            ),
            temptations = listOf(
                CardTemplate("Tentation", "Gardez cette carte : avant 72 heures, rejouez un moment de teasing qui dure au moins 2 minutes avant d'aller plus loin.", true),
                CardTemplate("Tentation", "Gardez cette carte : préparez une ambiance volontairement sensuelle pour plus tard cette semaine.", true),
                CardTemplate("Tentation", "Gardez cette carte : envoyez un message qui ouvre une vraie anticipation pour ce soir ou un autre moment choisi.", true),
                CardTemplate("Tentation", "Gardez cette carte : choisissez ensemble une chose simple à ralentir volontairement lors de votre prochain moment chaud.", true),
                CardTemplate("Tentation", "Gardez cette carte : planifiez une séquence “regard, mots, contact” à rejouer bientôt.", true),
                CardTemplate("Tentation", "Gardez cette carte : faites une liste à deux de trois choses qui vous plaisent vraiment quand le rythme reste maîtrisé.", true)
            ),
            challenges = listOf(
                ChallengeTemplate("Défi hot", "Pendant {duration} secondes, {action} la zone {zone} avec un rythme volontairement plus lent que naturel.", "Si c'est trop rapide, recommencez plus lentement."),
                ChallengeTemplate("Défi hot", "Une personne reçoit et ne peut guider qu'avec trois mots : plus lent, pareil, stop. L'autre {action} la zone {zone} pendant {duration} secondes.", "La contrainte rend la carte plus nette."),
                ChallengeTemplate("Défi hot", "Faites monter l'attente : commencez 5 secondes sans bouger, puis {action} la zone {zone} pendant {duration} secondes.", "Le début immobile compte."),
                ChallengeTemplate("Défi hot", "Votre objectif n'est pas la vitesse mais la tension. {action} autour de la zone {zone} pendant {duration} secondes en gardant l'attention de l'autre.", "Cherchez la tension, pas l'accumulation."),
                ChallengeTemplate("Défi hot", "Pendant {duration} secondes, {action} la zone {zone}. À mi-parcours, l'autre doit choisir : plus doux, pareil ou plus osé.", "Un seul ajustement autorisé."),
                ChallengeTemplate("Défi hot", "Commencez par un murmure ou une phrase courte, puis {action} la zone {zone} pendant {duration} secondes.", "Le verbal change la texture de la carte."),
                ChallengeTemplate("Défi hot", "Défi de contrôle : {action} la zone {zone} pendant {duration} secondes sans changer de zone ni casser le rythme.", "La frustration maîtrisée fait partie du jeu."),
                ChallengeTemplate("Défi hot", "Pendant {duration} secondes, {action} la zone {zone} comme si vous faisiez durer le meilleur moment au lieu d'accélérer.", "Cherchez la qualité de présence.")
            )
        ),
        GameMode.SECRET to ModeDeck(
            questions = listOf(
                CardTemplate("Secret", "Parmi les dynamiques suivantes, laquelle t'attire le plus quand elle est pleinement consentie : attente, guidage, abandon, scénario, intensité sensorielle ?", "Réponse honnête et nuancée."),
                CardTemplate("Secret", "Qu'est-ce qui, pour toi, transforme une expérience très chaude en expérience vraiment mémorable ?"),
                CardTemplate("Secret", "Quel fantasme ou type de jeu mérite surtout d'être mieux raconté ou mieux préparé plutôt que juste tenté ?"),
                CardTemplate("Secret", "Quand tu acceptes de te laisser guider, de quoi as-tu besoin pour te sentir parfaitement en confiance ?"),
                CardTemplate("Secret", "Quand tu prends le contrôle, qu'est-ce qui te plaît le plus : choisir le rythme, choisir la règle ou choisir le moment ?"),
                CardTemplate("Secret", "Parmi les jeux d'attente, lequel t'excite le plus : retarder, interrompre, recommencer ou faire durer ?"),
                CardTemplate("Secret", "Quelle catégorie t'intrigue le plus en ce moment : positions, scénarios, paroles, contraste doux/fort, variation de tempo ?"),
                CardTemplate("Secret", "Quelle limite ou réserve aimerais-tu mieux expliquer pour qu'elle soit mieux comprise ?"),
                CardTemplate("Secret", "Qu'est-ce qui te donne le plus envie de rejouer une expérience réussie ?"),
                CardTemplate("Devine ma réponse", "Choisis mentalement ce que tu préférerais pour une prochaine session : plus de tension, plus de guidage, plus de variété ou plus de lenteur. L'autre doit deviner."),
                CardTemplate("Secret", "Quelle ambiance rend le mode Secret vraiment différent d'un simple mode hot pour toi ?"),
                CardTemplate("Secret", "Quelle position ou famille de positions te donne le plus envie d'explorer davantage ?"),
                CardTemplate("Secret", "Préférerais-tu une session courte mais très dense, ou longue et progressive ? Pourquoi ?"),
                CardTemplate("Secret", "Quel type de scénario te semble le plus excitant s'il reste réaliste et bien encadré ?"),
                CardTemplate("Secret", "Y a-t-il une chose simple mais très efficace que tu aimerais rendre plus régulière dans nos moments adultes ?")
            ),
            situations = listOf(
                CardTemplate("Scénario secret", "L'un mène la prochaine minute. L'autre peut seulement répondre par “oui”, “moins”, “pareil” ou “stop”."),
                CardTemplate("Scénario secret", "Choisissez une règle courte pour les 2 prochaines manches : même zone, même rythme, silence, regard, ou reprise d'une carte favorite."),
                CardTemplate("Scénario secret", "Imaginez que vous construisez un moment très intense sans précipitation. Quelle sera votre première vraie règle ?"),
                CardTemplate("Scénario secret", "Chacun choisit une envie et une limite du moment. Le jeu consiste à rester au plus près de l'intersection des deux."),
                CardTemplate("Scénario secret", "Vous devez rendre la prochaine carte plus forte non pas en en faisant plus, mais en la cadrant mieux."),
                CardTemplate("Scénario secret", "Choisissez maintenant : dominant doux, abandon consenti, tension sensorielle ou exploration d'une position. Le reste de la carte doit suivre cette intention."),
                CardTemplate("Scénario secret", "Refaites une carte appréciée, mais avec une contrainte supplémentaire : lenteur, silence, yeux ouverts ou règle de contrôle."),
                CardTemplate("Scénario secret", "L'un orchestre. L'autre a le droit de modifier une seule chose à mi-parcours. Pas plus."),
                CardTemplate("Scénario secret", "Avant d'aller plus loin, prenez 20 secondes pour décider ce qui rendra la prochaine carte vraiment excitante pour les deux.")
            ),
            temptations = listOf(
                CardTemplate("Carte Tentation", "Gardez cette carte : planifiez une vraie session Secret avec ambiance, temps prévu et au moins une règle choisie à l'avance.", "Plus la préparation est claire, plus l'intensité peut monter proprement.", true),
                CardTemplate("Carte Tentation", "Gardez cette carte : créez votre top 3 des choses qui font le plus monter la tension chez vous deux.", true),
                CardTemplate("Carte Tentation", "Gardez cette carte : choisissez une position favorite et préparez sa version plus confortable et sa version plus ambitieuse.", true),
                CardTemplate("Carte Tentation", "Gardez cette carte : rejouez bientôt une séquence basée sur l'attente et le contrôle du rythme.", true),
                CardTemplate("Carte Tentation", "Gardez cette carte : discutez puis testez une règle de guidage qui vous plaît aux deux.", true),
                CardTemplate("Carte Tentation", "Gardez cette carte : préparez un scénario court mais clair à explorer lors d'un prochain moment privé.", true)
            ),
            challenges = listOf(
                ChallengeTemplate("Défi secret", "Pendant {duration} secondes, {action} la zone {zone} selon une règle définie avant de commencer : plus lent, pareil, stop.", "Précision, écoute et intensité."),
                ChallengeTemplate("Défi secret", "Une personne mène. L'autre se laisse guider pendant {duration} secondes pendant que la zone {zone} reste le centre du jeu et que le rythme reste maîtrisé.", "Toujours modifiable, jamais imposé."),
                ChallengeTemplate("Défi secret", "Créez de la frustration choisie : {action} autour de la zone {zone} pendant {duration} secondes sans changer de zone.", "Le cadre fait la force de la carte."),
                ChallengeTemplate("Défi secret", "Pendant {duration} secondes, {action} la zone {zone} avec une seule montée possible d'intensité. L'autre décide quand elle a lieu.", "Une seule montée, pas plus."),
                ChallengeTemplate("Défi secret", "Défi de contrôle : commencez 5 secondes immobiles, puis {action} la zone {zone} pendant {duration} secondes en gardant la même intention du début à la fin.", "Rester dans l'intention choisie."),
                ChallengeTemplate("Défi secret", "Utilisez un mot-clé choisi ensemble pour ajuster la carte. Pendant {duration} secondes, {action} la zone {zone} jusqu'à entendre ce mot ou le terminer naturellement.", "Le mot-clé clarifie et sécurise."),
                ChallengeTemplate("Défi secret", "Pendant {duration} secondes, l'un guide par le regard et quelques mots, l'autre exécute en se concentrant sur la zone {zone}.", "Le regard devient une règle."),
                ChallengeTemplate("Défi secret", "Version très hot : {action} la zone {zone} pendant {duration} secondes puis interrompez-vous 5 secondes avant de reprendre une dernière fois.", "L'interruption fait partie du jeu."),
                ChallengeTemplate("Défi secret", "Défi de maintien : {action} la zone {zone} pendant {duration} secondes sans chercher à “aller plus vite”.", "Le contrôle vaut plus que l'accélération."),
                ChallengeTemplate("Défi secret", "Pendant {duration} secondes, une personne reçoit et décide du tempo en temps réel pendant que l'autre {action} la zone {zone}.", "Une carte directe, claire et intense.")
            )
        )
    )

    private val positions = listOf(
        SecretPosition("Face-à-face cocon", 1, "Allongée face à face", "Mise en place : allongez-vous face à face, jambes souples, bassins proches. Atout : proximité maximale et rythme facile à ajuster. Confort : glissez un coussin sous le bassin si besoin.", 0),
        SecretPosition("Cuillère serrée", 1, "Côté", "Mise en place : les deux partenaires sur le côté, l'un derrière l'autre. Atout : très douce, idéale pour le rythme lent. Confort : gardez les genoux légèrement fléchis.", 1),
        SecretPosition("Assise enlacée", 2, "Assise", "Mise en place : une personne assise, l'autre se place face à elle en l'enlaçant. Atout : regard, contrôle facile, proximité. Confort : dossier, canapé ou tête de lit bienvenus.", 2),
        SecretPosition("Bord du lit complice", 2, "Avec appui", "Mise en place : une personne s'installe au bord du lit, l'autre reste debout ou semi-agenouillée. Atout : bon accès et transitions simples. Confort : gardez les pieds bien stables.", 3),
        SecretPosition("Chevauchement tendre", 2, "Dessus", "Mise en place : une personne allongée, l'autre au-dessus en gardant les mains en appui. Atout : guidage intuitif du rythme. Confort : ne cherchez pas tout de suite l'amplitude maximale.", 4),
        SecretPosition("Miroir assis", 2, "Assise", "Mise en place : asseyez-vous face à face, jambes entremêlées ou autour de l'autre. Atout : idéal pour les mots et le regard. Confort : ajoutez un coussin sous les fesses si nécessaire.", 5),
        SecretPosition("Côté relevé", 2, "Côté", "Mise en place : en position latérale, la personne devant relève légèrement la jambe supérieure. Atout : accès simple et sensation enveloppante. Confort : un coussin entre les genoux peut aider.", 6),
        SecretPosition("Mur patient", 3, "Debout", "Mise en place : une personne prend appui contre un mur, l'autre se place face à elle. Atout : très visuelle et intense. Confort : gardez au moins un point d'appui solide pour chacun.", 7),
        SecretPosition("Chaise confidente", 3, "Avec mobilier", "Mise en place : une personne s'assoit au fond d'une chaise stable, l'autre se place face à elle. Atout : bonne proximité et hauteur pratique. Confort : chaise sans roulettes uniquement.", 8),
        SecretPosition("Pont des cuisses", 3, "Dessus", "Mise en place : la personne du dessous replie légèrement les jambes pour créer un bon appui. Atout : permet un angle différent sans complexité extrême. Confort : coussin sous le bassin conseillé.", 9),
        SecretPosition("Genoux liés", 3, "À genoux", "Mise en place : les deux à genoux face à face ou l'un légèrement décalé. Atout : très bon pour le contrôle du tempo. Confort : couverture ou tapis épais recommandé.", 10),
        SecretPosition("Angle du canapé", 2, "Avec appui", "Mise en place : utilisez un coin de canapé pour soutenir le dos ou le bassin. Atout : aide à garder la position sans forcer. Confort : cherchez l'angle avant de commencer.", 11),
        SecretPosition("Debout enlacé", 3, "Debout", "Mise en place : face à face, corps proches, poids bien réparti. Atout : excellent pour une montée lente et visuelle. Confort : si la différence de taille gêne, changez l'angle ou revenez à un support.", 12),
        SecretPosition("Travers du lit", 3, "Avec appui", "Mise en place : une personne allongée en travers du lit, l'autre garde un appui au sol ou sur le lit. Atout : angle différent et bonne stabilité. Confort : vérifiez la hauteur avant de commencer.", 13),
        SecretPosition("Accolade profonde", 4, "Dessus", "Mise en place : une personne sur le dos, l'autre au-dessus très proche, tronc collé au tronc. Atout : intensité et proximité. Confort : travaillez par petites amplitudes.", 14),
        SecretPosition("Écharpe latérale", 4, "Côté", "Mise en place : à partir d'une position sur le côté, une jambe vient se placer plus haut autour de l'autre. Atout : change fortement l'angle. Confort : ne forcez jamais la hanche.", 15),
        SecretPosition("Appui tête de lit", 4, "Avec appui", "Mise en place : utilisez la tête de lit ou le mur derrière pour stabiliser le haut du corps. Atout : favorise un rythme régulier. Confort : gardez la nuque libre et les épaules souples.", 16),
        SecretPosition("Carré de contrôle", 4, "À genoux", "Mise en place : une personne à genoux, l'autre en appui devant elle, avec angles bien calés. Atout : sensation de guidage fort. Confort : surface douce indispensable.", 17),
        SecretPosition("Portique", 4, "Debout avec appui", "Mise en place : un partenaire prend appui sur un meuble stable ou un mur, l'autre se place derrière ou face à lui selon la variante. Atout : intense et visuelle. Confort : stabilité d'abord.", 18),
        SecretPosition("Spirale assise", 4, "Assise avancée", "Mise en place : à partir d'une assise face à face, le buste pivote légèrement. Atout : sensation différente et tension intéressante. Confort : gardez le bassin soutenu.", 19),
        SecretPosition("Pont suspendu", 5, "Avancée", "Mise en place : une personne garde le bassin haut avec aide d'appui ou de coussins pendant que l'autre ajuste sa place. Atout : très intense et physique. Confort : à réserver aux jours où l'énergie suit.", 20),
        SecretPosition("Debout porté assisté", 5, "Avancée", "Mise en place : ne tentez que si la force, la stabilité et l'envie sont là ; utilisez un mur pour sécuriser. Atout : spectaculaire et courte. Confort : quelques secondes peuvent suffire.", 21),
        SecretPosition("Croisé des hanches", 5, "Avancée", "Mise en place : à partir d'une base connue, croisez davantage les lignes de jambes pour changer l'angle. Atout : sensations nouvelles. Confort : exige de l'écoute et peu de précipitation.", 22),
        SecretPosition("Tête de lit verticale", 5, "Avancée avec appui", "Mise en place : utilisez franchement la tête de lit ou le mur pour stabiliser le haut du corps et réduire l'effort. Atout : intensité très directe. Confort : gardez une sortie facile de la position.", 23)
    )

    fun actions(mode:GameMode)=when(mode){
        GameMode.RELAX -> relaxActions
        GameMode.FUN -> funActions
        GameMode.ROMANTIC -> romanticActions
        GameMode.HOT, GameMode.SECRET -> hotActions
    }

    fun zones(mode:GameMode)=when(mode){
        GameMode.RELAX -> relaxZones
        GameMode.FUN -> funZones
        GameMode.ROMANTIC -> romanticZones
        GameMode.HOT, GameMode.SECRET -> hotZones
    }

    fun secretPositions():List<SecretPosition> = positions

    fun intensityWord(intensity:Int):String = when(intensity.coerceIn(1,5)){
        1 -> "très doux"
        2 -> "doux"
        3 -> "équilibré"
        4 -> "intense"
        else -> "très intense"
    }

    private fun <T> intensitySlice(items: List<T>, intensity: Int, minSize: Int = 6): List<T> {
        if (items.isEmpty()) return items
        val fraction = when (intensity.coerceIn(1, 5)) {
            1 -> 0.35
            2 -> 0.55
            3 -> 0.75
            4 -> 0.90
            else -> 1.0
        }
        val cap = max((items.size * fraction).toInt(), minOf(minSize, items.size))
        return items.take(cap)
    }

    private fun deck(mode: GameMode): ModeDeck = decks.getValue(mode)

    fun chooseKind(mode:GameMode,round:Int,memories:List<String>):CardKind{
        val hasMemories = memories.any { it.isNotBlank() }
        if (mode == GameMode.SECRET && round % 4 == 0) return CardKind.SECRET_POSITION
        if (hasMemories && round % 7 == 0) return CardKind.MEMORY

        val phase = when {
            round <= 2 -> "warmup"
            round <= 5 -> "build"
            else -> "peak"
        }

        val roll = Random.nextInt(100)
        return when (mode) {
            GameMode.RELAX -> when (phase) {
                "warmup" -> when (roll) { in 0..34 -> CardKind.QUESTION; in 35..69 -> CardKind.SITUATION; in 70..94 -> CardKind.CHALLENGE; else -> CardKind.TENTATION }
                "build" -> when (roll) { in 0..29 -> CardKind.QUESTION; in 30..54 -> CardKind.SITUATION; in 55..82 -> CardKind.CHALLENGE; in 83..92 -> CardKind.TENTATION; else -> CardKind.DESTINY }
                else -> when (roll) { in 0..24 -> CardKind.QUESTION; in 25..49 -> CardKind.SITUATION; in 50..82 -> CardKind.CHALLENGE; in 83..91 -> CardKind.TENTATION; else -> CardKind.DESTINY }
            }
            GameMode.FUN -> when (phase) {
                "warmup" -> when (roll) { in 0..29 -> CardKind.QUESTION; in 30..64 -> CardKind.SITUATION; in 65..89 -> CardKind.CHALLENGE; else -> CardKind.DESTINY }
                "build" -> when (roll) { in 0..19 -> CardKind.QUESTION; in 20..54 -> CardKind.SITUATION; in 55..84 -> CardKind.CHALLENGE; in 85..91 -> CardKind.TENTATION; else -> CardKind.DESTINY }
                else -> when (roll) { in 0..16 -> CardKind.QUESTION; in 17..44 -> CardKind.SITUATION; in 45..78 -> CardKind.CHALLENGE; in 79..89 -> CardKind.TENTATION; else -> CardKind.DESTINY }
            }
            GameMode.ROMANTIC -> when (phase) {
                "warmup" -> when (roll) { in 0..39 -> CardKind.QUESTION; in 40..64 -> CardKind.SITUATION; in 65..87 -> CardKind.CHALLENGE; else -> CardKind.TENTATION }
                "build" -> when (roll) { in 0..31 -> CardKind.QUESTION; in 32..54 -> CardKind.SITUATION; in 55..79 -> CardKind.CHALLENGE; in 80..90 -> CardKind.TENTATION; else -> CardKind.DESTINY }
                else -> when (roll) { in 0..24 -> CardKind.QUESTION; in 25..44 -> CardKind.SITUATION; in 45..74 -> CardKind.CHALLENGE; in 75..88 -> CardKind.TENTATION; else -> CardKind.DESTINY }
            }
            GameMode.HOT -> when (phase) {
                "warmup" -> when (roll) { in 0..32 -> CardKind.QUESTION; in 33..56 -> CardKind.SITUATION; in 57..80 -> CardKind.CHALLENGE; in 81..90 -> CardKind.TENTATION; else -> CardKind.DESTINY }
                "build" -> when (roll) { in 0..21 -> CardKind.QUESTION; in 22..43 -> CardKind.SITUATION; in 44..73 -> CardKind.CHALLENGE; in 74..87 -> CardKind.TENTATION; else -> CardKind.DESTINY }
                else -> when (roll) { in 0..14 -> CardKind.QUESTION; in 15..31 -> CardKind.SITUATION; in 32..67 -> CardKind.CHALLENGE; in 68..85 -> CardKind.TENTATION; else -> CardKind.DESTINY }
            }
            GameMode.SECRET -> when (phase) {
                "warmup" -> when (roll) { in 0..24 -> CardKind.QUESTION; in 25..45 -> CardKind.SITUATION; in 46..69 -> CardKind.CHALLENGE; in 70..83 -> CardKind.TENTATION; in 84..91 -> CardKind.SECRET_POSITION; else -> CardKind.DESTINY }
                "build" -> when (roll) { in 0..16 -> CardKind.QUESTION; in 17..34 -> CardKind.SITUATION; in 35..63 -> CardKind.CHALLENGE; in 64..78 -> CardKind.TENTATION; in 79..90 -> CardKind.SECRET_POSITION; else -> CardKind.DESTINY }
                else -> when (roll) { in 0..9 -> CardKind.QUESTION; in 10..24 -> CardKind.SITUATION; in 25..56 -> CardKind.CHALLENGE; in 57..73 -> CardKind.TENTATION; in 74..90 -> CardKind.SECRET_POSITION; else -> CardKind.DESTINY }
            }
        }
    }

    fun challenge(mode:GameMode,intensity:Int,actionRoll:Int,zoneRoll:Int):GameCard{
        val template = intensitySlice(deck(mode).challenges, intensity, minSize = 4).random()
        val action = actions(mode)[(actionRoll - 1).mod(actions(mode).size)].lowercase()
        val zone = zones(mode)[(zoneRoll - 1).mod(zones(mode).size)]
        val duration = when (intensity.coerceIn(1, 5)) {
            1 -> listOf(15, 20, 25).random()
            2 -> listOf(20, 25, 30).random()
            3 -> listOf(30, 35, 40).random()
            4 -> listOf(35, 45, 50).random()
            else -> listOf(45, 55, 60).random()
        }
        val text = template.pattern
            .replace("{action}", action)
            .replace("{zone}", zone)
            .replace("{duration}", duration.toString())
        val detail = buildString {
            append(template.detail.ifBlank { "Jouez-la vraiment, puis dites en une phrase ce qui a le mieux fonctionné." })
            append("\n")
            append("Environ ")
            append(duration)
            append(" secondes · intensité ")
            append(intensity.coerceIn(1,5))
            append("/5 (")
            append(intensityWord(intensity))
            append(")")
        }
        return GameCard(CardKind.CHALLENGE, template.title, text, detail)
    }

    fun specialCard(kind:CardKind,mode:GameMode,intensity:Int,memories:List<String>):GameCard = when(kind){
        CardKind.TENTATION -> {
            val card = intensitySlice(deck(mode).temptations, intensity, minSize = 4).random()
            GameCard(kind, card.title, card.text, card.detail.ifBlank { "À jouer maintenant ou à garder pour plus tard." }, true)
        }
        CardKind.DESTINY -> {
            val card = destinyCards.random()
            GameCard(kind, card.title, card.text, card.detail)
        }
        CardKind.QUESTION -> {
            val card = intensitySlice(deck(mode).questions, intensity, minSize = 6).random()
            GameCard(kind, card.title, card.text, card.detail.ifBlank { listOf(
                "Répondez chacun à votre tour.",
                "Soyez précis : une vraie scène vaut mieux qu'un mot vague.",
                "Commencez par une réponse courte, puis développez si vous en avez envie.",
                "Vous pouvez d'abord deviner la réponse de l'autre avant de révéler la vôtre.",
                "Pas besoin de viser la perfection, juste une réponse honnête."
            ).random() })
        }
        CardKind.SITUATION -> {
            val card = intensitySlice(deck(mode).situations, intensity, minSize = 5).random()
            GameCard(kind, card.title, card.text, card.detail.ifBlank { "Jouez la situation pour de vrai, même brièvement." })
        }
        CardKind.MEMORY -> {
            val memory = memories.filter { it.isNotBlank() }.randomOrNull() ?: "un de vos meilleurs souvenirs"
            GameCard(kind, "Souvenir de nous", memoryTemplates.random().format(memory), "Comparez vos versions : la différence est souvent la partie la plus intéressante.")
        }
        CardKind.SECRET_POSITION -> {
            val maxDifficulty = intensity.coerceIn(1, 5)
            val position = positions.filter { it.difficulty <= maxDifficulty }.random()
            GameCard(
                kind,
                "Position guidée",
                position.name,
                "${position.category} · difficulté ${position.difficulty}/5\n${position.description}\nChoisissez : essayer, simplifier, mettre en favori ou passer.",
                false,
                position.poseId
            )
        }
        CardKind.CHALLENGE -> error("Use challenge()")
    }

    fun contentStats() = mapOf(
        "questions" to decks.values.sumOf { it.questions.size },
        "situations" to decks.values.sumOf { it.situations.size },
        "challenges" to decks.values.sumOf { it.challenges.size },
        "temptations" to decks.values.sumOf { it.temptations.size },
        "destiny" to destinyCards.size,
        "memories" to memoryTemplates.size,
        "positions" to positions.size
    )
}
