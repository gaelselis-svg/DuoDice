package be.gael.duodice

import android.content.Context
import android.os.Bundle
import kotlinx.coroutines.delay
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DuoDiceApp() }
    }
}

private val appColors = darkColorScheme(
    primary = Color(0xFF8EC5FF),
    secondary = Color(0xFFFFC37A),
    surface = Color(0xFF161B22),
    background = Color(0xFF0D1117)
)

private enum class Screen { GAME, SETTINGS }

@Composable
private fun DuoDiceApp() {
    val context = LocalContext.current
    val prefs = remember { DicePrefs(context) }

    var screen by remember { mutableStateOf(Screen.GAME) }
    var actionSides by remember { mutableIntStateOf(prefs.getSides("action")) }
    var bodySides by remember { mutableIntStateOf(prefs.getSides("body")) }
    var actionLabels by remember { mutableStateOf(prefs.loadLabels("action", actionSides)) }
    var bodyLabels by remember { mutableStateOf(prefs.loadLabels("body", bodySides)) }

    var actionResult by remember { mutableStateOf<Int?>(null) }
    var bodyResult by remember { mutableStateOf<Int?>(null) }
    var actionRollSignal by remember { mutableIntStateOf(0) }
    var bodyRollSignal by remember { mutableIntStateOf(0) }

    MaterialTheme(colorScheme = appColors) {
        Scaffold { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp)
            ) {
                Spacer(Modifier.height(14.dp))
                Text(
                    text = "DuoDice",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Action + partie du corps",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { screen = Screen.GAME },
                        modifier = Modifier.weight(1f),
                        enabled = screen != Screen.GAME
                    ) { Text("Jouer") }
                    Button(
                        onClick = { screen = Screen.SETTINGS },
                        modifier = Modifier.weight(1f),
                        enabled = screen != Screen.SETTINGS
                    ) { Text("Réglages") }
                }

                Spacer(Modifier.height(14.dp))

                when (screen) {
                    Screen.GAME -> GameScreen(
                        actionSides = actionSides,
                        bodySides = bodySides,
                        actionLabels = actionLabels,
                        bodyLabels = bodyLabels,
                        actionResult = actionResult,
                        bodyResult = bodyResult,
                        actionRollSignal = actionRollSignal,
                        bodyRollSignal = bodyRollSignal,
                        onRollAction = {
                            actionResult = Random.nextInt(1, actionSides + 1)
                            bodyResult = null
                            actionRollSignal++
                        },
                        onRollBody = {
                            bodyResult = Random.nextInt(1, bodySides + 1)
                            bodyRollSignal++
                        },
                        onReset = {
                            actionResult = null
                            bodyResult = null
                        }
                    )

                    Screen.SETTINGS -> SettingsScreen(
                        actionSides = actionSides,
                        bodySides = bodySides,
                        actionLabels = actionLabels,
                        bodyLabels = bodyLabels,
                        onActionSidesChange = { sides ->
                            actionSides = sides
                            prefs.setSides("action", sides)
                            actionLabels = prefs.loadLabels("action", sides)
                            actionResult = null
                            bodyResult = null
                        },
                        onBodySidesChange = { sides ->
                            bodySides = sides
                            prefs.setSides("body", sides)
                            bodyLabels = prefs.loadLabels("body", sides)
                            actionResult = null
                            bodyResult = null
                        },
                        onActionLabelChange = { index, value ->
                            actionLabels = actionLabels.toMutableList().also { it[index] = value }
                            prefs.saveLabel("action", actionSides, index + 1, value)
                        },
                        onBodyLabelChange = { index, value ->
                            bodyLabels = bodyLabels.toMutableList().also { it[index] = value }
                            prefs.saveLabel("body", bodySides, index + 1, value)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun GameScreen(
    actionSides: Int,
    bodySides: Int,
    actionLabels: List<String>,
    bodyLabels: List<String>,
    actionResult: Int?,
    bodyResult: Int?,
    actionRollSignal: Int,
    bodyRollSignal: Int,
    onRollAction: () -> Unit,
    onRollBody: () -> Unit,
    onReset: () -> Unit
) {
    val haptic = LocalHapticFeedback.current

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            DiceCard(
                title = "1 · Action",
                sides = actionSides,
                result = actionResult,
                label = actionResult?.let { actionLabels[it - 1] },
                rollSignal = actionRollSignal,
                buttonText = "Lancer le D$actionSides",
                enabled = true,
                onRoll = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onRollAction()
                }
            )
        }

        item {
            DiceCard(
                title = "2 · Partie du corps",
                sides = bodySides,
                result = bodyResult,
                label = bodyResult?.let { bodyLabels[it - 1] },
                rollSignal = bodyRollSignal,
                buttonText = "Lancer le D$bodySides",
                enabled = actionResult != null,
                onRoll = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onRollBody()
                }
            )
        }

        if (actionResult != null && bodyResult != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Résultat", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = "${actionLabels[actionResult - 1]} · ${bodyLabels[bodyResult - 1]}",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(14.dp))
                        OutlinedButton(onClick = onReset) { Text("Nouveau tour") }
                    }
                }
            }
        }

        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun DiceCard(
    title: String,
    sides: Int,
    result: Int?,
    label: String?,
    rollSignal: Int,
    buttonText: String,
    enabled: Boolean,
    onRoll: () -> Unit
) {
    var isAnimating by remember { mutableStateOf(false) }
    var revealResult by remember { mutableStateOf(result != null && rollSignal == 0) }

    LaunchedEffect(rollSignal, result) {
        if (result == null) {
            isAnimating = false
            revealResult = false
        } else if (rollSignal > 0) {
            isAnimating = true
            revealResult = false
            delay(1900)
            revealResult = true
            isAnimating = false
        } else {
            revealResult = true
        }
    }

    val resultScale by animateFloatAsState(
        targetValue = if (revealResult) 1f else 0.72f,
        animationSpec = tween(durationMillis = 240),
        label = "resultScale"
    )
    val resultAlpha by animateFloatAsState(
        targetValue = if (revealResult) 1f else 0f,
        animationSpec = tween(durationMillis = 220),
        label = "resultAlpha"
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("D$sides", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(8.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(205.dp),
                contentAlignment = Alignment.Center
            ) {
                AndroidView(
                    modifier = Modifier.size(205.dp),
                    factory = { ctx ->
                        DiceGLSurfaceView(ctx).apply { setDice(sides) }
                    },
                    update = { view ->
                        view.setDice(sides)
                        if (view.lastRollSignal != rollSignal) {
                            view.lastRollSignal = rollSignal
                            if (rollSignal > 0 && result != null) view.roll(result)
                        }
                    }
                )

                if (result != null) {
                    Text(
                        text = result.toString(),
                        modifier = Modifier.graphicsLayer {
                            alpha = resultAlpha
                            scaleX = resultScale
                            scaleY = resultScale
                        },
                        fontSize = 46.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                }
            }

            if (label != null) {
                Text(
                    text = label.ifBlank { "Face $result" },
                    modifier = Modifier.graphicsLayer {
                        alpha = resultAlpha
                        scaleX = 0.94f + 0.06f * resultScale
                        scaleY = 0.94f + 0.06f * resultScale
                    },
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(8.dp))
            }

            Button(
                onClick = onRoll,
                enabled = enabled && !isAnimating,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    when {
                        isAnimating -> "Lancement…"
                        enabled -> buttonText
                        else -> "Lance d'abord le dé Action"
                    }
                )
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    actionSides: Int,
    bodySides: Int,
    actionLabels: List<String>,
    bodyLabels: List<String>,
    onActionSidesChange: (Int) -> Unit,
    onBodySidesChange: (Int) -> Unit,
    onActionLabelChange: (Int, String) -> Unit,
    onBodyLabelChange: (Int, String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                "Seuls les dés polyédriques réels D4, D6, D8, D10, D12 et D20 sont proposés.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            DiceSettingsHeader(
                title = "Dé 1 · Actions",
                selectedSides = actionSides,
                onSidesChange = onActionSidesChange
            )
        }
        itemsIndexed(actionLabels) { index, value ->
            FaceField(
                face = index + 1,
                value = value,
                placeholder = "Action ${index + 1}",
                onValueChange = { onActionLabelChange(index, it) }
            )
        }

        item {
            Spacer(Modifier.height(10.dp))
            DiceSettingsHeader(
                title = "Dé 2 · Parties du corps",
                selectedSides = bodySides,
                onSidesChange = onBodySidesChange
            )
        }
        itemsIndexed(bodyLabels) { index, value ->
            FaceField(
                face = index + 1,
                value = value,
                placeholder = "Partie du corps ${index + 1}",
                onValueChange = { onBodyLabelChange(index, it) }
            )
        }

        item { Spacer(Modifier.height(30.dp)) }
    }
}

@Composable
private fun DiceSettingsHeader(
    title: String,
    selectedSides: Int,
    onSidesChange: (Int) -> Unit
) {
    Card(shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 19.sp)
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(DicePrefs.DICE_TYPES) { sides ->
                    FilterChip(
                        selected = selectedSides == sides,
                        onClick = { onSidesChange(sides) },
                        label = { Text("D$sides") }
                    )
                }
            }
        }
    }
}

@Composable
private fun FaceField(
    face: Int,
    value: String,
    placeholder: String,
    onValueChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        label = { Text("Face $face") },
        placeholder = { Text(placeholder) }
    )
}

private class DicePrefs(context: Context) {
    private val prefs = context.getSharedPreferences("duodice", Context.MODE_PRIVATE)

    fun getSides(kind: String): Int {
        val fallback = 6
        val stored = prefs.getInt("${kind}_sides", fallback)
        return if (stored in DICE_TYPES) stored else fallback
    }

    fun setSides(kind: String, sides: Int) {
        if (sides in DICE_TYPES) prefs.edit().putInt("${kind}_sides", sides).apply()
    }

    fun loadLabels(kind: String, sides: Int): List<String> {
        val defaults = defaultLabels(kind, sides)
        return List(sides) { i ->
            prefs.getString("${kind}_${sides}_${i + 1}", null) ?: defaults[i]
        }
    }

    fun saveLabel(kind: String, sides: Int, face: Int, value: String) {
        prefs.edit().putString("${kind}_${sides}_$face", value).apply()
    }

    private fun defaultLabels(kind: String, sides: Int): List<String> {
        val actions = listOf(
            "Masser", "Caresser", "Embrasser", "Chatouiller", "Tapoter",
            "Souffler", "Effleurer", "Presser doucement", "Dessiner un cercle", "Frotter doucement",
            "Faire des petits points", "Maintenir 5 secondes", "Faire des zigzags", "Pincer doucement", "Faire rouler les doigts",
            "Donner un bisou", "Faire une plume imaginaire", "Réchauffer avec la main", "Faire trois pressions", "Choisir une action libre"
        )
        val body = listOf(
            "Tête", "Cou", "Épaules", "Bras", "Mains",
            "Poitrine", "Ventre", "Dos", "Hanches", "Fesses",
            "Cuisses", "Genoux", "Mollets", "Chevilles", "Pieds",
            "Visage", "Oreilles", "Cheveux", "Taille", "Jambes"
        )
        val source = if (kind == "action") actions else body
        return List(sides) { i -> source.getOrElse(i) { if (kind == "action") "Action ${i + 1}" else "Partie ${i + 1}" } }
    }

    companion object {
        val DICE_TYPES = listOf(4, 6, 8, 10, 12, 20)
    }
}
