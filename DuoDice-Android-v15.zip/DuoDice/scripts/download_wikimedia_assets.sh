#!/usr/bin/env bash
set -euo pipefail
OUT="app/src/main/res/drawable-nodpi"
mkdir -p "$OUT"
rm -f "$OUT"/position_*.webp
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
UA='DuoDice/15.0 Android app (licensed Wikimedia asset fetch for build)'

python3 -m pip install --quiet pillow

# v15: clear modern illustrations only, with Kama Hasard support in-app.
cat > "$TMP/assets.tsv" <<'ASSETS'
00	Wiki-missionary.png
01	Sex position - sitting 1.png
02	Wiki-Wiener-auster.png
03	Wiki-cowgirl.png
04	Wiki-sitting-sp.png
05	Wiki-spoons-sp.png
06	Wiki-T-square.png
07	Flanquette - Sexposition 1.png
08	Wiki-lcp.png
09	Wiki-dstyle.png
10	A tergo - doggy style - lying sex position.png
11	Wiki-standing.png
12	Wiki-sixtynine.png
13	Reverse ekiben 1.png
14	Seventh Posture.png
15	Piledriver Sex Position V2-Front.jpg
16	Sex position - sitting 2.png
ASSETS

while IFS=$'\t' read -r idx filename; do
  echo "Downloading position_$idx: $filename"
  encoded=$(python3 - "$filename" <<'PY2'
import sys, urllib.parse
print(urllib.parse.quote(sys.argv[1], safe=''))
PY2
)
  curl --fail --location --silent --show-error \
       --retry 4 --retry-delay 2 --connect-timeout 20 --max-time 120 \
       --user-agent "$UA" \
       "https://commons.wikimedia.org/wiki/Special:Redirect/file/$encoded" \
       -o "$TMP/raw_$idx"
  test -s "$TMP/raw_$idx"
  python3 - "$TMP/raw_$idx" "$OUT/position_$idx.webp" <<'PY3'
import sys
from PIL import Image, ImageOps
src,dst=sys.argv[1:3]
with Image.open(src) as im:
    im=ImageOps.exif_transpose(im)
    if im.mode in ('RGBA','LA') or ('transparency' in im.info):
        bg=Image.new('RGBA',im.size,'white')
        bg.alpha_composite(im.convert('RGBA'))
        im=bg.convert('RGB')
    else:
        im=im.convert('RGB')
    im.thumbnail((1100,1100), Image.Resampling.LANCZOS)
    im.save(dst,'WEBP',quality=88,method=6)
PY3
  test -s "$OUT/position_$idx.webp"
done < "$TMP/assets.tsv"

count=$(find "$OUT" -name 'position_*.webp' -type f | wc -l)
echo "Embedded $count verified modern Wikimedia illustrations."
test "$count" -eq 17
