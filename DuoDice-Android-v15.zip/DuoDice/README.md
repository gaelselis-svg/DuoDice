# DuoDice v15 — Clear Kama + Kama Hasard

Application Android de jeu de couple avec modes Détente, Fun, Romantique, Hot, Secret et Extrême.

## v15
- Base v14 conservée pour les cartes et les modes.
- Bibliothèque Kama retravaillée avec **17 positions** modernes et lisibles.
- La position rejetée précédemment a été remplacée par une illustration assise plus claire.
- Ajout d’une position assise supplémentaire pour élargir le choix.
- Fiches détaillées : description, mise en place, avantages, inconvénients, conseils, difficulté et catégorie.
- Nouveau mode **Kama Hasard** : tire automatiquement **3 positions** au hasard : **1 facile**, **1 moyenne**, **1 difficile**.
- Possibilité de relancer le tirage Kama Hasard jusqu’à trouver une combinaison adaptée.
- Illustrations libres embarquées dans l’APK pour fonctionner hors ligne après build.

Voir `THIRD_PARTY_ASSETS.md` pour les crédits et licences.
