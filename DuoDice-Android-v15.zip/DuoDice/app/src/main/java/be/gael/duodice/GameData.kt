package be.gael.duodice

import kotlin.random.Random

enum class GameMode(val title:String,val subtitle:String,val emoji:String,val adultOnly:Boolean=false){
    RELAX("Détente","Calme, complicité et petites attentions","☁"),
    FUN("Fun","Flirt, rires et défis légers","★"),
    ROMANTIC("Romantique","Connexion, souvenirs et tendresse","♥"),
    HOT("Hot","Sexy, provocant et progressif","🔥",true),
    SECRET("Secret","Très chaud, intime et direct","◆",true),
    EXTREME("Extrême","Hyper chaud, sexuellement cru et direct","⚡",true)
}

enum class CardKind{CHALLENGE,TENTATION,DESTINY,QUESTION,SITUATION,MEMORY,SECRET_POSITION}

data class GameCard(
    val kind:CardKind,
    val title:String,
    val text:String,
    val detail:String="",
    val canSave:Boolean=false,
    val visualKey:Int=-1,
    val intensity:Int=1
)

data class SecretPosition(
    val name:String,
    val difficulty:Int,
    val category:String,
    val description:String,
    val setup:String,
    val advantages:String,
    val disadvantages:String,
    val tips:String,
    val poseId:Int,
    val imageUrl:String,
    val credit:String,
    val license:String,
    val sourcePage:String
)

private data class CuratedCard(
    val kind:CardKind,
    val intensity:Int,
    val title:String,
    val text:String,
    val detail:String="",
    val canSave:Boolean=false
)

object GameEngine {
    private val modeCards: Map<GameMode, List<CuratedCard>> = mapOf(
        GameMode.RELAX to listOf(
            CuratedCard(CardKind.QUESTION, 1, "Vérité", "Quel petit geste de ma part te met presque toujours de bonne humeur ?", ""),
            CuratedCard(CardKind.CHALLENGE, 1, "Action", "Fais-moi rire en moins de 30 secondes. Une seule tentative.", ""),
            CuratedCard(CardKind.QUESTION, 1, "Vérité", "Quel rendez-vous qu’on a déjà fait accepterais-tu de refaire exactement pareil ?", ""),
            CuratedCard(CardKind.CHALLENGE, 1, "Action", "Choisis une chanson qu’on écoute ensemble jusqu’au bout, sans toucher au téléphone.", ""),
            CuratedCard(CardKind.QUESTION, 1, "Vérité", "Quelle habitude chez moi trouves-tu bizarre mais attachante ?", ""),
            CuratedCard(CardKind.CHALLENGE, 1, "Action", "Imite-moi pendant 30 secondes et laisse-moi deviner ce que tu imites.", ""),
            CuratedCard(CardKind.QUESTION, 1, "Vérité", "Quel repas ou snack associes-tu directement à nous deux ?", ""),
            CuratedCard(CardKind.CHALLENGE, 1, "Action", "Trouve trois mots pour me décrire aujourd’hui. Pas de mot générique comme “gentil”.", ""),
            CuratedCard(CardKind.QUESTION, 1, "Vérité", "Quel moment banal de notre quotidien te plaît plus que tu ne l’avoues ?", ""),
            CuratedCard(CardKind.CHALLENGE, 1, "Action", "Montre-moi la dernière photo de nous deux que tu aimes vraiment et explique pourquoi.", ""),
            CuratedCard(CardKind.QUESTION, 1, "Vérité", "Si on avait une soirée totalement libre demain, qu’est-ce que tu voudrais faire ?", ""),
            CuratedCard(CardKind.CHALLENGE, 1, "Action", "Choisis une activité de 10 minutes à faire maintenant : musique, jeu, marche ou canapé.", ""),
            CuratedCard(CardKind.QUESTION, 1, "Vérité", "Quel film ou série pourrais-tu revoir avec moi sans te lasser ?", ""),
            CuratedCard(CardKind.CHALLENGE, 1, "Action", "Fais-moi un compliment précis sur quelque chose que j’ai fait cette semaine.", ""),
            CuratedCard(CardKind.QUESTION, 1, "Vérité", "Quel est le meilleur fou rire qu’on a eu ensemble ?", ""),
            CuratedCard(CardKind.CHALLENGE, 1, "Action", "Raconte notre rencontre comme si tu présentais une bande-annonce de film.", ""),
            CuratedCard(CardKind.QUESTION, 1, "Vérité", "Quel endroit près de chez nous aimerais-tu découvrir à deux ?", ""),
            CuratedCard(CardKind.CHALLENGE, 1, "Action", "Choisis une photo de ton téléphone qui raconte un bon souvenir et montre-la-moi.", ""),
            CuratedCard(CardKind.QUESTION, 1, "Vérité", "Quel truc simple améliorerait vraiment nos soirées à deux ?", ""),
            CuratedCard(CardKind.CHALLENGE, 1, "Action", "Pendant une minute, on ne parle que de choses qu’on a envie de faire ensemble prochainement.", ""),
            CuratedCard(CardKind.QUESTION, 1, "Vérité", "Quelle petite dépense te ferait plaisir pour nous deux ?", ""),
            CuratedCard(CardKind.CHALLENGE, 1, "Action", "Prépare ou apporte quelque chose à boire à ton partenaire comme si vous étiez au restaurant.", ""),
            CuratedCard(CardKind.QUESTION, 1, "Vérité", "Quel surnom pourrais-tu me donner juste pour ce soir ?", ""),
            CuratedCard(CardKind.CHALLENGE, 1, "Action", "Fais-moi deviner un souvenir commun en donnant seulement trois indices.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quel jour récent aimerais-tu pouvoir rejouer ?", ""),
            CuratedCard(CardKind.CHALLENGE, 1, "Action", "Choisis un endroit dans la pièce. On s’y installe ensemble pendant deux minutes sans écran.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quelle qualité chez moi t’aide le plus au quotidien ?", ""),
            CuratedCard(CardKind.CHALLENGE, 1, "Action", "Écris en une phrase une idée de mini-rendez-vous à faire cette semaine et montre-la-moi.", ""),
            CuratedCard(CardKind.QUESTION, 1, "Vérité", "Quelle différence entre nous te fait plutôt rire qu’elle ne t’agace ?", ""),
            CuratedCard(CardKind.CHALLENGE, 1, "Action", "Fais un top 3 de nos meilleurs snacks, films ou sorties. Ton partenaire peut contester le classement.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quel cadeau reçu de ma part t’a le plus marqué, même s’il n’était pas cher ?", ""),
            CuratedCard(CardKind.CHALLENGE, 1, "Action", "Décris-moi comme si tu devais me vendre dans une publicité absurde de 20 secondes.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quelle chose qu’on faisait plus souvent avant aimerais-tu reprendre ?", ""),
            CuratedCard(CardKind.CHALLENGE, 1, "Action", "Pose ton téléphone face cachée. Pendant trois minutes, chacun raconte sa journée sans être interrompu.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quelle petite attention te fait sentir que je pense à toi ?", ""),
            CuratedCard(CardKind.CHALLENGE, 1, "Action", "Choisis un dessert ou un snack qu’on partagera lors de notre prochaine soirée.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quelle photo de nous devrait absolument rester si on devait n’en garder qu’une dizaine ?", ""),
            CuratedCard(CardKind.CHALLENGE, 1, "Action", "Donne-moi un défi ridicule mais faisable en 20 secondes.", ""),
            CuratedCard(CardKind.QUESTION, 1, "Vérité", "Quel est notre meilleur “inside joke” ?", ""),
            CuratedCard(CardKind.CHALLENGE, 1, "Action", "Refais une de mes expressions ou phrases typiques jusqu’à ce que je la reconnaisse.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Qu’est-ce qui te fait penser à moi quand je ne suis pas là ?", ""),
            CuratedCard(CardKind.CHALLENGE, 1, "Action", "Choisis une chanson qui pourrait être notre générique et explique ton choix.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quel projet simple à deux te ferait plaisir avant la fin du mois ?", ""),
            CuratedCard(CardKind.CHALLENGE, 1, "Action", "Pendant 30 secondes, chacun dit à tour de rôle une chose qu’il apprécie chez l’autre.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quel est le meilleur conseil que je t’ai déjà donné ?", ""),
            CuratedCard(CardKind.CHALLENGE, 1, "Action", "Invente un nom d’équipe pour nous deux et un slogan ridicule.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quelle soirée parfaite à la maison imagines-tu avec trois éléments maximum ?", ""),
            CuratedCard(CardKind.CHALLENGE, 1, "Action", "Choisis entre : câlin de 30 secondes, mini danse, massage des épaules ou fou rire forcé jusqu’à rire pour de vrai.", "")
        ),
        GameMode.FUN to listOf(
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "À quel moment m’as-tu trouvé particulièrement attirant(e) récemment ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Embrasse-moi à l’endroit de ton choix, sauf sur la bouche.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quel vêtement que je porte te plaît le plus ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Approche-toi et murmure-moi ce que tu aimerais qu’on fasse après cette partie.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Si on devait passer une nuit ailleurs ce soir, où irions-nous ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Donne-moi un baiser de 10 secondes sans utiliser tes mains.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quel compliment venant de moi te ferait le plus plaisir ce soir ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Choisis une chanson et entraîne-moi dans une danse de 30 secondes.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quel look aimerais-tu me voir porter pour une soirée à deux ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Regarde-moi dans les yeux et essaie de me faire sourire sans parler.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quel genre de message de ma part te ferait immédiatement sourire dans la journée ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Envoie-moi maintenant un message comme si on essayait de se séduire pour la première fois.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Qu’est-ce que tu trouves le plus séduisant dans ma façon d’être ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Choisis une partie de mon visage et embrasse-la lentement trois fois.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quel serait ton rendez-vous surprise idéal avec moi ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Fais-moi un compliment en évitant le physique.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quel souvenir de vacances ou de sortie à deux te donne encore envie de repartir ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Pendant 20 secondes, reste très proche de moi sans m’embrasser.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Qu’est-ce qui te plaît le plus quand je prends l’initiative ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Choisis entre : main dans la main, tête sur l’épaule, câlin serré ou baiser long.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quelle qualité chez moi te paraît la plus attirante ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Décris en trois mots l’ambiance que tu aimerais pour le reste de la soirée.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quel endroit public mais raisonnable serait parfait pour un rendez-vous spontané ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Fais une mini déclaration de 15 secondes, sérieuse ou drôle, mais sincère.", ""),
            CuratedCard(CardKind.QUESTION, 3, "Vérité", "Quel détail physique chez moi remarques-tu le plus souvent ?", ""),
            CuratedCard(CardKind.CHALLENGE, 3, "Action", "Embrasse-moi comme si on ne s’était pas vus depuis une semaine.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Tu préfères être surpris(e) ou savoir ce qui est prévu pour une soirée romantique ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Choisis une de mes mains et garde-la dans la tienne pendant les deux prochaines cartes.", ""),
            CuratedCard(CardKind.QUESTION, 3, "Vérité", "Quel genre de flirt entre nous fonctionne le mieux sur toi ?", ""),
            CuratedCard(CardKind.CHALLENGE, 3, "Action", "Murmure-moi un compliment que tu n’oserais pas forcément dire devant d’autres personnes.", ""),
            CuratedCard(CardKind.QUESTION, 3, "Vérité", "Quel type de baiser préfères-tu : court, long, tendre ou plus intense ?", ""),
            CuratedCard(CardKind.CHALLENGE, 3, "Action", "Donne-moi trois baisers différents et laisse-moi choisir mon préféré.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quelle sortie à deux te ferait vraiment sortir de la routine ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Fais-moi deviner ce que tu trouves attirant chez moi uniquement avec des gestes.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "À quel moment te sens-tu le plus proche de moi ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Installe-nous dans la position la plus confortable possible sur le canapé ou le lit.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quelle chose un peu spontanée aimerais-tu qu’on fasse plus souvent ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Choisis une photo de moi que tu trouves particulièrement réussie et montre-la-moi.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quel serait notre “date night” parfait avec un budget de 30 euros ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Fais-moi choisir entre trois idées de sortie que tu proposes maintenant.", ""),
            CuratedCard(CardKind.QUESTION, 3, "Vérité", "Quel geste de séduction de ma part fonctionne presque à tous les coups ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Pendant 30 secondes, parle-moi comme si on venait juste de se rencontrer et que tu voulais me séduire.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quel genre de surprise te ferait plaisir sans te mettre mal à l’aise ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Choisis une partie de la soirée que tu prends complètement en charge : musique, boisson, snack ou activité.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quel souvenir de nous te donne instantanément le sourire ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Fais un selfie de nous deux qui résume l’ambiance du moment.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Tu préfères une soirée très organisée ou totalement improvisée avec moi ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Choisis : un long baiser, un massage des épaules ou une minute collés l’un à l’autre.", "")
        ),
        GameMode.ROMANTIC to listOf(
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quel souvenir de nous te revient quand tu penses à nos meilleurs moments ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Regarde-moi dans les yeux pendant 20 secondes, puis dis-moi ce que tu apprécies le plus chez moi aujourd’hui.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Qu’est-ce que je fais qui te fait te sentir aimé(e), même quand je ne m’en rends pas compte ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Choisis notre prochain vrai rendez-vous : endroit, activité et moment.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Y a-t-il quelque chose que tu aimerais qu’on fasse plus souvent tous les deux ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Fais-moi un câlin d’une minute sans téléphone et sans parler.", ""),
            CuratedCard(CardKind.QUESTION, 3, "Vérité", "À quel moment as-tu compris que notre relation comptait vraiment pour toi ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Dis-moi une chose que tu aimerais vivre avec moi dans les douze prochains mois.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quelle qualité chez moi t’a surpris(e) positivement avec le temps ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Raconte-moi un souvenir commun que tu aimerais ne jamais oublier.", ""),
            CuratedCard(CardKind.QUESTION, 3, "Vérité", "Quand te sens-tu le plus soutenu(e) par moi ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Remercie-moi pour quelque chose de précis que j’ai fait récemment.", ""),
            CuratedCard(CardKind.QUESTION, 3, "Vérité", "Qu’est-ce que notre couple fait mieux aujourd’hui qu’au début ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Choisis une habitude de couple qu’on pourrait instaurer une fois par semaine.", ""),
            CuratedCard(CardKind.QUESTION, 3, "Vérité", "Quel moment difficile nous a finalement rapprochés ?", ""),
            CuratedCard(CardKind.CHALLENGE, 3, "Action", "Tiens-moi la main et raconte-moi ce que tu voudrais protéger dans notre relation.", ""),
            CuratedCard(CardKind.QUESTION, 3, "Vérité", "Qu’est-ce que tu aimerais que je comprenne mieux sur toi ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Dis-moi une chose que tu admires chez moi et donne un exemple concret.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quel projet commun te motive le plus en ce moment ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Planifie oralement une journée parfaite ensemble, du réveil au coucher.", ""),
            CuratedCard(CardKind.QUESTION, 3, "Vérité", "Quel changement positif chez moi as-tu remarqué ces dernières années ou derniers mois ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Choisis un souvenir de nous et raconte-le de ton point de vue.", ""),
            CuratedCard(CardKind.QUESTION, 3, "Vérité", "Qu’est-ce qui te rassure le plus dans notre relation ?", ""),
            CuratedCard(CardKind.CHALLENGE, 3, "Action", "Donne-moi un baiser puis dis-moi une chose que tu aimerais qu’on garde toujours entre nous.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quelle petite tradition de couple aimerais-tu créer ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Écris mentalement trois choses que tu aimes chez moi, puis dis-les une par une.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quel moment de notre quotidien te fait sentir qu’on forme une équipe ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Choisis une photo de nous et raconte ce que tu ressentais à ce moment-là.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Qu’est-ce que tu aimerais qu’on célèbre davantage ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Propose une soirée sans écran que tu serais vraiment content(e) de faire.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quel compliment de ma part t’a le plus marqué ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Dis-moi une chose que tu trouves belle dans notre relation aujourd’hui.", ""),
            CuratedCard(CardKind.QUESTION, 3, "Vérité", "Quelle peur ou inquiétude peux-tu plus facilement partager avec moi qu’avec d’autres ?", ""),
            CuratedCard(CardKind.CHALLENGE, 3, "Action", "Pendant une minute, écoute-moi te dire quelque chose d’important sans répondre ni conseiller.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Qu’aimerais-tu qu’on apprenne ensemble ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Choisis une destination ou activité qu’on ajoute à notre liste “à faire ensemble”.", ""),
            CuratedCard(CardKind.QUESTION, 3, "Vérité", "Quel geste d’affection voudrais-tu recevoir plus souvent ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Montre-moi exactement le type de câlin que tu préfères.", ""),
            CuratedCard(CardKind.QUESTION, 3, "Vérité", "Qu’est-ce qui te donne le sentiment d’être choisi(e) par moi ?", ""),
            CuratedCard(CardKind.CHALLENGE, 3, "Action", "Dis-moi quelque chose que tu as pensé récemment sur nous sans me l’avoir encore dit.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Dans quoi sommes-nous vraiment complémentaires ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Choisis une qualité que tu veux apporter davantage à notre couple cette semaine.", ""),
            CuratedCard(CardKind.QUESTION, 3, "Vérité", "Quel futur souvenir aimerais-tu absolument créer avec moi ?", ""),
            CuratedCard(CardKind.CHALLENGE, 3, "Action", "Imagine notre anniversaire idéal dans cinq ans et raconte-le-moi en une minute.", ""),
            CuratedCard(CardKind.QUESTION, 3, "Vérité", "Qu’est-ce qui te fait te sentir le plus en sécurité émotionnellement avec moi ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Demande-moi une chose simple que je peux faire cette semaine pour te faire plaisir.", ""),
            CuratedCard(CardKind.QUESTION, 2, "Vérité", "Quel moment récent t’a rendu fier/fière de nous ?", ""),
            CuratedCard(CardKind.CHALLENGE, 2, "Action", "Termine cette phrase : “J’aime notre couple quand…” puis laisse-moi faire la même chose.", "")
        ),
        GameMode.HOT to listOf(
            CuratedCard(CardKind.QUESTION, 3, "Vérité", "Quelle partie de mon corps préfères-tu embrasser ?", ""),
            CuratedCard(CardKind.CHALLENGE, 3, "Action", "Embrasse lentement mon cou pendant 20 secondes.", ""),
            CuratedCard(CardKind.QUESTION, 3, "Vérité", "Tu préfères généralement prendre l’initiative ou que je la prenne ?", ""),
            CuratedCard(CardKind.CHALLENGE, 3, "Action", "Offre-moi un massage sensuel de deux minutes. Tu choisis où.", ""),
            CuratedCard(CardKind.QUESTION, 4, "Vérité", "Quelle position sexuelle préfères-tu avec moi ?", ""),
            CuratedCard(CardKind.CHALLENGE, 3, "Action", "Choisis une partie de mon corps et embrasse-la comme tu en as envie pendant 30 secondes.", ""),
            CuratedCard(CardKind.QUESTION, 4, "Vérité", "Y a-t-il quelque chose que tu aimerais que je fasse davantage pendant les préliminaires ?", ""),
            CuratedCard(CardKind.CHALLENGE, 4, "Action", "Murmure-moi une envie que tu serais réellement prêt(e) à essayer.", ""),
            CuratedCard(CardKind.QUESTION, 3, "Vérité", "Tu préfères quelque chose de lent et sensuel ou plus intense ?", ""),
            CuratedCard(CardKind.CHALLENGE, 3, "Action", "Ton partenaire choisit où tu dois l’embrasser pendant une minute.", ""),
            CuratedCard(CardKind.QUESTION, 4, "Vérité", "Quel type de toucher te fait monter le plus vite en tension ?", ""),
            CuratedCard(CardKind.CHALLENGE, 3, "Action", "Pendant 45 secondes, embrasse uniquement le visage, le cou et les épaules de ton partenaire.", ""),
            CuratedCard(CardKind.QUESTION, 3, "Vérité", "Qu’est-ce qui te met le plus dans l’ambiance avant le sexe ?", ""),
            CuratedCard(CardKind.CHALLENGE, 3, "Action", "Choisis une chanson pour créer l’ambiance et rapproche-toi de ton partenaire pendant qu’elle commence.", ""),
            CuratedCard(CardKind.QUESTION, 3, "Vérité", "Quel moment de la journée te donne le plus envie d’intimité ?", ""),
            CuratedCard(CardKind.CHALLENGE, 3, "Action", "Donne un baiser long puis arrête-toi juste avant que ton partenaire ne s’y attende.", ""),
            CuratedCard(CardKind.QUESTION, 4, "Vérité", "Quelle tenue ou absence de tenue trouves-tu la plus attirante chez moi ?", ""),
            CuratedCard(CardKind.CHALLENGE, 4, "Action", "Enlève ou fais enlever une seule couche de vêtement, uniquement si vous en avez tous les deux envie.", ""),
            CuratedCard(CardKind.QUESTION, 4, "Vérité", "Qu’est-ce que tu préfères pendant les préliminaires : baisers, caresses, massage ou autre ?", ""),
            CuratedCard(CardKind.CHALLENGE, 3, "Action", "Pendant une minute, ton partenaire choisit le rythme des baisers.", ""),
            CuratedCard(CardKind.QUESTION, 3, "Vérité", "Quelle ambiance te plaît le plus : lumière tamisée, obscurité, musique ou silence ?", ""),
            CuratedCard(CardKind.CHALLENGE, 3, "Action", "Éteins ou baisse une lumière et crée l’ambiance que tu préfères.", ""),
            CuratedCard(CardKind.QUESTION, 3, "Vérité", "Quel est le baiser le plus excitant qu’on ait partagé récemment ?", ""),
            CuratedCard(CardKind.CHALLENGE, 3, "Action", "Reproduis le type de baiser que tu préfères recevoir.", ""),
            CuratedCard(CardKind.QUESTION, 4, "Vérité", "Y a-t-il une position que tu apprécies mais qu’on utilise trop rarement ?", ""),
            CuratedCard(CardKind.CHALLENGE, 4, "Action", "Choisis une position de la bibliothèque Kama que tu aimerais essayer plus tard et montre-la à ton partenaire.", ""),
            CuratedCard(CardKind.QUESTION, 4, "Vérité", "Qu’est-ce qui te plaît le plus quand je prends le contrôle ?", ""),
            CuratedCard(CardKind.CHALLENGE, 4, "Action", "Pendant une minute, prends l’initiative sur les baisers et les caresses, avec possibilité de dire stop à tout moment.", ""),
            CuratedCard(CardKind.QUESTION, 4, "Vérité", "Qu’est-ce qui te plaît le plus quand tu me laisses décider ?", ""),
            CuratedCard(CardKind.CHALLENGE, 4, "Action", "Laisse ton partenaire choisir entre trois options : baiser long, massage, caresses par-dessus les vêtements.", ""),
            CuratedCard(CardKind.QUESTION, 4, "Vérité", "Quel mot ou phrase te plaît particulièrement pendant un moment intime ?", ""),
            CuratedCard(CardKind.CHALLENGE, 4, "Action", "Murmure une phrase que ton partenaire aimerait entendre pendant un moment intime.", ""),
            CuratedCard(CardKind.QUESTION, 4, "Vérité", "Qu’est-ce qui te coupe le plus l’envie pendant un moment intime ?", ""),
            CuratedCard(CardKind.CHALLENGE, 3, "Action", "Dites chacun une limite claire et une chose que vous aimez. Puis reprenez le jeu.", ""),
            CuratedCard(CardKind.QUESTION, 3, "Vérité", "Tu préfères être surpris(e) ou qu’on te demande clairement ce que tu veux ?", ""),
            CuratedCard(CardKind.CHALLENGE, 3, "Action", "Demande directement à ton partenaire : “Qu’est-ce qui te ferait plaisir maintenant ?” et choisis une réponse réalisable.", ""),
            CuratedCard(CardKind.QUESTION, 4, "Vérité", "Quel souvenir intime entre nous te revient le plus facilement ?", ""),
            CuratedCard(CardKind.CHALLENGE, 4, "Action", "Décris en une phrase un moment intime que tu aimerais revivre avec moi.", ""),
            CuratedCard(CardKind.QUESTION, 4, "Vérité", "Quel endroit de la maison te paraît le plus propice à changer de routine ?", ""),
            CuratedCard(CardKind.CHALLENGE, 3, "Action", "Choisissez ensemble un autre endroit confortable de la maison pour continuer deux cartes.", ""),
            CuratedCard(CardKind.QUESTION, 4, "Vérité", "Quel type de caresse aimerais-tu recevoir plus longtemps ?", ""),
            CuratedCard(CardKind.CHALLENGE, 4, "Action", "Guide la main de ton partenaire vers une zone que tu apprécies, uniquement si cela vous convient à tous les deux.", ""),
            CuratedCard(CardKind.QUESTION, 3, "Vérité", "As-tu envie que nos moments intimes soient parfois plus planifiés ou plus spontanés ?", ""),
            CuratedCard(CardKind.CHALLENGE, 3, "Action", "Décidez ensemble d’une chose que vous aimeriez essayer lors d’une prochaine soirée intime.", ""),
            CuratedCard(CardKind.QUESTION, 4, "Vérité", "Quel est ton signal préféré pour me montrer que tu as envie de moi ?", ""),
            CuratedCard(CardKind.CHALLENGE, 4, "Action", "Montre-moi sans parler comment tu me ferais comprendre que tu as envie de moi.", ""),
            CuratedCard(CardKind.QUESTION, 4, "Vérité", "Quel est le meilleur moyen pour moi de savoir si tu veux ralentir, continuer ou changer ?", ""),
            CuratedCard(CardKind.CHALLENGE, 3, "Action", "Choisissez trois mots simples pour guider la suite : “continue”, “plus lentement”, “change”.", "")
        ),
        GameMode.SECRET to listOf(
            CuratedCard(CardKind.QUESTION, 4, "Vérité", "Quelle pratique sexuelle que nous n’avons jamais essayée t’intrigue réellement ?", ""),
            CuratedCard(CardKind.CHALLENGE, 4, "Action", "Choisis une position dans la bibliothèque Kama et propose-la à ton partenaire : oui, peut-être ou non.", ""),
            CuratedCard(CardKind.QUESTION, 4, "Vérité", "Y a-t-il une position que tu aimerais essayer ce soir ?", ""),
            CuratedCard(CardKind.CHALLENGE, 4, "Action", "Pendant deux minutes, l’un dirige le rythme et l’autre peut dire “continue”, “doucement”, “change” ou “stop”.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité", "Est-ce qu’un jeu de domination ou de soumission t’attire ? Si oui, dans quel rôle ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action", "Choisissez ensemble qui mène pendant les trois prochaines minutes. Le rôle peut être arrêté à tout moment.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité", "Quel fantasme ne m’as-tu encore jamais raconté ?", ""),
            CuratedCard(CardKind.CHALLENGE, 4, "Action", "Choisissez ensemble une chose que vous avez déjà faite et que vous aimeriez refaire ce soir.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité", "Y a-t-il un sextoy ou accessoire que tu voudrais essayer ensemble ?", ""),
            CuratedCard(CardKind.CHALLENGE, 4, "Action", "Choisis entre : massage sensuel, préliminaires, nouvelle position ou surprise du partenaire.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité", "Quel est l’endroit le plus excitant où tu serais réellement prêt(e) à faire l’amour tout en restant dans un cadre sûr et privé ?", ""),
            CuratedCard(CardKind.CHALLENGE, 4, "Action", "Ton partenaire choisit une position parmi trois proposées dans l’application. Tu peux accepter, demander une autre ou passer.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité", "Quelle chose que je fais pendant le sexe voudrais-tu que je fasse plus souvent ?", ""),
            CuratedCard(CardKind.CHALLENGE, 4, "Action", "Dis clairement une chose que tu veux plus, une chose que tu veux moins et une chose que tu aimerais tester.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité", "Le langage cru pendant le sexe t’excite, te laisse indifférent(e) ou te gêne ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action", "Si vous êtes tous les deux à l’aise, murmure une phrase plus audacieuse que d’habitude.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité", "Quelle place ont les sextoys dans ce que tu aimerais explorer à deux ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action", "Si vous possédez un accessoire que vous aimez tous les deux, choisissez ensemble s’il entre dans la partie ou non.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité", "Est-ce que le fait d’avoir les yeux bandés t’attire ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action", "Si vous êtes tous les deux d’accord, l’un ferme les yeux pendant 30 secondes pendant que l’autre choisit uniquement des baisers ou caresses légères.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité", "Quel type de contrôle te plaît le plus : rythme, position, consignes ou simplement prendre l’initiative ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action", "Choisis un seul élément que tu contrôles pendant deux minutes : rythme, position ou type de toucher.", ""),
            CuratedCard(CardKind.QUESTION, 4, "Vérité", "Y a-t-il une pratique que tu sais déjà ne pas vouloir essayer ?", ""),
            CuratedCard(CardKind.CHALLENGE, 4, "Action", "Chacun dit une limite non négociable. Aucun commentaire ni justification n’est demandé.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité", "Est-ce que regarder du contenu érotique ensemble pourrait t’intéresser, ou pas du tout ?", ""),
            CuratedCard(CardKind.CHALLENGE, 4, "Action", "Choisissez un thème ou une ambiance érotique qui vous intrigue tous les deux, sans obligation de la réaliser.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité", "Est-ce qu’un scénario ou jeu de rôle t’attire ? Si oui, lequel ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action", "Inventez ensemble un scénario en une phrase. Vous décidez ensuite : maintenant, plus tard ou jamais.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité", "Qu’est-ce qui t’excite le plus dans l’idée d’essayer quelque chose de nouveau ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action", "Chacun propose une nouveauté. Gardez uniquement celle qui reçoit deux “oui” ou deux “peut-être”.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité", "As-tu déjà simulé avoir plus envie que tu n’en avais réellement ?", ""),
            CuratedCard(CardKind.CHALLENGE, 4, "Action", "Chacun décrit son meilleur signal pour dire “pas ce soir” sans que l’autre le prenne personnellement.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité", "Est-ce que recevoir des consignes précises pendant le sexe te plaît ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action", "Si oui pour les deux, donne une consigne simple et réversible : “plus lentement”, “plus près”, “continue”.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité", "Y a-t-il une partie de ton corps que tu aimerais que j’explore davantage ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action", "Montre ou nomme une zone que tu aimerais que ton partenaire embrasse ou caresse davantage.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité", "Quel rôle te plaît le plus dans une soirée très intense : mener, suivre ou alterner ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action", "Décidez d’alterner : une minute chacun à prendre l’initiative, puis choisissez ce que vous avez préféré.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité", "Est-ce que le sexe oral est quelque chose que tu aimerais recevoir plus souvent, donner plus souvent, les deux ou ni l’un ni l’autre ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action", "Parlez pendant une minute de ce que chacun aime ou n’aime pas dans le sexe oral. Pas d’obligation de passer à l’action.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité", "L’anal t’intéresse-t-il : oui, peut-être, non, ou seulement dans certaines conditions ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action", "Si le sujet vous intéresse tous les deux, dites uniquement quelles conditions de confort et de sécurité seraient nécessaires. Sinon, passez.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité", "Quel fantasme te semble excitant en imagination mais pas forcément dans la réalité ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action", "Chacun partage un fantasme “imagination seulement” sans devoir le transformer en projet.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité", "Est-ce que filmer ou photographier un moment intime t’attire, ou est-ce une limite claire ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action", "Décidez ensemble de votre règle sur les photos/vidéos intimes : jamais, seulement avec accord explicite, ou autre règle commune.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité", "Quelle est la chose la plus audacieuse que tu serais vraiment partant(e) pour essayer avec moi ?", ""),
            CuratedCard(CardKind.CHALLENGE, 4, "Action", "Terminez par un choix commun : “on continue”, “on ralentit”, “on change de mode” ou “on arrête ici”.", "")
        ),
        GameMode.EXTREME to listOf(
            CuratedCard(CardKind.QUESTION, 5, "Vérité crue", "Quelle pratique sexuelle voudrais-tu que je te fasse plus souvent, sans tourner autour du pot ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action extrême", "Lèche ton/ta partenaire pendant 60 secondes en gardant le même rythme. La personne qui reçoit te guide seulement avec « plus vite », « plus lentement », « continue » ou « stop ».", "Réservé aux adultes consentants."),
            CuratedCard(CardKind.QUESTION, 5, "Vérité crue", "Si tu pouvais choisir maintenant entre sexe oral, pénétration, sextoy ou masturbation mutuelle, qu’est-ce que tu choisirais vraiment ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action extrême", "Dis exactement où tu veux être léché(e) ou touché(e), puis guide ton/ta partenaire jusqu’au rythme qui te plaît.", "Tu peux arrêter ou changer à tout moment."),
            CuratedCard(CardKind.QUESTION, 5, "Vérité crue", "Quel fantasme sexuel n’as-tu encore jamais osé me demander directement ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action extrême", "Si vous êtes tous les deux d’accord, mets doucement un doigt bien lubrifié dans les fesses de ton/ta partenaire. La personne qui reçoit contrôle entièrement profondeur et rythme.", "Lubrifiant indispensable. Aucun mouvement brusque."),
            CuratedCard(CardKind.QUESTION, 5, "Vérité crue", "Tu préfères généralement lécher, être léché(e), sucer, être sucé(e), ou varier selon l’envie ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action extrême", "Si votre anatomie s’y prête et que vous en avez envie, frotte ton sexe entre les seins de ton/ta partenaire pendant une minute.", "Choisissez une pression confortable."),
            CuratedCard(CardKind.QUESTION, 5, "Vérité crue", "Qu’est-ce que tu aimerais que je fasse différemment quand je te fais du sexe oral ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action extrême", "Assieds-toi sur le visage de ton/ta partenaire pour une courte séquence de sexe oral, uniquement si vous êtes tous les deux à l’aise. La personne dessous garde toujours un moyen clair d’arrêter.", "Ne bloquez jamais la respiration."),
            CuratedCard(CardKind.QUESTION, 5, "Vérité crue", "Est-ce que l’idée d’une pénétration orale plus profonde t’excite réellement, ou pas du tout ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action extrême", "Si la personne qui pratique en a envie, essayez une fellation plus profonde pendant quelques mouvements. Elle contrôle seule la profondeur : aucune poussée ni maintien de la tête.", "La respiration doit rester libre à tout moment."),
            CuratedCard(CardKind.QUESTION, 5, "Vérité crue", "Quelle position sexuelle te donne envie rien qu’en la voyant ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action extrême", "Ouvre la bibliothèque Kamasutra, choisis trois positions très chaudes et laisse ton/ta partenaire en accepter une, en demander une autre ou passer.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité crue", "Tu préfères être celui/celle qui prend le contrôle, celui/celle qui se laisse diriger, ou alterner ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action extrême", "Pendant deux minutes, une seule personne décide du rythme et de la position. L’autre garde cinq mots : « continue », « plus fort », « plus doux », « change », « stop ».", "Le mot « stop » met fin immédiatement au défi."),
            CuratedCard(CardKind.QUESTION, 5, "Vérité crue", "Quel sextoy aimerais-tu vraiment utiliser avec moi lors d’une prochaine partie ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action extrême", "Choisissez un sextoy que vous possédez déjà et que vous avez tous les deux validé. La personne qui le reçoit décide comment il est utilisé pendant 90 secondes.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité crue", "Quelle partie de mon corps te donne le plus envie de la lécher, la sucer ou la mordiller doucement ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action extrême", "Choisis une zone du corps de ton/ta partenaire et utilise uniquement ta bouche pendant une minute : baisers, langue et succion douce.", "Évite toute zone douloureuse ou déjà irritée."),
            CuratedCard(CardKind.QUESTION, 5, "Vérité crue", "Pendant le sexe, quels mots crus te plaisent vraiment et lesquels te coupent immédiatement l’envie ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action extrême", "Dis à ton/ta partenaire, avec tes vrais mots, ce que tu veux qu’il/elle te fasse maintenant. Pas de sous-entendu.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité crue", "Est-ce que recevoir une fessée légère ou en donner t’excite ? Si oui, dans quelles limites ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action extrême", "Si vous l’avez validé tous les deux, donne trois fessées légères sur une zone charnue. La personne qui reçoit choisit ensuite : arrêter, continuer pareil ou un peu plus fort.", "Jamais sur le dos, les reins ou une zone blessée."),
            CuratedCard(CardKind.QUESTION, 5, "Vérité crue", "Quelle chose que nous faisons déjà voudrais-tu rendre franchement plus intense ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action extrême", "Choisissez une pratique que vous aimez déjà et faites-la pendant deux minutes en augmentant seulement un paramètre : rythme, pression ou durée.", "Un seul paramètre à la fois."),
            CuratedCard(CardKind.QUESTION, 5, "Vérité crue", "As-tu envie d’essayer un jour le sexe anal ? Si oui, qu’est-ce qui te rassurerait le plus pour que ce soit agréable ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action extrême", "Si l’anal fait partie de vos envies communes, commencez uniquement par une stimulation externe lente avec beaucoup de lubrifiant pendant une minute.", "Aucune pénétration n’est obligatoire."),
            CuratedCard(CardKind.QUESTION, 5, "Vérité crue", "Quelle est la chose la plus obscène que tu aimerais m’entendre te demander ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action extrême", "Murmure à l’oreille de ton/ta partenaire une consigne sexuelle très directe que tu aimerais réellement qu’il/elle suive. Il/elle répond oui, modifier ou passer.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité crue", "Tu préfères que le sexe oral soit lent et prolongé, rapide et intense, ou alterné ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action extrême", "Fais du sexe oral à ton/ta partenaire pendant une minute et laisse-le/la modifier ton rythme avec une main ou avec des mots.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité crue", "Est-ce que regarder ton/ta partenaire se masturber t’excite ? Et l’inverse ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action extrême", "Masturbe-toi devant ton/ta partenaire pendant une minute, uniquement si vous en avez tous les deux envie. L’autre regarde sans toucher jusqu’à la fin du minuteur.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité crue", "Quelle position par derrière préfères-tu réellement, et qu’est-ce qui fait la différence pour toi ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action extrême", "Choisissez une position par derrière que vous aimez déjà. La personne qui reçoit choisit le rythme pendant les 90 premières secondes.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité crue", "Est-ce qu’un bandeau sur les yeux t’excite ? Qu’est-ce que tu accepterais de recevoir dans cette situation ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action extrême", "Si vous l’avez validé, l’un met un bandeau ou ferme les yeux pendant 60 secondes. L’autre alterne trois sensations déjà acceptées : bouche, mains ou sextoy.", "Aucune surprise hors des limites validées."),
            CuratedCard(CardKind.QUESTION, 5, "Vérité crue", "Quelle pratique sexuelle aimerais-tu essayer uniquement si tu savais déjà que j’en avais très envie aussi ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action extrême", "Chacun écrit ou dit une pratique très sexuelle qu’il aimerait tester. Si les deux envies sont compatibles, elle devient le prochain défi ; sinon, passez sans justification.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité crue", "Tu préfères qu’on te donne des ordres sexuels directs ou que l’on te demande ce que tu veux ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action extrême", "Pendant deux minutes, la personne qui dirige donne des consignes courtes et explicites. La personne qui reçoit peut refuser n’importe laquelle sans casser le jeu.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité crue", "Quelle zone de ton corps voudrais-tu que j’explore beaucoup plus longtemps avec ma bouche ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action extrême", "Choisis une zone que ton/ta partenaire aime recevoir avec la bouche et consacre-lui 90 secondes sans changer de zone.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité crue", "Si tu devais choisir un seul acte sexuel à recevoir maintenant, lequel serait-ce ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action extrême", "Choisis entre : oral, mains, sextoy, position Kama ou masturbation mutuelle. Ton/ta partenaire peut accepter, remplacer ou passer.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité crue", "Est-ce que le fait d’être regardé(e) pendant que tu prends du plaisir t’excite ou te gêne ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Action extrême", "L’un donne du plaisir à l’autre pendant 60 secondes tout en maintenant le contact visuel autant que c’est confortable.", ""),
            CuratedCard(CardKind.QUESTION, 5, "Vérité crue", "Quelle demande sexuelle très directe aimerais-tu me faire ce soir si tu savais que je ne te jugerais pas ?", ""),
            CuratedCard(CardKind.CHALLENGE, 5, "Finale extrême", "Chacun choisit une envie sexuelle réellement acceptable ce soir. Si elles sont compatibles, combinez-les en une finale de cinq minutes. Sinon, choisissez ensemble celle qui vous tente le plus.", "Tout peut être ralenti, modifié ou arrêté à tout moment.")
        )
    )

    private val destinyCards = listOf(
        CuratedCard(CardKind.DESTINY, 1, "Joker", "La prochaine carte peut être remplacée une fois sans justification."),
        CuratedCard(CardKind.DESTINY, 1, "Inversion", "Pour la prochaine action, inversez celui/celle qui donne et celui/celle qui reçoit."),
        CuratedCard(CardKind.DESTINY, 2, "Double choix", "Tirez deux cartes et choisissez ensemble celle que vous préférez."),
        CuratedCard(CardKind.DESTINY, 2, "Partenaire choisit", "La prochaine fois, ton/ta partenaire choisit entre deux cartes proposées."),
        CuratedCard(CardKind.DESTINY, 2, "60 secondes", "La prochaine action dure exactement 60 secondes."),
        CuratedCard(CardKind.DESTINY, 3, "Sans parler", "La prochaine action se joue sans parler, sauf pour dire stop ou ralentir."),
        CuratedCard(CardKind.DESTINY, 3, "Encore", "Rejouez une carte que vous avez aimée pendant cette partie."),
        CuratedCard(CardKind.DESTINY, 3, "À ton rythme", "La personne qui reçoit choisit entièrement le rythme de la prochaine action."),
        CuratedCard(CardKind.DESTINY, 4, "Choix secret", "Chacun décide en secret : jouer / adoucir / passer. Révélez en même temps."),
        CuratedCard(CardKind.DESTINY, 4, "Position Kama", "La prochaine carte peut être remplacée par une position de la bibliothèque Kamasutra.")
    )

    private val memoryTemplates = listOf(
        "Racontez chacun votre version de : %s. Commencez par le détail que l’autre a probablement oublié.",
        "À propos de : %s, chacun dit d’abord l’émotion principale ressentie à ce moment-là.",
        "Pour : %s, choisissez le moment exact où vous vous êtes sentis le plus équipe.",
        "À partir de : %s, dites chacun ce que vous aimeriez revivre presque à l’identique.",
        "À propos de : %s, dites le détail le plus tendre, drôle ou surprenant."
    )

    private val positions = listOf(
        SecretPosition(
            "Missionnaire classique", 1, "Face à face",
            "Position face à face : une personne est allongée sur le dos, l’autre se place au-dessus.",
            "La personne qui reçoit s’allonge sur le dos. L’autre se place entre ses jambes et garde ses appuis sur les genoux, les mains ou les avant-bras.",
            "Très simple à installer • Beaucoup de contact visuel • Facile à ralentir ou interrompre",
            "La personne au-dessus porte une partie de son poids • L’angle peut sembler limité",
            "Pour le confort, éviter de faire reposer tout le poids sur le partenaire. Un coussin ferme sous le bassin permet de modifier légèrement l’angle.",
            0,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Wiki-missionary.png",
            "Seedfeeder", "CC BY-SA 3.0", "https://commons.wikimedia.org/wiki/File:Wiki-missionary.png"
        ),
        SecretPosition(
            "Assise face à face", 2, "Assis",
            "Les partenaires sont assis face à face, très proches, avec les bassins alignés dans une position simple et visuelle.",
            "Une personne s’assoit avec un appui stable. L’autre s’installe face à elle, à cheval sur son bassin, puis les deux se rapprochent en gardant le dos relâché.",
            "Beaucoup de proximité • Bon contact visuel • Rythme lent et facile à ajuster",
            "Amplitude plus réduite • Peut demander un bon appui au dos ou aux cuisses",
            "S’adosser à un canapé, une tête de lit ou un mur améliore nettement le confort. Inutile de croiser parfaitement les jambes : l’important est la stabilité.",
            1,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Sex%20position%20-%20sitting%201.png",
            "Sciencia58", "CC0 1.0", "https://commons.wikimedia.org/wiki/File:Sex_position_-_sitting_1.png"
        ),
        SecretPosition(
            "Huître viennoise", 4, "Face à face",
            "Variante du missionnaire où les jambes de la personne allongée sont fortement relevées vers le haut du corps.",
            "La personne qui reçoit reste sur le dos et relève les jambes vers le torse. L’autre reste au-dessus en gardant des appuis solides.",
            "Angle très différent du missionnaire classique • Position compacte • Le partenaire au-dessus contrôle facilement le mouvement",
            "Demande beaucoup de mobilité des hanches • Peut tirer sur le bas du dos ou l’arrière des jambes",
            "Ne jamais forcer les jambes vers le torse. Garder les genoux moins hauts est une variante nettement plus accessible.",
            2,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Wiki-Wiener-auster.png",
            "Seedfeeder", "CC BY-SA 3.0", "https://commons.wikimedia.org/wiki/File:Wiki-Wiener-auster.png"
        ),
        SecretPosition(
            "Chevauchement (cowgirl)", 2, "Dessus",
            "Une personne reste allongée sur le dos pendant que l’autre la chevauche en lui faisant face.",
            "La personne du dessous s’allonge. La personne du dessus s’installe à califourchon, genoux de chaque côté du bassin, puis choisit son inclinaison.",
            "La personne du dessus contrôle facilement rythme et amplitude • Bon contact visuel • Facile à ajuster",
            "Peut fatiguer les cuisses ou les genoux • Les mouvements trop brusques sont moins confortables",
            "Privilégier les mouvements de bassin plutôt que de monter et descendre très haut. Se pencher en avant réduit souvent l’effort.",
            3,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Wiki-cowgirl.png",
            "Seedfeeder", "CC BY-SA 3.0", "https://commons.wikimedia.org/wiki/File:Wiki-cowgirl.png"
        ),
        SecretPosition(
            "Lotus", 2, "Assis",
            "Les deux partenaires sont assis face à face, très proches, l’un installé sur le bassin de l’autre.",
            "Une personne s’assoit avec des appuis stables. L’autre s’installe face à elle, autour de son bassin, puis les deux se rapprochent.",
            "Contact corps à corps important • Très bon contact visuel • Convient bien à un rythme lent",
            "Amplitude de mouvement plus réduite • Peut demander de la souplesse des hanches",
            "S’adosser à une tête de lit ou un canapé peut rendre la position beaucoup plus confortable. Les jambes n’ont pas besoin d’être parfaitement croisées.",
            4,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Wiki-sitting-sp.png",
            "Seedfeeder", "CC BY-SA 3.0", "https://commons.wikimedia.org/wiki/File:Wiki-sitting-sp.png"
        ),
        SecretPosition(
            "Cuillère", 1, "Côté",
            "Les deux partenaires sont couchés sur le côté dans la même direction, l’un derrière l’autre.",
            "Allongez-vous tous les deux sur le même côté. La personne derrière se rapproche du bassin de la personne devant tout en gardant les jambes confortablement fléchies.",
            "Très peu fatigante • Beaucoup de contact du corps • Facile à maintenir longtemps",
            "Peu de contact visuel • L’angle peut être difficile selon les morphologies",
            "Décaler légèrement les bassins ou relever la jambe supérieure de la personne devant peut faciliter l’alignement.",
            5,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Wiki-spoons-sp.png",
            "Seedfeeder", "CC BY-SA 3.0", "https://commons.wikimedia.org/wiki/File:Wiki-spoons-sp.png"
        ),
        SecretPosition(
            "T-square", 2, "Côté",
            "Les corps forment approximativement un T : une personne est allongée et l’autre se place perpendiculairement à son bassin.",
            "Une personne reste sur le dos ou légèrement de côté. L’autre s’allonge ou s’agenouille perpendiculairement, au niveau de son bassin.",
            "Position stable • Change nettement l’angle • Peu de poids porté par le partenaire",
            "Moins de proximité du haut du corps • Demande de trouver précisément la bonne hauteur de bassin",
            "Utiliser un coussin pour aligner les bassins si nécessaire. Installer la position avant de commencer les mouvements évite les torsions inutiles.",
            6,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Wiki-T-square.png",
            "Seedfeeder", "CC BY-SA 3.0", "https://commons.wikimedia.org/wiki/File:Wiki-T-square.png"
        ),
        SecretPosition(
            "Flanquette", 2, "Côté",
            "Position latérale asymétrique : une personne est principalement sur le côté tandis que l’autre se place près de son bassin.",
            "La personne qui reçoit s’allonge sur le côté en gardant une jambe plus ouverte. L’autre se place près du bassin selon l’orientation visible sur l’illustration.",
            "Angle original sans position acrobatique • Appuis relativement simples • Bonne alternative aux positions frontales",
            "Placement moins intuitif au début • Peut nécessiter plusieurs petits ajustements",
            "Reproduire d’abord les appuis de l’illustration sans chercher de mouvement. Une fois l’alignement confortable, commencer doucement.",
            7,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Flanquette%20-%20Sexposition%201.png",
            "Sciencia58", "CC0 1.0", "https://commons.wikimedia.org/wiki/File:Flanquette_-_Sexposition_1.png"
        ),
        SecretPosition(
            "Coït latéral", 2, "Côté",
            "Position latérale décrite par Masters et Johnson, avec les partenaires partiellement emboîtés sur le côté.",
            "Les partenaires se placent de côté, jambes disposées comme sur l’illustration afin de rapprocher les bassins sans superposer complètement les corps.",
            "Répartit bien le poids • Position relativement stable • Permet des mouvements courts et précis",
            "Mise en place moins évidente que la cuillère • L’orientation des jambes peut demander un peu d’habitude",
            "Prendre le temps de placer les jambes avant de rapprocher les bassins. Si une hanche tire, revenir à une position latérale plus simple.",
            8,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Wiki-lcp.png",
            "Seedfeeder", "CC BY-SA 3.0", "https://commons.wikimedia.org/wiki/File:Wiki-lcp.png"
        ),
        SecretPosition(
            "Levrette classique", 2, "Arrière",
            "Une personne est à quatre appuis tandis que l’autre se place derrière, à genoux.",
            "La personne devant prend appui sur les mains et les genoux. La personne derrière s’agenouille et rapproche son bassin sans tirer sur le partenaire.",
            "Placement facile à comprendre • Bon contrôle du rythme pour la personne derrière • Angle modulable",
            "Peu de contact visuel • Peut fatiguer poignets, épaules ou genoux",
            "Passer sur les avant-bras ou ajouter des coussins sous les genoux si nécessaire. Commencer avec une amplitude courte.",
            9,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Wiki-dstyle.png",
            "Seedfeeder", "CC BY-SA 3.0", "https://commons.wikimedia.org/wiki/File:Wiki-dstyle.png"
        ),
        SecretPosition(
            "Arrière allongé (à plat ventre)", 2, "Arrière",
            "Variante arrière où la personne qui reçoit reste allongée sur le ventre plutôt qu’à quatre pattes.",
            "La personne devant s’allonge sur le ventre. L’autre se place derrière ou au-dessus en gardant son poids sur ses propres appuis.",
            "Très stable • Moins fatigante pour les bras de la personne allongée • Position compacte",
            "Peu de contact visuel • Angle plus fermé • Peut être inconfortable si trop de poids repose sur le dos",
            "Un petit coussin sous le bassin peut aider. La personne au-dessus doit garder ses appuis plutôt que d’écraser le partenaire.",
            10,
            "https://commons.wikimedia.org/wiki/Special:FilePath/A%20tergo%20-%20doggy%20style%20-%20lying%20sex%20position.png",
            "Sciencia58", "CC0 1.0", "https://commons.wikimedia.org/wiki/File:A_tergo_-_doggy_style_-_lying_sex_position.png"
        ),
        SecretPosition(
            "Ekiben (porté face à face)", 5, "Debout",
            "Une personne reste debout et porte l’autre face à elle, comme le montre l’illustration.",
            "La personne porteuse reste debout avec les pieds bien ancrés. L’autre est soutenue dans ses bras et rapproche ses jambes autour du bassin.",
            "Contact face à face très proche • Position dynamique • Peut être utilisée brièvement comme transition",
            "Très exigeante en force et en équilibre • Risque de chute si les appuis sont mauvais",
            "À réserver aux couples capables de porter le poids sans effort excessif. Un mur solide derrière le partenaire porté peut ajouter de la stabilité.",
            11,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Wiki-standing.png",
            "Seedfeeder", "CC BY-SA 3.0", "https://commons.wikimedia.org/wiki/File:Wiki-standing.png"
        ),
        SecretPosition(
            "69 allongé", 2, "Oral",
            "Les partenaires sont allongés tête-bêche pour permettre une stimulation orale mutuelle.",
            "L’un s’allonge, l’autre se place en sens inverse au-dessus ou légèrement sur le côté afin que chacun ait accès au bassin de l’autre.",
            "Stimulation mutuelle • Position connue et facile à identifier • Peut se faire sur le côté pour plus de confort",
            "Coordination parfois difficile • Peut être moins relaxant si les deux veulent se concentrer en même temps",
            "La variante sur le côté réduit la fatigue. Il est aussi possible d’alterner plutôt que de tout faire simultanément.",
            12,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Wiki-sixtynine.png",
            "Seedfeeder", "CC BY-SA 3.0", "https://commons.wikimedia.org/wiki/File:Wiki-sixtynine.png"
        ),
        SecretPosition(
            "Reverse Ekiben", 5, "Debout",
            "Position portée où la personne qui reçoit tourne le dos à la personne qui la tient.",
            "La personne porteuse reste debout et soutient le partenaire devant elle. Le partenaire porté est orienté dans la même direction, dos contre le torse de l’autre.",
            "Angle très différent • Position inhabituelle et très physique",
            "Très fatigante • Demande beaucoup de force et d’équilibre • Peu adaptée à une longue durée",
            "L’illustration est utile surtout pour comprendre les appuis. Ne pas tenter si le partenaire ne peut pas être porté de façon stable et confortable.",
            13,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Reverse%20ekiben%201.png",
            "Sciencia58", "CC0 1.0", "https://commons.wikimedia.org/wiki/File:Reverse_ekiben_1.png"
        ),
        SecretPosition(
            "Seventh Posture (leg glider)", 3, "Avancé",
            "Position dite « Seventh Posture » ou « leg glider », présentée dans une illustration moderne dédiée.",
            "Reproduire d’abord l’orientation des corps et de la jambe visible sur l’illustration, puis rapprocher les bassins seulement lorsque les appuis sont stables.",
            "Variante originale • Offre un angle asymétrique • Ne nécessite pas d’être debout",
            "Moins intuitive à installer • Peut demander de la mobilité des hanches",
            "Ne pas chercher à reproduire une amplitude exacte : la priorité est que les hanches et les genoux restent dans une position naturelle.",
            14,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Seventh%20Posture.png",
            "Dronebogus", "CC BY 4.0", "https://commons.wikimedia.org/wiki/File:Seventh_Posture.png"
        ),
        SecretPosition(
            "Piledriver", 5, "Avancé",
            "La personne qui reçoit est sur le dos, bassin relevé et jambes très hautes, tandis que l’autre se place au-dessus.",
            "La personne allongée ramène les jambes vers le haut et relève le bassin. L’autre se place au-dessus comme sur l’illustration en gardant le contrôle de son propre poids.",
            "Angle très marqué • Position nettement différente des variantes classiques",
            "Très exigeante en souplesse • Forte charge sur le haut du dos • Inadaptée en cas d’inconfort cervical ou dorsal",
            "Ne jamais faire porter le poids sur le cou. Garder une version partiellement relevée est préférable si la position complète tire ou comprime.",
            15,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Piledriver%20Sex%20Position%20V2-Front.jpg",
            "Javadst", "CC BY 4.0", "https://commons.wikimedia.org/wiki/File:Piledriver_Sex_Position_V2-Front.jpg"
        ),
        SecretPosition(
            "Assise croisée", 3, "Assis",
            "Variante assise où les partenaires restent très proches mais avec une disposition des jambes différente, pour modifier l’angle et les appuis.",
            "Une personne s’assoit avec des appuis stables. L’autre vient s’installer face à elle selon l’orientation de l’illustration, en ajustant d’abord les jambes puis le rapprochement des bassins.",
            "Illustration claire • Bon compromis entre proximité et variation • Intéressante pour changer du lotus classique",
            "Peut demander quelques essais de placement • Le confort dépend beaucoup de l’appui du dos et des hanches",
            "Installer la position lentement et ne pas chercher à imiter exactement chaque angle si cela tire. Un appui stable derrière le dos change souvent tout.",
            16,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Sex%20position%20-%20sitting%202.png",
            "Sciencia58", "CC BY-SA 4.0", "https://commons.wikimedia.org/wiki/File:Sex_position_-_sitting_2.png"
        )
    )
    fun positionById(poseId:Int): SecretPosition? = positions.firstOrNull { it.poseId == poseId }
    fun secretPositions(): List<SecretPosition> = positions

    fun intensityWord(intensity:Int):String = when(intensity.coerceIn(1,5)){
        1 -> "très doux"
        2 -> "doux"
        3 -> "intense"
        4 -> "très intense"
        else -> "extrême"
    }

    private fun effectiveIntensity(mode: GameMode, selected: Int): Int {
        val i = selected.coerceIn(1,5)
        return when(mode){
            GameMode.SECRET -> i.coerceAtLeast(4)
            GameMode.EXTREME -> 5
            else -> i
        }
    }

    private fun candidates(mode: GameMode, kind: CardKind, selectedIntensity: Int): List<CuratedCard> {
        val target = effectiveIntensity(mode, selectedIntensity)
        val all = modeCards.getValue(mode).filter { it.kind == kind }
        if (all.isEmpty()) return emptyList()
        val close = all.filter { it.intensity in (target - 1).coerceAtLeast(1)..target }
        return if (close.isNotEmpty()) close else all.filter { it.intensity <= target }.ifEmpty { all }
    }

    fun chooseKind(mode:GameMode, round:Int, memories:List<String>):CardKind {
        val hasMemory = memories.any { it.isNotBlank() }
        if ((mode == GameMode.SECRET || mode == GameMode.EXTREME) && round % 4 == 0) return CardKind.SECRET_POSITION
        if (hasMemory && round % 7 == 0 && !mode.adultOnly) return CardKind.MEMORY
        val r = Random.nextInt(100)
        return when(mode) {
            GameMode.RELAX -> if (r < 50) CardKind.QUESTION else if (r < 92) CardKind.CHALLENGE else CardKind.DESTINY
            GameMode.FUN -> if (r < 42) CardKind.QUESTION else if (r < 92) CardKind.CHALLENGE else CardKind.DESTINY
            GameMode.ROMANTIC -> if (r < 52) CardKind.QUESTION else if (r < 92) CardKind.CHALLENGE else CardKind.DESTINY
            GameMode.HOT -> if (r < 42) CardKind.QUESTION else if (r < 94) CardKind.CHALLENGE else CardKind.DESTINY
            GameMode.SECRET -> if (r < 38) CardKind.QUESTION else if (r < 92) CardKind.CHALLENGE else CardKind.DESTINY
            GameMode.EXTREME -> if (r < 34) CardKind.QUESTION else if (r < 96) CardKind.CHALLENGE else CardKind.DESTINY
        }
    }

    fun challenge(mode:GameMode, intensity:Int, actionRoll:Int, zoneRoll:Int):GameCard =
        specialCard(CardKind.CHALLENGE, mode, intensity, emptyList())

    fun specialCard(kind:CardKind, mode:GameMode, intensity:Int, memories:List<String>):GameCard = when(kind) {
        CardKind.MEMORY -> {
            val memory = memories.filter { it.isNotBlank() }.randomOrNull() ?: "un de vos meilleurs souvenirs"
            GameCard(kind, "Souvenir de nous", memoryTemplates.random().format(memory), intensity = 1)
        }
        CardKind.SECRET_POSITION -> {
            val maxDifficulty = when(mode){
                GameMode.EXTREME -> 5
                GameMode.SECRET -> effectiveIntensity(mode, intensity)
                else -> intensity.coerceIn(1,5)
            }
            val eligible = positions.filter { it.difficulty <= maxDifficulty }.ifEmpty { positions }
            val p = eligible.random()
            GameCard(
                kind, "Position Kamasutra", p.name,
                "${p.category} · difficulté ${p.difficulty}/5\n${p.description}\nRegardez l’illustration, adaptez les appuis et passez si la position ne vous convient pas.",
                false, p.poseId, p.difficulty
            )
        }
        CardKind.DESTINY -> destinyCards.filter { it.intensity <= effectiveIntensity(mode, intensity) }.ifEmpty { destinyCards }.random().toGameCard()
        CardKind.CHALLENGE, CardKind.QUESTION -> candidates(mode, kind, intensity).random().toGameCard()
        CardKind.SITUATION, CardKind.TENTATION -> candidates(mode, CardKind.CHALLENGE, intensity).random().toGameCard()
    }

    private fun CuratedCard.toGameCard() = GameCard(kind, title, text, detail, canSave, -1, intensity)

    fun contentStats(): Map<String,Int> {
        val all = modeCards.values.flatten()
        return mapOf(
            "questions" to all.count { it.kind == CardKind.QUESTION },
            "challenges" to all.count { it.kind == CardKind.CHALLENGE },
            "destiny" to destinyCards.size,
            "memories" to memoryTemplates.size,
            "positions" to positions.size,
            "extreme" to modeCards.getValue(GameMode.EXTREME).size,
            "total_curated" to (all.size + destinyCards.size + memoryTemplates.size + positions.size)
        )
    }
}
