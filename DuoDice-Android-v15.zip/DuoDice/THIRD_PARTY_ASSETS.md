# DuoDice v15 — Wikimedia assets

All position illustrations are fetched from Wikimedia Commons during the GitHub build and embedded in the APK.

## Modern instructional illustrations
- `Wiki-missionary.png` — Seedfeeder — CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Wiki-missionary.png
- `Sex position - sitting 1.png` — Sciencia58 — CC0 1.0 — https://commons.wikimedia.org/wiki/File:Sex_position_-_sitting_1.png
- `Wiki-Wiener-auster.png` — Seedfeeder — CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Wiki-Wiener-auster.png
- `Wiki-cowgirl.png` — Seedfeeder — CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Wiki-cowgirl.png
- `Wiki-sitting-sp.png` — Seedfeeder — CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Wiki-sitting-sp.png
- `Wiki-spoons-sp.png` — Seedfeeder — CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Wiki-spoons-sp.png
- `Wiki-T-square.png` — Seedfeeder — CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Wiki-T-square.png
- `Flanquette - Sexposition 1.png` — Sciencia58 — CC0 1.0 — https://commons.wikimedia.org/wiki/File:Flanquette_-_Sexposition_1.png
- `Wiki-lcp.png` — Seedfeeder — CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Wiki-lcp.png
- `Wiki-dstyle.png` — Seedfeeder — CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Wiki-dstyle.png
- `A tergo - doggy style - lying sex position.png` — Sciencia58 — CC0 1.0 — https://commons.wikimedia.org/wiki/File:A_tergo_-_doggy_style_-_lying_sex_position.png
- `Wiki-standing.png` — Seedfeeder — CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Wiki-standing.png
- `Wiki-sixtynine.png` — Seedfeeder — CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Wiki-sixtynine.png
- `Reverse ekiben 1.png` — Sciencia58 — CC0 1.0 — https://commons.wikimedia.org/wiki/File:Reverse_ekiben_1.png
- `Seventh Posture.png` — Dronebogus — CC BY 4.0 — https://commons.wikimedia.org/wiki/File:Seventh_Posture.png
- `Piledriver Sex Position V2-Front.jpg` — Javadst — CC BY 4.0 — https://commons.wikimedia.org/wiki/File:Piledriver_Sex_Position_V2-Front.jpg
- `Sex position - sitting 2.png` — Sciencia58 — CC BY-SA 4.0 — https://commons.wikimedia.org/wiki/File:Sex_position_-_sitting_2.png
