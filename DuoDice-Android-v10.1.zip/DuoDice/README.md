# DuoDice v9 — Big Content Edition

## Contenu
- 400 questions réparties entre général, Fun, Romantique et Extra Hot
- 240 situations/scénarios
- 365 défis directs
- 120 cartes Tentation
- 50 événements Roue du destin
- 30 formulations Souvenirs
- 79 positions/variantes Kama Sutra
- plus des formats de réponse, durées et règles secondaires

Total : 1 284 entrées directes avant les variantes de format.

## Nouveautés v9
- Nouveau type de carte Situation
- Anti-répétition sur les 35 dernières cartes
- Intensité qui modifie réellement le contenu disponible
- Bibliothèque Kama Sutra privée dans le Mode Secret
- Filtres de difficulté 1 à 4
- Silhouettes stylisées intégrées dans l'application
- Le Mode Secret reste protégé par confirmation 18+ + PIN
- Les données restent locales et hors ligne

Les noms des positions varient selon les sources : la bibliothèque regroupe les positions courantes et leurs variantes plutôt que de prétendre à une liste universelle officielle.


## Version v10 XXL

- Refonte éditoriale des contenus Duo Quest : cartes plus écrites, moins génériques, avec vraie montée en intensité.
- Base de contenu restructurée par mode (Détente, Fun, Romantique, Extra Hot, Secret).
- Bibliothèque Secret enrichie avec 24 positions guidées, conseils de mise en place et illustrations stylisées plus lisibles.
- Pondération des cartes par phase de partie et niveau d'intensité.
- Conserve le mode libre à deux dés et le rendu 3D existant.
