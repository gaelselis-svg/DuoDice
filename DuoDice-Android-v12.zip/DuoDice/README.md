# DuoDice v11 — Real Content Edition

Application Android native en Kotlin + Jetpack Compose.

## Ce qui change réellement dans la v11

- Les défis Duo Quest ne sont plus fabriqués par assemblage aléatoire « action + zone ».
- 407 cartes de jeu écrites individuellement : questions, défis, situations et Tentations.
- 15 événements / wildcards, 8 formats souvenirs.
- Mode Secret : 105 cartes adultes dédiées, niveaux 3 à 5 uniquement.
- 32 positions guidées avec 32 illustrations PNG distinctes, et non une poignée de silhouettes recyclées.
- Chaque fiche position peut être ouverte en grand avec description et conseils d'appui.
- Anti-répétition de session porté à 60 cartes récentes.
- Mode libre classique à deux dés conservé.

## Contenu

- Détente : 68 cartes
- Fun : 73 cartes
- Romantique : 78 cartes
- Extra Hot : 83 cartes
- Secret : 105 cartes
- Destin / Wildcards : 15
- Souvenirs : 8 formats
- Positions : 32
- Total éditorial intégré : 462 éléments

Le contenu est original. Les produits et guides externes ont servi uniquement de benchmark pour les mécaniques (progression, réponses privées, niveaux, fiches de positions), pas de source à copier.

## Build

- Android API 35
- minSdk 26
- AGP 8.7.3
- Kotlin 2.0.21
- Compose

Le workflow GitHub fourni construit `DuoDice-v11.apk`.


## v12 – Real Assets + Deep Content
- Remplacement des illustrations internes par des illustrations réellement publiées sur Wikimedia Commons sous CC0 / CC BY-SA.
- Crédit et licence affichés dans les fiches de positions.
- 14 positions externes distinctes, chacune liée à son illustration dédiée.
- Nouveau bloc de contenu rédigé carte par carte avec mécaniques de compatibilité Oui/Peut-être/Non, réponses simultanées, devinettes, scénarios à choix, contrôle partagé et progression.
- Aucune construction de défi par assemblage action + zone dans ce nouveau contenu.
