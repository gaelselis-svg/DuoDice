# DuoDice v12 – illustrations externes

Les illustrations de positions ne sont plus générées par DuoDice. Elles sont chargées depuis Wikimedia Commons et chaque fiche affiche le crédit et la licence.

## CC BY-SA 3.0 – Seedfeeder
- Wiki-missionary.png
- Wiki-spoons-sp.png
- Wiki-sitting-sp.png
- Wiki-cowgirl.png
- Wiki-lcp.png
- Wiki-dstyle.png
- Wiki-T-square.png
- Wiki-Wiener-auster.png
- Wiki-standing.png

Licence : https://creativecommons.org/licenses/by-sa/3.0/
Auteur : Seedfeeder. Source : Wikimedia Commons.

## CC0 1.0 – Sciencia58
- A tergo - doggy style - lying sex position.png
- Flanquette - Sexposition 1.png
- Vaginal intercourse - Rocking 1.png
- Sex position - sitting 1.png

Licence : https://creativecommons.org/publicdomain/zero/1.0/
Auteur : Sciencia58. Source : Wikimedia Commons.

## CC BY-SA 4.0 – Sciencia58
- Sex position - sitting 2.png

Licence : https://creativecommons.org/licenses/by-sa/4.0/
Auteur : Sciencia58. Source : Wikimedia Commons.

Les URL de la page source et la licence correspondante sont aussi conservées dans GameData.kt.
