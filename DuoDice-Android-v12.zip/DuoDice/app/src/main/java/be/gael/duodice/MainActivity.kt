package be.gael.duodice

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import coil.compose.SubcomposeAsyncImage
import coil.compose.SubcomposeAsyncImageContent
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DuoDiceApp() }
    }
}

private enum class Screen { HOME, QUEST, CLASSIC, SETTINGS }

private data class Palette(
    val accent: Color,
    val accent2: Color,
    val backgroundTop: Color,
    val backgroundBottom: Color,
    val surface: Color
)

private fun paletteFor(mode: GameMode): Palette = when (mode) {
    GameMode.RELAX -> Palette(
        accent = Color(0xFF78E6D0),
        accent2 = Color(0xFF79B9FF),
        backgroundTop = Color(0xFF071B1D),
        backgroundBottom = Color(0xFF081018),
        surface = Color(0xFF102529)
    )
    GameMode.FUN -> Palette(
        accent = Color(0xFFFF7BBD),
        accent2 = Color(0xFFFFC857),
        backgroundTop = Color(0xFF261126),
        backgroundBottom = Color(0xFF101022),
        surface = Color(0xFF2B1730)
    )
    GameMode.ROMANTIC -> Palette(
        accent = Color(0xFFFF8DA1),
        accent2 = Color(0xFFFFD08A),
        backgroundTop = Color(0xFF2A0E18),
        backgroundBottom = Color(0xFF120B12),
        surface = Color(0xFF2B151D)
    )
    GameMode.HOT -> Palette(
        accent = Color(0xFFFF5D68),
        accent2 = Color(0xFFB868FF),
        backgroundTop = Color(0xFF26080D),
        backgroundBottom = Color(0xFF09070D),
        surface = Color(0xFF2B1015)
    )
    GameMode.SECRET -> Palette(
        accent = Color(0xFFFFD36A),
        accent2 = Color(0xFFFF7D7D),
        backgroundTop = Color(0xFF1D1708),
        backgroundBottom = Color(0xFF070707),
        surface = Color(0xFF211D13)
    )
}

@Composable
private fun DuoDiceApp() {
    val context = LocalContext.current
    val prefs = remember { DicePrefs(context) }

    var screen by remember { mutableStateOf(Screen.HOME) }
    var selectedMode by remember { mutableStateOf(GameMode.ROMANTIC) }
    var questMode by remember { mutableStateOf(GameMode.ROMANTIC) }
    var intensity by remember { mutableIntStateOf(2) }
    var rounds by remember { mutableIntStateOf(10) }

    var secretEnabled by remember { mutableStateOf(prefs.secretEnabled()) }
    var adultConfirmed by remember { mutableStateOf(prefs.adultConfirmed()) }
    var secretPin by remember { mutableStateOf(prefs.secretPin()) }
    var showSecretDialog by remember { mutableStateOf(false) }
    var pinAttempt by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }
    var titleTaps by remember { mutableIntStateOf(0) }

    var actionSides by remember { mutableIntStateOf(prefs.getSides("action")) }
    var bodySides by remember { mutableIntStateOf(prefs.getSides("body")) }
    var actionLabels by remember { mutableStateOf(prefs.loadLabels("action", actionSides)) }
    var bodyLabels by remember { mutableStateOf(prefs.loadLabels("body", bodySides)) }
    var memories by remember { mutableStateOf(prefs.memories()) }

    val visualMode = if (screen == Screen.QUEST) questMode else selectedMode
    val palette = paletteFor(visualMode)
    val scheme = darkColorScheme(
        primary = palette.accent,
        secondary = palette.accent2,
        surface = palette.surface,
        background = palette.backgroundBottom
    )

    MaterialTheme(colorScheme = scheme) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(palette.backgroundTop, palette.backgroundBottom)
                    )
                )
        ) {
            Scaffold(containerColor = Color.Transparent) { innerPadding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(horizontal = 16.dp)
                ) {
                    Spacer(Modifier.height(12.dp))
                    AppHeader(
                        screen = screen,
                        palette = palette,
                        onTitleTap = {
                            titleTaps++
                            if (titleTaps >= 5) {
                                titleTaps = 0
                                if (secretEnabled && adultConfirmed) {
                                    pinAttempt = ""
                                    pinError = false
                                    showSecretDialog = true
                                }
                            }
                        },
                        onHome = { screen = Screen.HOME },
                        onClassic = { screen = Screen.CLASSIC },
                        onSettings = { screen = Screen.SETTINGS }
                    )
                    Spacer(Modifier.height(12.dp))

                    when (screen) {
                        Screen.HOME -> HomeScreen(
                            selectedMode = selectedMode,
                            intensity = intensity,
                            rounds = rounds,
                            palette = palette,
                            adultConfirmed = adultConfirmed,
                            onMode = { selectedMode = it },
                            onIntensity = { intensity = it },
                            onRounds = { rounds = it },
                            onStart = {
                                questMode = selectedMode
                                screen = Screen.QUEST
                            }
                        )

                        Screen.QUEST -> QuestScreen(
                            mode = questMode,
                            intensity = intensity,
                            totalRounds = rounds,
                            memories = memories,
                            palette = palette,
                            onExit = { screen = Screen.HOME }
                        )

                        Screen.CLASSIC -> ClassicGameScreen(
                            actionSides = actionSides,
                            bodySides = bodySides,
                            actionLabels = actionLabels,
                            bodyLabels = bodyLabels,
                            palette = palette
                        )

                        Screen.SETTINGS -> SettingsScreen(
                            prefs = prefs,
                            actionSides = actionSides,
                            bodySides = bodySides,
                            actionLabels = actionLabels,
                            bodyLabels = bodyLabels,
                            secretEnabled = secretEnabled,
                            adultConfirmed = adultConfirmed,
                            secretPin = secretPin,
                            memories = memories,
                            onActionSidesChange = { sides ->
                                actionSides = sides
                                prefs.setSides("action", sides)
                                actionLabels = prefs.loadLabels("action", sides)
                            },
                            onBodySidesChange = { sides ->
                                bodySides = sides
                                prefs.setSides("body", sides)
                                bodyLabels = prefs.loadLabels("body", sides)
                            },
                            onActionLabelChange = { index, value ->
                                actionLabels = actionLabels.toMutableList().also { it[index] = value }
                                prefs.saveLabel("action", actionSides, index + 1, value)
                            },
                            onBodyLabelChange = { index, value ->
                                bodyLabels = bodyLabels.toMutableList().also { it[index] = value }
                                prefs.saveLabel("body", bodySides, index + 1, value)
                            },
                            onSecretEnabled = {
                                secretEnabled = it
                                prefs.setSecretEnabled(it)
                            },
                            onAdultConfirmed = {
                                adultConfirmed = it
                                prefs.setAdultConfirmed(it)
                                if (!it) {
                                    secretEnabled = false
                                    prefs.setSecretEnabled(false)
                                }
                            },
                            onSecretPin = {
                                val clean = it.filter(Char::isDigit).take(4)
                                secretPin = clean
                                if (clean.length == 4) prefs.setSecretPin(clean)
                            },
                            onMemoryChange = { index, value ->
                                memories = memories.toMutableList().also { it[index] = value }
                                prefs.setMemory(index, value)
                            }
                        )
                    }
                }
            }
        }
    }

    if (showSecretDialog) {
        AlertDialog(
            onDismissRequest = { showSecretDialog = false },
            title = { Text("Mode Secret") },
            text = {
                Column {
                    Text("Entre ton code à 4 chiffres.")
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = pinAttempt,
                        onValueChange = {
                            pinAttempt = it.filter(Char::isDigit).take(4)
                            pinError = false
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        isError = pinError,
                        label = { Text("Code") }
                    )
                    if (pinError) {
                        Text("Code incorrect.", color = MaterialTheme.colorScheme.error)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (pinAttempt == secretPin && secretPin.length == 4) {
                            showSecretDialog = false
                            questMode = GameMode.SECRET
                            intensity = intensity.coerceAtLeast(3)
                            screen = Screen.QUEST
                        } else {
                            pinError = true
                        }
                    }
                ) { Text("Déverrouiller") }
            },
            dismissButton = {
                TextButton(onClick = { showSecretDialog = false }) { Text("Annuler") }
            }
        )
    }
}

@Composable
private fun AppHeader(
    screen: Screen,
    palette: Palette,
    onTitleTap: () -> Unit,
    onHome: () -> Unit,
    onClassic: () -> Unit,
    onSettings: () -> Unit
) {
    Text(
        text = "DuoDice",
        modifier = Modifier.clickable { onTitleTap() },
        fontSize = 30.sp,
        fontWeight = FontWeight.Black
    )
    Text(
        text = if (screen == Screen.QUEST) "Duo Quest" else "Jeu de couple personnalisable",
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Spacer(Modifier.height(10.dp))
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            FilterChip(
                selected = screen == Screen.HOME,
                onClick = onHome,
                label = { Text("Accueil") }
            )
        }
        item {
            FilterChip(
                selected = screen == Screen.CLASSIC,
                onClick = onClassic,
                label = { Text("Mode libre") }
            )
        }
        item {
            FilterChip(
                selected = screen == Screen.SETTINGS,
                onClick = onSettings,
                label = { Text("Réglages") }
            )
        }
    }
}

@Composable
private fun HomeScreen(
    selectedMode: GameMode,
    intensity: Int,
    rounds: Int,
    palette: Palette,
    adultConfirmed: Boolean,
    onMode: (GameMode) -> Unit,
    onIntensity: (Int) -> Unit,
    onRounds: (Int) -> Unit,
    onStart: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            HeroCard(palette)
        }

        item {
            Text("Choisis l'ambiance", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        items(GameMode.entries.filter { it != GameMode.SECRET }) { mode ->
            ModeCard(
                mode = mode,
                selected = selectedMode == mode,
                palette = paletteFor(mode),
                enabled = !mode.adultOnly || adultConfirmed,
                onClick = { onMode(mode) }
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = palette.surface.copy(alpha = 0.88f))
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("Intensité", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items((1..5).toList()) { level ->
                            FilterChip(
                                selected = intensity == level,
                                onClick = { onIntensity(level) },
                                label = { Text("$level") }
                            )
                        }
                    }
                    Text(
                        GameEngine.intensityWord(intensity),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(Modifier.height(14.dp))
                    Text("Durée de la partie", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(listOf(5, 10, 20)) { count ->
                            FilterChip(
                                selected = rounds == count,
                                onClick = { onRounds(count) },
                                label = { Text("$count manches") }
                            )
                        }
                    }
                }
            }
        }

        item {
            Button(
                onClick = onStart,
                enabled = !selectedMode.adultOnly || adultConfirmed,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) {
                Text(
                    if (selectedMode.adultOnly && !adultConfirmed)
                        "Confirme 18+ dans Réglages"
                    else
                        "Démarrer Duo Quest",
                    fontWeight = FontWeight.Bold
                )
            }
        }

        item {
            Text(
                "Pendant la partie : cartes écrites individuellement, situations jouables, questions naturelles, Tentations, événements et souvenirs. Le Mode Secret reste invisible ici.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun HeroCard(palette: Palette) {
    Card(
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = palette.accent.copy(alpha = 0.12f)),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, palette.accent.copy(alpha = 0.42f), RoundedCornerShape(28.dp))
    ) {
        Column(Modifier.padding(20.dp)) {
            Text("DUO QUEST", color = palette.accent, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(6.dp))
            Text(
                "Une partie qui monte progressivement en intensité et évite les répétitions.",
                fontSize = 22.sp,
                fontWeight = FontWeight.Black
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Chaque carte Duo Quest est désormais écrite comme une scène complète : plus de combinaison action + zone qui fabrique une phrase au hasard.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            val stats = GameEngine.contentStats()
            Text(
                "${stats["total_curated"]} contenus éditoriaux · ${stats["positions"]} positions avec une illustration distincte",
                color = palette.accent,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
        }
    }
}

@Composable
private fun ModeCard(
    mode: GameMode,
    selected: Boolean,
    palette: Palette,
    enabled: Boolean,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(22.dp)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (selected) Modifier.border(2.dp, palette.accent, shape)
                else Modifier
            )
            .clickable(enabled = enabled) { onClick() },
        shape = shape,
        colors = CardDefaults.cardColors(
            containerColor = if (selected) palette.surface else palette.surface.copy(alpha = 0.68f)
        )
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(palette.accent.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center
            ) {
                Text(mode.emoji, fontSize = 26.sp, color = palette.accent)
            }
            Spacer(Modifier.size(14.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(mode.title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    if (mode.adultOnly) {
                        Spacer(Modifier.size(8.dp))
                        Text("18+", color = palette.accent, fontWeight = FontWeight.Bold)
                    }
                }
                Text(
                    if (enabled) mode.subtitle else "Active d'abord la confirmation 18+ dans les réglages.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun QuestScreen(
    mode: GameMode,
    intensity: Int,
    totalRounds: Int,
    memories: List<String>,
    palette: Palette,
    onExit: () -> Unit
) {
    val haptic = LocalHapticFeedback.current
    var round by remember(mode, totalRounds) { mutableIntStateOf(1) }
    var card by remember(mode, totalRounds) { mutableStateOf<GameCard?>(null) }
    var rolling by remember(mode, totalRounds) { mutableStateOf(false) }
    var reveal by remember(mode, totalRounds) { mutableStateOf(false) }
    var rollSignal by remember(mode, totalRounds) { mutableIntStateOf(0) }
    var finished by remember(mode, totalRounds) { mutableStateOf(false) }
    val savedTemptations = remember(mode, totalRounds) { mutableStateListOf<GameCard>() }
    var showSaved by remember { mutableStateOf(false) }
    var showKamaLibrary by remember { mutableStateOf(false) }
    val recentCardKeys = remember(mode, totalRounds) { mutableStateListOf<String>() }

    LaunchedEffect(rollSignal) {
        if (rollSignal > 0) {
            delay(1900)
            reveal = true
            rolling = false
        }
    }

    if (finished) {
        QuestFinished(
            mode = mode,
            totalRounds = totalRounds,
            savedCount = savedTemptations.size,
            palette = palette,
            onRestart = {
                round = 1
                card = null
                finished = false
                reveal = false
            },
            onExit = onExit
        )
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = palette.surface.copy(alpha = 0.86f))
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("${mode.emoji} ${mode.title}", fontWeight = FontWeight.Black, color = palette.accent)
                        Text("Manche $round / $totalRounds", fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(10.dp))
                    LinearProgressIndicator(
                        progress = (round - 1).toFloat() / totalRounds.toFloat(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Intensité $intensity/5")
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (mode == GameMode.SECRET) {
                                TextButton(onClick = { showKamaLibrary = true }) { Text("Kama Sutra") }
                            }
                            TextButton(onClick = { showSaved = true }) {
                                Text("Tentations : ${savedTemptations.size}")
                            }
                        }
                    }
                }
            }
        }

        if (card == null) {
            item {
                Card(
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = palette.accent.copy(alpha = 0.10f)),
                    modifier = Modifier.border(
                        1.dp,
                        palette.accent.copy(alpha = 0.32f),
                        RoundedCornerShape(28.dp)
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Prêts pour la manche $round ?", fontSize = 24.sp, fontWeight = FontWeight.Black)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Le jeu choisit entre défi, situation, question, Tentation, événement ou souvenir.",
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(18.dp))
                        Button(
                            onClick = {
                                var candidate: GameCard
                                var attempts = 0
                                do {
                                    val kind = GameEngine.chooseKind(mode, round, memories)
                                    candidate = GameEngine.specialCard(kind, mode, intensity, memories)
                                    attempts++
                                } while (recentCardKeys.contains("${candidate.kind}|${candidate.text}") && attempts < 15)
                                card = candidate
                                recentCardKeys.add("${candidate.kind}|${candidate.text}")
                                while (recentCardKeys.size > 60) recentCardKeys.removeAt(0)
                                reveal = false
                                rolling = true
                                rollSignal++
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                        ) {
                            Text("Lancer la manche", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else {
            item {
                when (card!!.kind) {
                    CardKind.CHALLENGE -> MysteryStage(
                        rollSignal = rollSignal,
                        reveal = reveal,
                        palette = palette,
                        kind = CardKind.CHALLENGE
                    )

                    CardKind.DESTINY -> DestinyStage(
                        rollSignal = rollSignal,
                        reveal = reveal,
                        palette = palette,
                        card = card!!
                    )

                    CardKind.SECRET_POSITION -> SecretPositionStage(
                        card = card!!,
                        rollSignal = rollSignal,
                        reveal = reveal,
                        palette = palette
                    )

                    else -> MysteryStage(
                        rollSignal = rollSignal,
                        reveal = reveal,
                        palette = palette,
                        kind = card!!.kind
                    )
                }
            }

            item {
                AnimatedVisibility(visible = reveal) {
                    ResultCard(
                        card = card!!,
                        palette = palette,
                        onSave = if (card!!.canSave) {
                            {
                                if (!savedTemptations.contains(card!!)) {
                                    savedTemptations.add(card!!)
                                }
                            }
                        } else null
                    )
                }
            }

            if (reveal) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                card = null
                                reveal = false
                                if (round >= totalRounds) finished = true else round++
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Passer")
                        }
                        Button(
                            onClick = {
                                card = null
                                reveal = false
                                if (round >= totalRounds) finished = true else round++
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (round >= totalRounds) "Terminer" else "Défi fait ✓")
                        }
                    }
                }
            }
        }

        item { Spacer(Modifier.height(28.dp)) }
    }

    if (showSaved) {
        AlertDialog(
            onDismissRequest = { showSaved = false },
            title = { Text("Cartes Tentation") },
            text = {
                if (savedTemptations.isEmpty()) {
                    Text("Aucune carte conservée pour le moment.")
                } else {
                    Column {
                        savedTemptations.forEachIndexed { index, item ->
                            Text("${index + 1}. ${item.text}")
                            if (index < savedTemptations.lastIndex) {
                                Spacer(Modifier.height(8.dp))
                                HorizontalDivider()
                                Spacer(Modifier.height(8.dp))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSaved = false }) { Text("Fermer") }
            }
        )
    }
    if (showKamaLibrary) {
        KamaLibraryDialog(palette = palette, onDismiss = { showKamaLibrary = false })
    }

}

@Composable
private fun DestinyStage(
    rollSignal: Int,
    reveal: Boolean,
    palette: Palette,
    card: GameCard
) {
    val angle by animateFloatAsState(
        targetValue = if (reveal) 1480f else if (rollSignal > 0) 720f else 0f,
        animationSpec = tween(1900),
        label = "wheelRotation"
    )
    Card(
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = palette.surface.copy(alpha = 0.90f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("ROUE DU DESTIN", color = palette.accent, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(12.dp))
            Box(contentAlignment = Alignment.TopCenter) {
                Canvas(
                    modifier = Modifier
                        .size(220.dp)
                        .rotate(angle)
                ) {
                    val sweep = 45f
                    repeat(8) { i ->
                        drawArc(
                            color = if (i % 2 == 0) palette.accent else palette.accent2,
                            startAngle = i * sweep,
                            sweepAngle = sweep - 2f,
                            useCenter = true
                        )
                    }
                    drawCircle(
                        color = palette.backgroundBottom,
                        radius = size.minDimension * 0.16f
                    )
                }
                Text("▼", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
            }
            if (!reveal) {
                Text("La roue tourne…", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun SecretPositionStage(
    card: GameCard,
    rollSignal: Int,
    reveal: Boolean,
    palette: Palette
) {
    val position = GameEngine.positionById(card.visualKey)
    Card(
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = palette.surface.copy(alpha = 0.94f)),
        modifier = Modifier.border(1.dp, palette.accent.copy(alpha = 0.5f), RoundedCornerShape(28.dp))
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("MODE SECRET · POSITIONS RÉELLES", color = palette.accent, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(10.dp))
            Box(
                modifier = Modifier.fillMaxWidth().height(255.dp).clip(RoundedCornerShape(22.dp))
                    .background(Color.White),
                contentAlignment = Alignment.Center
            ) {
                if (reveal && position != null) {
                    WikimediaPositionImage(position, Modifier.fillMaxSize().padding(6.dp))
                } else {
                    Text("?", fontSize = 56.sp, fontWeight = FontWeight.Black, color = palette.backgroundBottom.copy(alpha = 0.75f))
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                if (reveal && position != null) "Illustration externe libre · ${position.credit} · ${position.license}" else "Sélection en cours…",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun WikimediaPositionImage(position: SecretPosition, modifier: Modifier = Modifier) {
    SubcomposeAsyncImage(
        model = position.imageUrl,
        contentDescription = "Illustration libre de ${position.name}",
        modifier = modifier.clip(RoundedCornerShape(18.dp)),
        contentScale = ContentScale.Fit,
        loading = {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Chargement de l’illustration…", color = Color.DarkGray, textAlign = TextAlign.Center)
            }
        },
        error = {
            Box(Modifier.fillMaxSize().padding(18.dp), contentAlignment = Alignment.Center) {
                Text(
                    "Illustration Wikimedia indisponible. Vérifiez la connexion Internet.",
                    color = Color.DarkGray,
                    textAlign = TextAlign.Center
                )
            }
        },
        success = { SubcomposeAsyncImageContent() }
    )
}

@Composable
private fun KamaLibraryDialog(palette: Palette, onDismiss: () -> Unit) {
    val positions = remember { GameEngine.secretPositions() }
    var difficulty by remember { mutableIntStateOf(0) }
    var selectedPosition by remember { mutableStateOf<SecretPosition?>(null) }
    val filtered = if (difficulty == 0) positions else positions.filter { it.difficulty == difficulty }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (selectedPosition == null) "Bibliothèque Secret · Positions" else selectedPosition!!.name)
        },
        text = {
            val current = selectedPosition
            if (current == null) {
                Column {
                    Text(
                        "${positions.size} positions guidées · vraies illustrations externes libres · touchez une carte pour l'ouvrir en grand",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        item { FilterChip(selected = difficulty == 0, onClick = { difficulty = 0 }, label = { Text("Toutes") }) }
                        items((1..5).toList()) { d ->
                            FilterChip(selected = difficulty == d, onClick = { difficulty = d }, label = { Text("Niv. $d") })
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(modifier = Modifier.height(470.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(filtered) { position ->
                            Card(
                                modifier = Modifier.fillMaxWidth().clickable { selectedPosition = position },
                                shape = RoundedCornerShape(18.dp),
                                colors = CardDefaults.cardColors(containerColor = palette.surface.copy(alpha=.94f))
                            ) {
                                Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier.size(118.dp).clip(RoundedCornerShape(15.dp)).background(palette.backgroundBottom),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        WikimediaPositionImage(position, Modifier.fillMaxSize())
                                    }
                                    Spacer(Modifier.size(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(position.name, fontWeight = FontWeight.Bold)
                                        Text(
                                            "${position.category} · difficulté ${position.difficulty}/5",
                                            color = palette.accent,
                                            fontSize = 12.sp
                                        )
                                        Spacer(Modifier.height(3.dp))
                                        Text(
                                            position.description,
                                            fontSize = 13.sp,
                                            maxLines = 4,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Spacer(Modifier.height(5.dp))
                                        Text("Voir la fiche →", color = palette.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                Column {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(330.dp)
                            .clip(RoundedCornerShape(22.dp))
                            .background(palette.backgroundBottom),
                        contentAlignment = Alignment.Center
                    ) {
                        WikimediaPositionImage(current, Modifier.fillMaxSize().padding(6.dp))
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "${current.category} · difficulté ${current.difficulty}/5",
                        color = palette.accent,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(current.description, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Illustration : ${current.credit} · ${current.license} · Wikimedia Commons",
                        fontSize = 11.sp,
                        color = palette.accent
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Avant de la jouer : regardez les appuis sur l'illustration, choisissez une amplitude confortable et changez de position si quelque chose tire ou force.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        confirmButton = {
            if (selectedPosition == null) {
                TextButton(onClick = onDismiss) { Text("Fermer") }
            } else {
                TextButton(onClick = { selectedPosition = null }) { Text("Retour") }
            }
        },
        dismissButton = {
            if (selectedPosition != null) {
                TextButton(onClick = onDismiss) { Text("Fermer") }
            }
        }
    )
}

@Composable
private fun MysteryStage(
    rollSignal: Int,
    reveal: Boolean,
    palette: Palette,
    kind: CardKind
) {
    val label = when (kind) {
        CardKind.CHALLENGE -> "DÉFI"
        CardKind.TENTATION -> "TENTATION"
        CardKind.QUESTION -> "QUESTION"
        CardKind.SITUATION -> "SITUATION"
        CardKind.MEMORY -> "SOUVENIR"
        else -> "SURPRISE"
    }
    Card(
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = palette.surface.copy(alpha = 0.90f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, color = palette.accent, fontWeight = FontWeight.Black)
            Box(contentAlignment = Alignment.Center) {
                DiceVisual(
                    sides = 20,
                    result = ((rollSignal * 7) % 20) + 1,
                    rollSignal = rollSignal,
                    palette = palette,
                    size = 220
                )
                Text(
                    if (reveal) "!" else "?",
                    fontSize = 52.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
private fun ResultCard(
    card: GameCard,
    palette: Palette,
    onSave: (() -> Unit)?
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = palette.accent.copy(alpha = 0.14f)),
        modifier = Modifier.border(1.dp, palette.accent.copy(alpha = 0.45f), RoundedCornerShape(24.dp))
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (card.title != "Résultat") {
                Text(
                    "NIVEAU ${card.intensity}/5",
                    color = palette.accent.copy(alpha = 0.82f),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(3.dp))
            }
            Text(card.title.uppercase(), color = palette.accent, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(7.dp))
            Text(
                card.text,
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center
            )
            if (card.detail.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    card.detail,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (onSave != null) {
                Spacer(Modifier.height(12.dp))
                OutlinedButton(onClick = onSave) { Text("Garder pour plus tard") }
            }
        }
    }
}

@Composable
private fun QuestFinished(
    mode: GameMode,
    totalRounds: Int,
    savedCount: Int,
    palette: Palette,
    onRestart: () -> Unit,
    onExit: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("✓", fontSize = 64.sp, color = palette.accent, fontWeight = FontWeight.Black)
        Text("Duo Quest terminé", fontSize = 30.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(8.dp))
        Text("$totalRounds manches · ${mode.title}")
        if (savedCount > 0) Text("$savedCount carte(s) Tentation conservée(s)")
        Spacer(Modifier.height(24.dp))
        Button(onClick = onRestart, modifier = Modifier.fillMaxWidth()) { Text("Rejouer") }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = onExit, modifier = Modifier.fillMaxWidth()) { Text("Retour à l'accueil") }
    }
}

@Composable
private fun ClassicGameScreen(
    actionSides: Int,
    bodySides: Int,
    actionLabels: List<String>,
    bodyLabels: List<String>,
    palette: Palette
) {
    var actionResult by remember { mutableStateOf<Int?>(null) }
    var bodyResult by remember { mutableStateOf<Int?>(null) }
    var actionRollSignal by remember { mutableIntStateOf(0) }
    var bodyRollSignal by remember { mutableIntStateOf(0) }
    val haptic = LocalHapticFeedback.current

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Mode libre", fontSize = 24.sp, fontWeight = FontWeight.Black)
            Text(
                "Les deux dés restent entièrement personnalisables dans Réglages.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        item {
            ClassicDiceCard(
                title = "1 · Action",
                sides = actionSides,
                result = actionResult,
                label = actionResult?.let { actionLabels[it - 1] },
                rollSignal = actionRollSignal,
                buttonText = "Lancer le D$actionSides",
                enabled = true,
                palette = palette,
                onRoll = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    actionResult = Random.nextInt(1, actionSides + 1)
                    bodyResult = null
                    actionRollSignal++
                }
            )
        }
        item {
            ClassicDiceCard(
                title = "2 · Partie du corps",
                sides = bodySides,
                result = bodyResult,
                label = bodyResult?.let { bodyLabels[it - 1] },
                rollSignal = bodyRollSignal,
                buttonText = "Lancer le D$bodySides",
                enabled = actionResult != null,
                palette = palette,
                onRoll = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    bodyResult = Random.nextInt(1, bodySides + 1)
                    bodyRollSignal++
                }
            )
        }
        val currentActionResult = actionResult
        val currentBodyResult = bodyResult
        if (currentActionResult != null && currentBodyResult != null) {
            item {
                ResultCard(
                    card = GameCard(
                        CardKind.CHALLENGE,
                        "Résultat",
                        "${actionLabels[currentActionResult - 1]} · ${bodyLabels[currentBodyResult - 1]}"
                    ),
                    palette = palette,
                    onSave = null
                )
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun ClassicDiceCard(
    title: String,
    sides: Int,
    result: Int?,
    label: String?,
    rollSignal: Int,
    buttonText: String,
    enabled: Boolean,
    palette: Palette,
    onRoll: () -> Unit
) {
    var isAnimating by remember { mutableStateOf(false) }
    var revealResult by remember { mutableStateOf(result != null && rollSignal == 0) }

    LaunchedEffect(rollSignal, result) {
        if (result == null) {
            isAnimating = false
            revealResult = false
        } else if (rollSignal > 0) {
            isAnimating = true
            revealResult = false
            delay(1900)
            revealResult = true
            isAnimating = false
        } else {
            revealResult = true
        }
    }

    val resultScale by animateFloatAsState(
        targetValue = if (revealResult) 1f else 0.72f,
        animationSpec = tween(240),
        label = "classicResultScale"
    )

    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = palette.surface.copy(alpha = 0.90f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("D$sides", color = palette.accent, fontWeight = FontWeight.Black)
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp),
                contentAlignment = Alignment.Center
            ) {
                DiceVisual(
                    sides = sides,
                    result = result ?: 1,
                    rollSignal = rollSignal,
                    palette = palette,
                    size = 220
                )
                if (result != null && revealResult) {
                    Text(
                        result.toString(),
                        modifier = Modifier.graphicsLayer {
                            scaleX = resultScale
                            scaleY = resultScale
                        },
                        fontSize = 46.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                }
            }
            if (label != null && revealResult) {
                Text(label, fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(8.dp))
            }
            Button(
                onClick = onRoll,
                enabled = enabled && !isAnimating,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    when {
                        isAnimating -> "Lancement…"
                        enabled -> buttonText
                        else -> "Lance d'abord le dé Action"
                    }
                )
            }
        }
    }
}

@Composable
private fun DiceVisual(
    sides: Int,
    result: Int,
    rollSignal: Int,
    palette: Palette,
    size: Int
) {
    AndroidView(
        modifier = Modifier
            .size(size.dp)
            .clip(RoundedCornerShape(24.dp))
            .border(
                1.dp,
                palette.accent.copy(alpha = 0.28f),
                RoundedCornerShape(24.dp)
            ),
        factory = { ctx ->
            DiceGLSurfaceView(ctx).apply {
                setDice(sides)
                setTheme(
                    palette.accent.red, palette.accent.green, palette.accent.blue,
                    palette.backgroundBottom.red, palette.backgroundBottom.green, palette.backgroundBottom.blue
                )
            }
        },
        update = { view ->
            view.setDice(sides)
            view.setTheme(
                palette.accent.red, palette.accent.green, palette.accent.blue,
                palette.backgroundBottom.red, palette.backgroundBottom.green, palette.backgroundBottom.blue
            )
            if (view.lastRollSignal != rollSignal) {
                view.lastRollSignal = rollSignal
                if (rollSignal > 0) view.roll(result)
            }
        }
    )
}

@Composable
private fun SettingsScreen(
    prefs: DicePrefs,
    actionSides: Int,
    bodySides: Int,
    actionLabels: List<String>,
    bodyLabels: List<String>,
    secretEnabled: Boolean,
    adultConfirmed: Boolean,
    secretPin: String,
    memories: List<String>,
    onActionSidesChange: (Int) -> Unit,
    onBodySidesChange: (Int) -> Unit,
    onActionLabelChange: (Int, String) -> Unit,
    onBodyLabelChange: (Int, String) -> Unit,
    onSecretEnabled: (Boolean) -> Unit,
    onAdultConfirmed: (Boolean) -> Unit,
    onSecretPin: (String) -> Unit,
    onMemoryChange: (Int, String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Réglages", fontSize = 25.sp, fontWeight = FontWeight.Black)
        }

        item {
            Card(shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Mode Secret", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Une fois activé, il n'apparaît pas sur l'accueil. Tape 5 fois sur DuoDice, entre le code, puis accède à Duo Quest et à la bibliothèque Kama Sutra illustrée.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = adultConfirmed,
                            onCheckedChange = onAdultConfirmed
                        )
                        Text("Je confirme avoir 18 ans ou plus")
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Activer le Mode Secret")
                        Switch(
                            checked = secretEnabled,
                            enabled = adultConfirmed && secretPin.length == 4,
                            onCheckedChange = onSecretEnabled
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = secretPin,
                        onValueChange = onSecretPin,
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        label = { Text("Code secret à 4 chiffres") },
                        singleLine = true,
                        supportingText = {
                            Text("Le contenu reste stocké localement sur le téléphone.")
                        }
                    )
                }
            }
        }

        item {
            Card(shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Souvenirs de nous", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Ajoute jusqu'à 3 souvenirs ou moments. Duo Quest pourra les ressortir pendant certaines manches.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(10.dp))
                    memories.forEachIndexed { index, value ->
                        OutlinedTextField(
                            value = value,
                            onValueChange = { onMemoryChange(index, it) },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Souvenir ${index + 1}") },
                            singleLine = true
                        )
                        if (index < memories.lastIndex) Spacer(Modifier.height(8.dp))
                    }
                }
            }
        }

        item {
            Text("Mode libre · Dés personnalisés", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(
                "D4, D6, D8, D10, D12 et D20. Chaque face peut garder son propre texte.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            DiceSettingsHeader(
                title = "Dé 1 · Actions",
                selectedSides = actionSides,
                onSidesChange = onActionSidesChange
            )
        }
        itemsIndexed(actionLabels) { index, value ->
            FaceField(index + 1, value, "Action ${index + 1}") {
                onActionLabelChange(index, it)
            }
        }

        item {
            DiceSettingsHeader(
                title = "Dé 2 · Parties du corps",
                selectedSides = bodySides,
                onSidesChange = onBodySidesChange
            )
        }
        itemsIndexed(bodyLabels) { index, value ->
            FaceField(index + 1, value, "Partie ${index + 1}") {
                onBodyLabelChange(index, it)
            }
        }

        item { Spacer(Modifier.height(30.dp)) }
    }
}

@Composable
private fun DiceSettingsHeader(
    title: String,
    selectedSides: Int,
    onSidesChange: (Int) -> Unit
) {
    Card(shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 19.sp)
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(DicePrefs.DICE_TYPES) { sides ->
                    FilterChip(
                        selected = selectedSides == sides,
                        onClick = { onSidesChange(sides) },
                        label = { Text("D$sides") }
                    )
                }
            }
        }
    }
}

@Composable
private fun FaceField(
    face: Int,
    value: String,
    placeholder: String,
    onValueChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        label = { Text("Face $face") },
        placeholder = { Text(placeholder) }
    )
}

private class DicePrefs(context: Context) {
    private val prefs = context.getSharedPreferences("duodice", Context.MODE_PRIVATE)

    fun getSides(kind: String): Int {
        val fallback = 6
        val stored = prefs.getInt("${kind}_sides", fallback)
        return if (stored in DICE_TYPES) stored else fallback
    }

    fun setSides(kind: String, sides: Int) {
        if (sides in DICE_TYPES) prefs.edit().putInt("${kind}_sides", sides).apply()
    }

    fun loadLabels(kind: String, sides: Int): List<String> {
        val defaults = defaultLabels(kind, sides)
        return List(sides) { i ->
            prefs.getString("${kind}_${sides}_${i + 1}", null) ?: defaults[i]
        }
    }

    fun saveLabel(kind: String, sides: Int, face: Int, value: String) {
        prefs.edit().putString("${kind}_${sides}_$face", value).apply()
    }

    fun adultConfirmed(): Boolean = prefs.getBoolean("adult_confirmed", false)
    fun setAdultConfirmed(value: Boolean) = prefs.edit().putBoolean("adult_confirmed", value).apply()

    fun secretEnabled(): Boolean = prefs.getBoolean("secret_enabled", false)
    fun setSecretEnabled(value: Boolean) = prefs.edit().putBoolean("secret_enabled", value).apply()

    fun secretPin(): String = prefs.getString("secret_pin", "2468") ?: "2468"
    fun setSecretPin(value: String) = prefs.edit().putString("secret_pin", value).apply()

    fun memories(): List<String> = List(3) { i ->
        prefs.getString("memory_$i", "") ?: ""
    }

    fun setMemory(index: Int, value: String) {
        prefs.edit().putString("memory_$index", value).apply()
    }

    private fun defaultLabels(kind: String, sides: Int): List<String> {
        val actions = listOf(
            "Masser", "Caresser", "Embrasser", "Chatouiller", "Tapoter",
            "Souffler", "Effleurer", "Presser doucement", "Dessiner un cercle", "Frotter doucement",
            "Faire des petits points", "Maintenir 5 secondes", "Faire des zigzags", "Pincer doucement", "Faire rouler les doigts",
            "Donner un bisou", "Faire une plume imaginaire", "Réchauffer avec la main", "Faire trois pressions", "Choisir une action libre"
        )
        val body = listOf(
            "Tête", "Cou", "Épaules", "Bras", "Mains",
            "Poitrine", "Ventre", "Dos", "Hanches", "Fesses",
            "Cuisses", "Genoux", "Mollets", "Chevilles", "Pieds",
            "Visage", "Oreilles", "Cheveux", "Taille", "Jambes"
        )
        val source = if (kind == "action") actions else body
        return List(sides) { i ->
            source.getOrElse(i) {
                if (kind == "action") "Action ${i + 1}" else "Partie ${i + 1}"
            }
        }
    }

    companion object {
        val DICE_TYPES = listOf(4, 6, 8, 10, 12, 20)
    }
}
