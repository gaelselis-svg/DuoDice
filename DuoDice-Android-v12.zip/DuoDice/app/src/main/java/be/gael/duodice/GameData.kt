package be.gael.duodice

import kotlin.random.Random

enum class GameMode(val title:String,val subtitle:String,val emoji:String,val adultOnly:Boolean=false){
    RELAX("Détente","Calme, soins et petites attentions","☁"),
    FUN("Fun","Jeux, défis et fous rires","★"),
    ROMANTIC("Romantique","Connexion, souvenirs et tendresse","♥"),
    HOT("Extra Hot","Flirt, tension et montée progressive","🔥",true),
    SECRET("Secret","Privé, très intense et entièrement adulte","◆",true)
}

enum class CardKind{CHALLENGE,TENTATION,DESTINY,QUESTION,SITUATION,MEMORY,SECRET_POSITION}

data class GameCard(
    val kind:CardKind,
    val title:String,
    val text:String,
    val detail:String="",
    val canSave:Boolean=false,
    val visualKey:Int=-1,
    val intensity:Int=1
)

data class SecretPosition(
    val name:String,
    val difficulty:Int,
    val category:String,
    val description:String,
    val poseId:Int,
    val imageUrl:String,
    val credit:String,
    val license:String,
    val sourcePage:String
)

private data class CuratedCard(
    val kind:CardKind,
    val intensity:Int,
    val title:String,
    val text:String,
    val detail:String="",
    val canSave:Boolean=false
)

object GameEngine {
    private val modeCards: Map<GameMode, List<CuratedCard>> = mapOf(
        GameMode.RELAX to listOf(
            CuratedCard(CardKind.QUESTION, 1, "Question douce", "Quand une journée te vide complètement, qu'est-ce qui t'aide réellement à redescendre ?", "Donne une réponse concrète, pas idéale.", false),
            CuratedCard(CardKind.QUESTION, 1, "Question douce", "Quel petit geste de ma part te fait te sentir pris(e) en compte sans avoir besoin de parler ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "Question douce", "À quel moment de la journée aurais-tu le plus besoin qu'on se retrouve vraiment cinq minutes ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "Question douce", "Qu'est-ce qui te détend le plus avec moi : parler, rire, être touché(e), marcher ou simplement être côte à côte ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "Question douce", "Quelle habitude de notre quotidien te donne une vraie sensation de stabilité ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "Question douce", "Quel type d'ambiance te fait immédiatement souffler : silence, musique, lumière basse, boisson chaude ou autre ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "Question douce", "Qu'est-ce que tu aimerais que je remarque plus vite quand tu es fatigué(e) ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "Question douce", "Quel endroit de la maison te donne le plus envie de ralentir ? Pourquoi ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "Question douce", "Si on inventait un rituel de retour à la maison de trois minutes, qu'est-ce qu'il contiendrait ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "Question douce", "Quelle petite chose pourrais-je faire ce soir pour t'alléger l'esprit ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "À cœur ouvert", "Quand tu as besoin de calme, qu'est-ce qui est le plus utile : qu'on t'écoute, qu'on t'aide, qu'on te laisse souffler ou qu'on te prenne dans les bras ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "À cœur ouvert", "Y a-t-il une fatigue que tu portes en ce moment et que je ne vois peut-être pas ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Question duo", "Quelle tâche ou décision pourrait être simplifiée cette semaine pour nous faire gagner de l'énergie ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Question duo", "Quel moment récent t'a donné la sensation qu'on fonctionnait bien comme équipe ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Question duo", "Quand on est tous les deux à bout, quelle règle simple nous aiderait à éviter de nous agacer inutilement ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Question duo", "Quel plaisir simple avons-nous tendance à oublier alors qu'il nous fait du bien à chaque fois ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Question duo", "Quelle chose aimerais-tu qu'on protège davantage : le sommeil, le temps à deux, le silence, le rire ou les sorties ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Question duo", "Si on avait une soirée totalement vide cette semaine, quelle serait ta version idéale d'une soirée qui repose vraiment ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Question duo", "Quelle attention de cinq minutes vaut pour toi plus qu'un grand geste organisé ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Question duo", "Qu'est-ce qui te permet de te sentir proche de moi même quand on n'a presque pas de temps ?", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi détente", "Pendant 60 secondes, masse lentement les mains de l'autre, paume puis doigts. À la moitié, demande simplement : plus lent, pareil ou un peu plus ferme ?", "Le but est d'ajuster, pas de deviner.", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi détente", "Installez-vous confortablement et prenez trois respirations lentes ensemble. À chaque expiration, relâchez volontairement les épaules.", "Simple, mais faites-le vraiment.", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi détente", "Une personne ferme les yeux pendant 30 secondes pendant que l'autre pose une main immobile sur son épaule ou son dos. Puis inversez.", "Pas besoin de bouger pour créer du calme.", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi détente", "Pendant une minute, l'un masse doucement la nuque et le haut des épaules. L'autre ne donne que trois indications : plus lent, pareil, stop.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi détente", "Prenez chacun une main de l'autre. Pendant 30 secondes, ne faites rien d'autre que garder le contact et respirer normalement.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi détente", "Choisissez une chanson calme. Pendant le premier couplet, restez simplement assis ou allongés côte à côte sans téléphone.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi détente", "Faites un mini scan du corps : chacun nomme une zone tendue et une zone qui se sent bien aujourd'hui.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi détente", "L'un prépare en 90 secondes le coin le plus confortable possible avec ce qui est déjà autour de vous. Puis échangez les rôles la prochaine fois.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi détente", "Donne à l'autre un compliment qui n'a rien à voir avec son apparence et qui concerne quelque chose qu'il ou elle a fait récemment.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi détente", "Pendant 45 secondes, masse doucement les avant-bras de l'autre en gardant exactement le même rythme. Puis demande si ce rythme convenait.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi détente", "L'un choisit entre nuque, mains, épaules ou pieds. L'autre offre deux minutes de massage uniquement sur cette zone, sans changer de mission.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi détente", "Pendant une minute, restez enlacés sans parler. À la fin, chacun dit en un mot ce qui a changé dans son niveau de tension.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi détente", "Chacun retire une petite contrainte de la soirée pour l'autre : une tâche, une décision ou un détail pratique. Dites clairement laquelle.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi détente", "Faites une pause eau ou boisson chaude ensemble. Pendant deux minutes, interdiction de parler de travail, d'organisation ou de problèmes.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi détente", "Une personne s'allonge. L'autre exerce des pressions lentes avec les paumes sur le haut du dos pendant 60 secondes, toujours dans une zone confortable.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi détente", "Choisissez un souvenir calme : vacances, matin tranquille, trajet, plage, canapé. Racontez chacun un détail sensoriel dont vous vous souvenez.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi détente", "Pendant 90 secondes, l'un s'occupe uniquement des pieds ou des mollets de l'autre. Puis demande : qu'est-ce qui était le plus agréable ?", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi détente", "Éteignez une lumière ou baissez-la. Posez les téléphones hors de portée et restez trois minutes dans cette ambiance avant de reprendre le jeu.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi détente", "Chacun choisit une chose à ne plus gérer ce soir. Si c'est réaliste, l'autre l'accepte sans négocier.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi détente", "Asseyez-vous dos contre dos pendant une minute. Essayez de trouver un rythme respiratoire naturel qui se rapproche sans le forcer.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi détente", "Une personne choisit un mot : calme, léger, chaud ou lent. L'autre invente une minute de soin qui correspond à ce mot.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi détente", "Pendant deux minutes, alternez 20 secondes de massage et 10 secondes d'immobilité. Observez quelle partie détend le plus.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi détente", "Dites chacun ce que vous pourriez faire demain matin pour rendre le début de journée de l'autre un peu plus facile.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi détente", "Choisissez ensemble un rituel de fin de soirée de moins de cinq minutes. Testez-en une version miniature maintenant.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi détente", "L'un pose la question : de quoi as-tu besoin tout de suite ? L'autre doit répondre en une seule phrase simple. Si c'est faisable, faites-le.", "", false),
            CuratedCard(CardKind.SITUATION, 1, "Situation", "Vous rentrez tous les deux d'une journée chargée et vous n'avez que dix minutes avant de reprendre le rythme de la maison. Comment utilisez-vous ces dix minutes pour vous retrouver ?", "", false),
            CuratedCard(CardKind.SITUATION, 1, "Situation", "Il est tard, vous êtes fatigués et aucun de vous n'a envie d'une grande discussion. Inventez une façon simple de montrer “je suis avec toi”.", "", false),
            CuratedCard(CardKind.SITUATION, 1, "Situation", "Vous avez une soirée libre mais aucune énergie pour sortir. Construisez votre programme idéal en trois éléments maximum.", "", false),
            CuratedCard(CardKind.SITUATION, 1, "Situation", "Une des deux personnes a besoin de silence, l'autre de proximité. Trouvez une solution qui respecte les deux.", "", false),
            CuratedCard(CardKind.SITUATION, 1, "Situation", "Vous êtes dans une chambre d'hôtel après une longue journée de trajet. Quelle est la première chose qui rendrait l'endroit vraiment reposant ?", "", false),
            CuratedCard(CardKind.SITUATION, 1, "Situation", "Vous avez cinq minutes avant de dormir. Choisissez un seul rituel qui mérite de devenir une habitude.", "", false),
            CuratedCard(CardKind.SITUATION, 1, "Situation", "L'un est tendu, l'autre ne sait pas quoi faire. Décidez d'une phrase simple qu'on pourrait utiliser à l'avenir pour demander du soutien sans devoir tout expliquer.", "", false),
            CuratedCard(CardKind.SITUATION, 2, "Situation", "Vous devez organiser un dimanche matin qui recharge vraiment les batteries. Chacun choisit une chose à garder et une chose à éviter.", "", false),
            CuratedCard(CardKind.SITUATION, 2, "Situation", "Vous avez tous les deux besoin d'attention mais pas de la même manière. Dites chacun ce qui vous ferait du bien et cherchez le point commun.", "", false),
            CuratedCard(CardKind.SITUATION, 2, "Situation", "Supposez que les téléphones soient coupés pendant 30 minutes. Qu'est-ce que vous feriez spontanément ensemble ?", "", false),
            CuratedCard(CardKind.SITUATION, 2, "Situation", "Vous avez eu un petit désaccord plus tôt. Sans rouvrir le débat, quelle action simple permettrait de recréer de la douceur maintenant ?", "", false),
            CuratedCard(CardKind.SITUATION, 2, "Situation", "Vous devez créer un coin détente avec seulement trois objets disponibles autour de vous. Lesquels choisissez-vous ?", "", false),
            CuratedCard(CardKind.SITUATION, 2, "Situation", "L'un doit préparer une micro-pause pour l'autre en moins de deux minutes. Pas de cadeau, pas d'achat : uniquement ce qui est déjà là.", "", false),
            CuratedCard(CardKind.SITUATION, 2, "Situation", "Vous avez une heure totalement libre demain. Chacun propose une activité calme, puis combinez les deux en une seule mini-sortie ou pause.", "", false),
            CuratedCard(CardKind.SITUATION, 2, "Situation", "Imaginez que vous puissiez retirer une seule source de stress de la semaine. Laquelle aurait le plus d'effet sur votre couple ?", "", false),
            CuratedCard(CardKind.TENTATION, 1, "Tentation douce", "Gardez cette carte : cette semaine, accordez-vous dix minutes sans écran juste pour vous poser ensemble.", "À utiliser quand vous sentez que vous tournez en pilote automatique.", true),
            CuratedCard(CardKind.TENTATION, 1, "Tentation douce", "Gardez cette carte : préparez à l'autre une boisson ou une petite pause sans qu'il ou elle ait à la demander.", "", true),
            CuratedCard(CardKind.TENTATION, 1, "Tentation douce", "Gardez cette carte : envoyez demain un message qui n'a qu'un but — alléger la journée de l'autre.", "", true),
            CuratedCard(CardKind.TENTATION, 1, "Tentation douce", "Gardez cette carte : choisissez un soir de la semaine où vous vous couchez dix minutes plus tôt juste pour discuter ou vous enlacer.", "", true),
            CuratedCard(CardKind.TENTATION, 2, "Tentation douce", "Gardez cette carte : offrez à l'autre un massage de dix minutes cette semaine, avec choix libre de la zone confortable.", "", true),
            CuratedCard(CardKind.TENTATION, 2, "Tentation douce", "Gardez cette carte : organisez un mini moment calme après une journée difficile, sans attendre que l'autre le réclame.", "", true),
            CuratedCard(CardKind.TENTATION, 2, "Tentation douce", "Gardez cette carte : créez votre rituel de “retour au calme” en trois étapes et testez-le deux fois cette semaine.", "", true),
            CuratedCard(CardKind.TENTATION, 2, "Tentation douce", "Gardez cette carte : choisissez une soirée où chacun abandonne volontairement une tâche non urgente pour passer du temps ensemble.", "", true)
        ),
        GameMode.FUN to listOf(
            CuratedCard(CardKind.QUESTION, 1, "Question fun", "Si notre couple avait une bande-annonce de film, quelle scène banale devrait absolument y apparaître ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "Question fun", "Quel objet de la maison pourrait raconter les meilleures anecdotes sur nous ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "Question fun", "Quelle de mes petites habitudes serait la plus drôle à imiter devant quelqu'un qui nous connaît bien ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "Question fun", "Si nous ouvrions un restaurant ensemble, quel serait le nom le plus catastrophique mais crédible ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "Question fun", "Quelle corvée domestique ferait le meilleur sport olympique pour nous deux ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "Question fun", "Quel faux titre de journal résumerait parfaitement notre semaine ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "Question fun", "Si on devait avoir un cri de guerre avant d'aller faire les courses, ce serait quoi ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "Question fun", "Quel personnage de dessin animé ressemble le plus à ma version fatiguée ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "Question fun", "Quel talent totalement inutile mais impressionnant devrais-je apprendre ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "Question fun", "Si on avait notre propre émission, quelle rubrique serait forcément un désastre ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "Devine ma réponse", "Quel animal choisirais-je pour te représenter un dimanche matin ? Devine avant que je réponde.", "", false),
            CuratedCard(CardKind.QUESTION, 1, "Devine ma réponse", "Quel plat décrit le mieux ma personnalité aujourd'hui ? Devine d'abord, puis je justifie.", "", false),
            CuratedCard(CardKind.QUESTION, 1, "Devine ma réponse", "Quel serait mon pire déguisement possible ? Devine avant que je donne ma réponse.", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Question fun", "Quelle blague interne est devenue impossible à expliquer à quelqu'un d'extérieur ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Question fun", "Quelle situation embarrassante vécue ensemble nous fait rire maintenant ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Question fun", "Dans quel jeu télévisé serions-nous probablement éliminés très vite ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Question fun", "Quel petit mensonge innocent avons-nous le plus de chances de dire au serveur d'un restaurant ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Question fun", "Si on échangeait nos personnalités pendant 24 heures, qu'est-ce qui serait le plus dangereux ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Question fun", "Quelle compétition ridicule pourrais-tu vraiment gagner contre moi ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Question fun", "Quelle phrase prononcée trop souvent chez nous mérite de devenir un bouton sonore ?", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi fun", "Choisis un objet à portée de main et vends-le à l'autre comme s'il coûtait 10 000 €. Tu as 30 secondes.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi fun", "Imite-moi quand je suis pressé(e) pendant 20 secondes. Interdiction d'expliquer : je dois reconnaître la scène.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi fun", "Fais une publicité dramatique de 20 secondes pour quelque chose de totalement banal dans la pièce.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi fun", "Mime une de nos habitudes communes. L'autre a trois tentatives pour deviner.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi fun", "Inventez ensemble le nom, le slogan et la spécialité d'un restaurant que personne ne devrait jamais ouvrir.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi fun", "L'un choisit une émotion exagérée. L'autre doit dire “qu'est-ce qu'on mange ce soir ?” comme s'il vivait cette émotion à 200 %.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi fun", "Pendant 30 secondes, raconte ta journée comme un commentateur sportif en plein match décisif.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi fun", "L'un pense à un souvenir à deux. Il donne trois indices volontairement mauvais. L'autre doit quand même deviner.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi fun", "Choisissez une chanson connue et remplacez un mot du refrain par le prénom de l'autre. Chantez au moins une phrase.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi fun", "Fais trois compliments à l'autre, mais l'un doit être volontairement absurde. Il ou elle doit repérer lequel.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi fun", "Dessine une forme simple dans le dos de l'autre avec un doigt. Trois essais pour deviner.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi fun", "Créez un handshake de couple en quatre mouvements maximum. Répétez-le trois fois sans vous tromper.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi fun", "Faites un concours de regard sérieux. Le premier qui rit doit raconter une anecdote embarrassante légère.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi fun", "L'un choisit un mot banal. L'autre doit improviser une chanson de 15 secondes qui contient ce mot.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi fun", "Inventez le pire nom possible pour un parfum qui représenterait votre couple.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi fun", "Jouez “qui connaît mieux l'autre” : chacun note mentalement la boisson, le snack ou le dessert que l'autre choisirait maintenant. Révélez en même temps.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi fun", "Une personne fait une pose ridicule immobile. L'autre doit la reproduire exactement sans rire pendant dix secondes.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi fun", "Raconte une vraie anecdote sur toi en ajoutant un seul faux détail. L'autre doit repérer le détail inventé.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi fun", "Vous avez 45 secondes pour inventer le scénario d'un film où vous êtes tous les deux des agents secrets complètement incompétents.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi fun", "Choisissez une corvée. Transformez-la en épreuve olympique avec règles, arbitre et commentaire final.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi fun", "L'un doit faire rire l'autre en moins de 30 secondes sans le toucher. Puis inversez les rôles.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi fun", "Choisissez chacun un objet sans le dire. En même temps, essayez de convaincre l'autre que votre objet serait le meilleur compagnon de voyage.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi fun", "Créez une histoire à deux : chacun ajoute une phrase, mais toutes les phrases doivent empirer la situation.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi fun", "Faites un mini doublage : mettez le son d'une vidéo muette ou regardez une scène quelconque sans son et improvisez deux répliques chacun.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi fun", "Imite la manière dont l'autre commande au restaurant, choisit un film ou cherche ses clés. À lui ou elle de deviner laquelle.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi fun", "Inventez chacun un surnom secret pour l'autre. Révélez-les et gardez le plus drôle pour la fin de la partie.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi fun", "Pendant une minute, chaque fois que l'autre dit “oui” ou “non”, il doit immédiatement ajouter un bruit d'animal.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi fun", "Choisissez une photo ancienne sur votre téléphone. Chacun invente une légende volontairement mensongère et la plus crédible gagne.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi fun", "Faites un duel d'impro : vous êtes deux candidats d'une émission de télé-réalité qui doivent expliquer pourquoi l'autre mérite de rester dans l'aventure.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi fun", "L'un ferme les yeux. L'autre lui fait toucher trois objets sûrs de la pièce, un par un. Deviner les trois gagne une carte bonus morale : choisir la prochaine catégorie.", "", false),
            CuratedCard(CardKind.SITUATION, 1, "Situation", "Vous êtes invités à une soirée à thème mais vous apprenez le thème cinq minutes avant de partir. Inventez le pire thème possible et votre plan de survie.", "", false),
            CuratedCard(CardKind.SITUATION, 1, "Situation", "On vous engage pour présenter ensemble une émission de cuisine alors qu'aucun de vous n'a vu la recette. Comment commence le direct ?", "", false),
            CuratedCard(CardKind.SITUATION, 1, "Situation", "Vous gagnez un week-end gratuit, mais l'hôtel impose une activité totalement ridicule. Laquelle vous ferait le plus rire ?", "", false),
            CuratedCard(CardKind.SITUATION, 1, "Situation", "Un journaliste veut écrire un article sur “le couple le plus banal du monde”. Quelle anecdote lui donneriez-vous pour ruiner son titre ?", "", false),
            CuratedCard(CardKind.SITUATION, 1, "Situation", "Vous devez choisir une mascotte officielle pour votre maison. Défendez chacun votre candidat en 20 secondes.", "", false),
            CuratedCard(CardKind.SITUATION, 1, "Situation", "Vous ouvrez un parc d'attractions basé sur votre quotidien. Nommez trois attractions.", "", false),
            CuratedCard(CardKind.SITUATION, 1, "Situation", "Vous devez participer à un concours de talents demain. Quel duo pouvez-vous réellement préparer en une soirée ?", "", false),
            CuratedCard(CardKind.SITUATION, 1, "Situation", "Vous êtes bloqués dans un ascenseur avec une célébrité imaginaire. Qui serait la personne la plus drôle à avoir avec vous ?", "", false),
            CuratedCard(CardKind.SITUATION, 1, "Situation", "Votre maison devient un musée pendant une journée. Quel objet mérite sa propre vitrine et quelle serait l'étiquette ?", "", false),
            CuratedCard(CardKind.SITUATION, 1, "Situation", "Vous êtes finalistes d'un jeu télévisé : la dernière question porte sur votre couple. Quel thème vous ferait le plus peur ?", "", false),
            CuratedCard(CardKind.SITUATION, 2, "Situation", "Vous devez inventer une fausse tradition de couple assez crédible pour qu'un ami pense qu'elle existe vraiment.", "", false),
            CuratedCard(CardKind.SITUATION, 2, "Situation", "Un réalisateur veut adapter votre semaine en comédie. Choisissez l'acteur ou l'actrice qui jouerait chacun de vous et le titre du film.", "", false),
            CuratedCard(CardKind.SITUATION, 2, "Situation", "Vous avez 100 € fictifs pour créer la soirée la plus inutilement luxueuse possible à la maison. Comment dépensez-vous le budget imaginaire ?", "", false),
            CuratedCard(CardKind.SITUATION, 2, "Situation", "Vous échangez vos rôles du quotidien pendant une journée. Qu'est-ce qui risque de partir de travers en premier ?", "", false),
            CuratedCard(CardKind.SITUATION, 2, "Situation", "Vous devez créer une règle absurde que toute personne entrant chez vous doit respecter pendant une heure.", "", false),
            CuratedCard(CardKind.TENTATION, 1, "Tentation fun", "Gardez cette carte : cette semaine, envoyez à l'autre un défi drôle qui prend moins de deux minutes.", "", true),
            CuratedCard(CardKind.TENTATION, 1, "Tentation fun", "Gardez cette carte : prenez une photo volontairement ridicule mais mémorable ensemble avant la fin de semaine.", "", true),
            CuratedCard(CardKind.TENTATION, 1, "Tentation fun", "Gardez cette carte : inventez un mot secret à placer naturellement lors d'une sortie. Celui qui craque et rit a perdu.", "", true),
            CuratedCard(CardKind.TENTATION, 1, "Tentation fun", "Gardez cette carte : organisez une mini compétition à la maison avec un trophée improvisé.", "", true),
            CuratedCard(CardKind.TENTATION, 2, "Tentation fun", "Gardez cette carte : choisissez un soir et faites un mini quiz de 10 questions sur vos habitudes respectives.", "", true),
            CuratedCard(CardKind.TENTATION, 2, "Tentation fun", "Gardez cette carte : créez un faux prix annuel pour une habitude de l'autre et préparez une remise de prix de 30 secondes.", "", true),
            CuratedCard(CardKind.TENTATION, 2, "Tentation fun", "Gardez cette carte : choisissez une activité que vous n'avez jamais prise au sérieux et transformez-la en défi officiel à deux.", "", true),
            CuratedCard(CardKind.TENTATION, 2, "Tentation fun", "Gardez cette carte : pendant une sortie, chacun doit secrètement trouver l'objet le plus étrange à moins de 5 € sans l'acheter.", "", true)
        ),
        GameMode.ROMANTIC to listOf(
            CuratedCard(CardKind.QUESTION, 1, "À cœur ouvert", "Quel moment récent t'a donné la sensation qu'on formait vraiment une équipe ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "À cœur ouvert", "Quelle petite attention de ma part t'a marqué(e) plus que je ne l'imaginais ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "À cœur ouvert", "Quel souvenir de nos débuts revient le plus facilement quand tu penses à nous ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "À cœur ouvert", "Quelle qualité chez moi t'apporte le plus de sécurité dans notre relation ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "À cœur ouvert", "Qu'est-ce qui te fait te sentir “chez toi” avec moi ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "À cœur ouvert", "Quel geste tendre aimerais-tu recevoir plus souvent sans avoir à le demander ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "À cœur ouvert", "Quel moment banal de notre quotidien te manquerait énormément s'il disparaissait ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "À cœur ouvert", "Quelle chose que nous faisons ensemble te semble plus précieuse avec le temps ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "À cœur ouvert", "Quel compliment venant de moi a le plus de valeur pour toi ?", "", false),
            CuratedCard(CardKind.QUESTION, 1, "À cœur ouvert", "Quelle habitude de couple voudrais-tu préserver même dans dix ans ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Devine ma réponse", "Quel petit rendez-vous simple me ferait le plus plaisir cette semaine ? Devine avant que je réponde.", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Devine ma réponse", "Quel souvenir à deux est, selon toi, celui que je raconterais en premier à quelqu'un ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Devine ma réponse", "Quelle qualité de notre relation choisirais-je si je ne pouvais en garder qu'une ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Question duo", "Quel projet commun te donne le plus envie de nous voir avancer ensemble ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Question duo", "Qu'est-ce que nous faisons mieux aujourd'hui qu'au début de notre relation ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Question duo", "Quel moment t'a fait réaliser que tu pouvais vraiment compter sur moi ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Question duo", "Quel endroit aimerais-tu redécouvrir avec moi, mais différemment cette fois ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Question duo", "Quelle chose aimerais-tu que je comprenne mieux sur la manière dont tu te sens aimé(e) ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Question duo", "Quelle petite promesse réaliste pourrait améliorer notre mois à venir ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Question duo", "Quelle tradition de couple aimerais-tu commencer maintenant plutôt que “un jour” ?", "", false),
            CuratedCard(CardKind.QUESTION, 3, "À cœur ouvert", "Y a-t-il un moment où tu t'es senti(e) blessé(e) ou seul(e) alors que je pensais probablement que tout allait bien ?", "Parlez du besoin, pas du procès.", false),
            CuratedCard(CardKind.QUESTION, 3, "À cœur ouvert", "Quelle peur liée à notre avenir est plus facile à dire dans un jeu que dans une conversation ordinaire ?", "", false),
            CuratedCard(CardKind.QUESTION, 3, "À cœur ouvert", "Quelle partie de toi aimerais-tu que je protège davantage quand la vie devient compliquée ?", "", false),
            CuratedCard(CardKind.QUESTION, 3, "À cœur ouvert", "Qu'est-ce que tu veux absolument que nous continuions à faire même si notre quotidien devient beaucoup plus chargé ?", "", false),
            CuratedCard(CardKind.QUESTION, 3, "À cœur ouvert", "Quelle chose as-tu apprise sur l'amour grâce à notre relation ?", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi romantique", "Regardez-vous pendant 20 secondes sans parler, puis dites chacun une chose précise que vous aimez voir chez l'autre aujourd'hui.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi romantique", "Donne à l'autre un compliment sur quelque chose qu'il ou elle a fait récemment et explique pourquoi ça t'a touché(e).", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi romantique", "Prenez-vous dans les bras pendant 30 secondes. À la fin, ne dites qu'une phrase : “Ce que j'aime ici, c'est…”", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi romantique", "Choisis un souvenir heureux et raconte-le comme si tu décrivais une photo : lieu, détail, lumière, expression de l'autre.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi romantique", "Embrasse l'autre doucement puis dis une chose que tu apprécies davantage aujourd'hui qu'au début de votre relation.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi romantique", "Prenez chacun la main de l'autre et dites une chose que vous avez envie de faire ensemble avant la fin de l'année.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi romantique", "Choisissez une chanson qui vous ressemble aujourd'hui. Écoutez-en une minute ensemble sans faire autre chose.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi romantique", "Faites un mini slow d'une minute, même sans musique. Interdiction de commenter le ridicule éventuel.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi romantique", "L'un ferme les yeux. L'autre donne trois baisers lents à trois endroits tendres et non intimes : front, joue, main, épaule ou nuque. Puis inversez.", "", false),
            CuratedCard(CardKind.CHALLENGE, 1, "Défi romantique", "Dites chacun une chose pour laquelle vous êtes reconnaissant(e) envers l'autre cette semaine.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi romantique", "Recréez en deux minutes l'ambiance d'un petit rendez-vous avec ce que vous avez autour de vous : lumière, siège, musique ou boisson.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi romantique", "Une personne décrit son rendez-vous parfait de deux heures. L'autre doit en récupérer au moins un élément réellement faisable bientôt.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi romantique", "Écrivez chacun une phrase sur ce que vous espérez encore vivre ensemble. Lisez-la à voix haute sans la commenter tout de suite.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi romantique", "Pendant 45 secondes, restez très proches sans parler. Ensuite, chacun choisit : baiser, câlin ou phrase tendre.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi romantique", "Choisissez une photo de vous deux que vous aimez. Chacun explique ce qu'il ou elle voit dans cette photo que l'autre ne voit peut-être pas.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi romantique", "L'un donne trois raisons précises pour lesquelles il ou elle choisirait encore l'autre aujourd'hui. Puis inversez.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi romantique", "Inventez votre rendez-vous idéal à petit budget : un lieu, une nourriture, une activité. Gardez l'idée si elle vous plaît vraiment.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi romantique", "Une personne raconte un moment où l'autre l'a aidée sans forcément s'en rendre compte. Puis inversez.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi romantique", "Choisissez une qualité de l'autre. Donnez un exemple concret où cette qualité a vraiment compté.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi romantique", "L'un prend le visage de l'autre entre ses mains pendant quelques secondes et dit simplement : “Je suis content(e) d'être ici avec toi.”", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi romantique", "Faites chacun une promesse minuscule pour la semaine à venir, suffisamment petite pour être tenue.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi romantique", "Racontez chacun une période difficile traversée ensemble et dites ce que l'autre a fait de juste à ce moment-là.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi romantique", "Complétez chacun la phrase : “Quand j'imagine nous dans cinq ans, j'espère surtout que…”", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi romantique", "Choisissez un sujet de tension récurrent. Sans le résoudre, chacun formule uniquement le besoin qui se cache derrière.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi romantique", "L'un dit une chose qu'il aimerait recevoir davantage dans la relation. L'autre reformule sans se défendre. Puis inversez.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi romantique", "Dites chacun une chose que vous admirez dans la façon dont l'autre a évolué depuis que vous êtes ensemble.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi romantique", "Échangez un vrai merci pour une chose que vous avez fini par considérer comme “normale” alors qu'elle ne l'est pas.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi romantique", "Choisissez ensemble un souvenir que vous aimeriez recréer cette année. Fixez le premier petit pas nécessaire.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi romantique", "Prenez deux minutes pour raconter ce que vous aimeriez que l'autre retienne de cette période de votre vie.", "", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi romantique", "Posez-vous une question que vous avez envie de poser depuis longtemps mais que vous repoussez parce que le moment ne semble jamais parfait. L'autre peut choisir de répondre maintenant ou plus tard.", "", false),
            CuratedCard(CardKind.SITUATION, 1, "Situation", "Vous avez une heure libre inattendue un soir de semaine. Comment en faire un vrai mini rendez-vous au lieu de simplement remplir le temps ?", "", false),
            CuratedCard(CardKind.SITUATION, 1, "Situation", "Vous êtes dans une ville inconnue avec deux heures devant vous. Quel type de moment choisiriez-vous ensemble ?", "", false),
            CuratedCard(CardKind.SITUATION, 1, "Situation", "Il pleut toute la journée pendant vos vacances. Imaginez la meilleure version possible de cette journée à deux.", "", false),
            CuratedCard(CardKind.SITUATION, 1, "Situation", "Vous retrouvez une boîte avec des photos de vos débuts. Laquelle auriez-vous envie de raconter en premier ?", "", false),
            CuratedCard(CardKind.SITUATION, 1, "Situation", "Vous devez organiser un rendez-vous sans restaurant, sans cinéma et sans achat. Que proposez-vous ?", "", false),
            CuratedCard(CardKind.SITUATION, 1, "Situation", "Vous avez un balcon, une terrasse ou simplement une fenêtre ouverte un soir calme. Qu'est-ce qui transformerait dix minutes en vrai moment à deux ?", "", false),
            CuratedCard(CardKind.SITUATION, 2, "Situation", "Vous fêtez un anniversaire de relation avec presque aucun budget. Qu'est-ce qui rendrait quand même la soirée spéciale ?", "", false),
            CuratedCard(CardKind.SITUATION, 2, "Situation", "L'un part plusieurs jours. Quel petit rituel garderiez-vous à distance pour rester connectés ?", "", false),
            CuratedCard(CardKind.SITUATION, 2, "Situation", "Vous devez écrire ensemble trois lignes à relire dans dix ans. Que voulez-vous absolument y mettre ?", "", false),
            CuratedCard(CardKind.SITUATION, 2, "Situation", "Un couple d'amis vous demande le secret d'une chose qui fonctionne bien entre vous. Que répondriez-vous sans enjoliver ?", "", false),
            CuratedCard(CardKind.SITUATION, 2, "Situation", "Vous pouvez revivre une journée de votre histoire sans rien changer. Laquelle choisissez-vous ?", "", false),
            CuratedCard(CardKind.SITUATION, 2, "Situation", "Vous pouvez revivre une journée mais changer un seul détail pour la rendre encore meilleure. Laquelle et quel détail ?", "", false),
            CuratedCard(CardKind.SITUATION, 3, "Situation", "Vous traversez une période où vous avez très peu de temps l'un pour l'autre. Quelle règle minimale protégerait votre couple ?", "", false),
            CuratedCard(CardKind.SITUATION, 3, "Situation", "L'un de vous doute de lui-même. Quelle phrase venant de l'autre aurait le plus de valeur parce qu'elle serait crédible ?", "", false),
            CuratedCard(CardKind.SITUATION, 3, "Situation", "Vous devez définir ce que “prendre soin de nous” signifie concrètement pour les trois prochains mois. Donnez trois actions maximum.", "", false),
            CuratedCard(CardKind.TENTATION, 1, "Tentation romantique", "Gardez cette carte : laissez dans les sept jours un mot simple à un endroit où l'autre le trouvera seul(e).", "", true),
            CuratedCard(CardKind.TENTATION, 1, "Tentation romantique", "Gardez cette carte : choisissez une photo de vous deux et envoyez-la plus tard avec une phrase sur ce souvenir.", "", true),
            CuratedCard(CardKind.TENTATION, 1, "Tentation romantique", "Gardez cette carte : organisez un mini rendez-vous de moins d'une heure cette semaine, sans attendre une occasion spéciale.", "", true),
            CuratedCard(CardKind.TENTATION, 1, "Tentation romantique", "Gardez cette carte : recréez un petit détail d'un de vos premiers rendez-vous.", "", true),
            CuratedCard(CardKind.TENTATION, 2, "Tentation romantique", "Gardez cette carte : faites une attention que l'autre ne remarquera peut-être qu'après quelques minutes.", "", true),
            CuratedCard(CardKind.TENTATION, 2, "Tentation romantique", "Gardez cette carte : choisissez une soirée où vous vous racontez chacun un souvenir favori de votre histoire.", "", true),
            CuratedCard(CardKind.TENTATION, 2, "Tentation romantique", "Gardez cette carte : préparez une surprise simple basée sur quelque chose que l'autre a mentionné récemment.", "", true),
            CuratedCard(CardKind.TENTATION, 3, "Tentation romantique", "Gardez cette carte : planifiez un rendez-vous autour d'un souvenir commun plutôt qu'autour d'une activité nouvelle.", "", true)
        ),
        GameMode.HOT to listOf(
            CuratedCard(CardKind.QUESTION, 2, "Préférence", "Qu'est-ce qui fait le plus monter le désir chez toi : l'attente, les mots, le regard, le toucher ou l'initiative ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Préférence", "Tu préfères qu'un moment chaud commence spontanément ou qu'une tension s'installe longtemps avant ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Préférence", "Quel type de baiser te fait le plus d'effet : très lent, intense, imprévisible ou entrecoupé de pauses ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Préférence", "Quel endroit non explicite du corps est beaucoup plus sensuel pour toi qu'on pourrait le croire ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Préférence", "Tu préfères guider avec des mots ou laisser l'autre comprendre surtout par ta réaction ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Préférence", "Quel détail d'ambiance change le plus ton état d'esprit : lumière, musique, odeur, tenue ou moment de la journée ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Préférence", "Quelle forme de teasing te plaît le plus : proximité sans toucher, toucher bref, mots ou attente ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Préférence", "Quel rythme est le meilleur pour toi au début : très lent, progressif ou rapidement assumé ?", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Devine ma réponse", "Devine ce que je choisirais entre : cinq minutes de teasing, un long baiser, un massage sensuel ou une surprise.", "", false),
            CuratedCard(CardKind.QUESTION, 2, "Devine ma réponse", "Quel détail me fait le plus sentir désiré(e) : le regard, les mots, les mains ou l'initiative ?", "", false),
            CuratedCard(CardKind.QUESTION, 3, "Préférence", "Qu'est-ce qui différencie pour toi un geste agréable d'un geste réellement excitant ?", "", false),
            CuratedCard(CardKind.QUESTION, 3, "Préférence", "Dans un moment sensuel, qu'est-ce que tu aimerais qu'on fasse plus lentement qu'on ne le fait d'habitude ?", "", false),
            CuratedCard(CardKind.QUESTION, 3, "Préférence", "Tu préfères une personne qui mène clairement ou une alternance où le contrôle change souvent ?", "", false),
            CuratedCard(CardKind.QUESTION, 3, "Préférence", "Quelle phrase ou quel ton de voix peut faire monter la température presque instantanément ?", "", false),
            CuratedCard(CardKind.QUESTION, 3, "Préférence", "Quel type de contact apprécies-tu davantage quand les vêtements sont encore là ?", "", false),
            CuratedCard(CardKind.QUESTION, 3, "Préférence", "Qu'est-ce qui te donne le plus confiance pour essayer quelque chose de nouveau ?", "", false),
            CuratedCard(CardKind.QUESTION, 3, "Préférence", "Si tu pouvais améliorer une seule chose dans nos moments intimes, ce serait plutôt le temps, l'ambiance, la communication ou la variété ?", "", false),
            CuratedCard(CardKind.QUESTION, 3, "Préférence", "Quelle partie du moment préfères-tu prolonger volontairement plutôt que d'aller directement à la suite ?", "", false),
            CuratedCard(CardKind.QUESTION, 4, "Préférence", "Quel fantasme léger ou scénario te semble attirant surtout pour l'ambiance qu'il crée ?", "", false),
            CuratedCard(CardKind.QUESTION, 4, "Préférence", "Qu'est-ce que tu aimerais pouvoir demander plus facilement quand la tension monte ?", "", false),
            CuratedCard(CardKind.QUESTION, 4, "Préférence", "Quelle dose de contrôle venant de l'autre est excitante pour toi sans devenir inconfortable ?", "", false),
            CuratedCard(CardKind.QUESTION, 4, "Préférence", "Quel rôle te ressemble le plus dans un moment chaud : initier, guider, provoquer, répondre ou alterner ?", "", false),
            CuratedCard(CardKind.QUESTION, 4, "Préférence", "Quelle nouveauté serait excitante précisément parce qu'elle reste simple et réaliste ?", "", false),
            CuratedCard(CardKind.QUESTION, 5, "Préférence", "Si on pouvait construire une session idéale en trois phases — teasing, montée, finale — qu'est-ce que tu mettrais dans chaque phase ?", "", false),
            CuratedCard(CardKind.QUESTION, 5, "Préférence", "Quel élément de nos moments les plus intenses aimerais-tu retrouver plus souvent sans forcément en faire plus ?", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi hot", "Embrasse l'autre lentement pendant 30 secondes. À mi-chemin, fais une pause de trois secondes sans reculer, puis reprends encore plus lentement.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi hot", "Pendant 45 secondes, caresse uniquement la nuque, les épaules et le haut du dos. Interdiction de changer de zone avant la fin.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi hot", "Approche-toi très près sans toucher pendant dix secondes. Ensuite seulement, donne un baiser où l'autre le choisit parmi trois zones tendres.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi hot", "L'un murmure une chose qu'il trouve attirante chez l'autre, puis l'embrasse exactement comme il aimerait être embrassé.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi hot", "Pendant une minute, l'un mène un massage sensuel à travers les vêtements. L'autre ne donne que trois indications : plus lent, pareil, stop.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi hot", "Choisissez une zone parmi cou, épaules, dos, ventre ou cuisses. Pendant 40 secondes, restez uniquement sur cette zone et faites durer l'attente.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi hot", "L'un garde les mains immobiles pendant 20 secondes pendant que l'autre décide comment créer la tension uniquement avec proximité, regard et baisers.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi hot", "Embrasse l'autre trois fois : une fois très doucement, une fois avec plus d'assurance, puis une troisième fois selon sa préférence.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi hot", "Pendant 30 secondes, une personne ne fait rien d'autre que regarder l'autre comme si elle allait l'embrasser. Le baiser n'arrive qu'à la fin.", "", false),
            CuratedCard(CardKind.CHALLENGE, 2, "Défi hot", "Choisis une phrase courte à murmurer à l'oreille de l'autre, puis garde le silence pendant 20 secondes de contact.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi hot", "Une personne mène pendant 60 secondes. Elle choisit rythme, proximité et baisers. L'autre peut uniquement dire : plus lent, pareil, stop.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi hot", "Retirez chacun un vêtement si vous en avez envie, puis recommencez une carte précédente que vous avez aimée avec deux fois plus de lenteur.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi hot", "Pendant 45 secondes, alterne 10 secondes de contact et 5 secondes de pause. L'autre ne sait pas exactement quand tu reprends.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi hot", "Choisissez ensemble une zone autorisée. Pendant une minute, toutes les attentions reviennent à cette zone sans se disperser.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi hot", "L'un ferme les yeux. L'autre choisit trois contacts différents sur des zones convenues. Après chaque contact, la personne qui reçoit donne une note sur 10.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi hot", "Pendant une minute, l'un ne peut utiliser que ses lèvres et son souffle autour du visage, du cou et des épaules. Puis inversez.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi hot", "Prenez 30 secondes pour dire chacun ce qui vous donne le plus envie maintenant. Choisissez uniquement le point commun et jouez-le pendant une minute.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi hot", "Une personne décide d'un rythme. L'autre décide d'une zone. Pendant 45 secondes, aucun des deux ne peut modifier sa décision.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi hot", "L'un guide la main de l'autre vers une zone confortable qu'il veut sentir davantage touchée. Pas de devinette : montrez clairement.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi hot", "Choisissez entre lent, provocant ou intense. Jouez un long baiser de 40 secondes en restant fidèle à ce mot.", "", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi hot", "Pendant 90 secondes, une personne mène et doit faire monter la tension sans accélérer. Elle n'a droit qu'à une seule augmentation de rythme.", "", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi hot", "Choisissez un vêtement ou accessoire qui vous plaît sur l'autre. Retirez-le ou déplacez-le lentement, puis faites une pause avant de continuer.", "", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi hot", "L'un n'a pas le droit de toucher pendant 30 secondes. L'autre utilise uniquement proximité, regard et mots. Ensuite, échangez.", "", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi hot", "Une personne choisit deux zones autorisées. L'autre alterne entre elles sans prévenir pendant une minute, toujours avec un rythme maîtrisé.", "", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi hot", "Choisissez une carte hot déjà appréciée. Rejouez-la avec une règle supplémentaire : silence, yeux ouverts ou pauses imposées.", "", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi hot", "L'un donne trois consignes sensuelles courtes. L'autre en choisit deux à exécuter dans l'ordre qu'il préfère.", "", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi hot", "Pendant 60 secondes, l'un doit faire durer l'envie sans aller vers la zone que l'autre préfère le plus. À la fin seulement, demande s'il veut continuer.", "", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi hot", "Choisissez un mot de contrôle simple. Pendant une minute, la personne qui reçoit peut dire ce mot une seule fois pour modifier immédiatement le rythme ou la zone.", "", false),
            CuratedCard(CardKind.CHALLENGE, 5, "Défi hot", "Construisez une séquence de trois minutes : 60 secondes de teasing, 60 secondes de contact assumé, 60 secondes choisies par la personne qui reçoit.", "", false),
            CuratedCard(CardKind.CHALLENGE, 5, "Défi hot", "L'un mène pendant deux minutes et doit faire monter l'intensité par petites étapes. L'autre décide exactement quand chaque étape peut commencer.", "", false),
            CuratedCard(CardKind.SITUATION, 2, "Situation", "Vous n'avez que dix minutes à deux et vous voulez faire monter la tension sans vous précipiter. Quelles sont les trois étapes que vous gardez ?", "", false),
            CuratedCard(CardKind.SITUATION, 2, "Situation", "Vous êtes dans une chambre d'hôtel, encore habillés, avec une heure devant vous. Quelle ambiance créez-vous avant même de commencer ?", "", false),
            CuratedCard(CardKind.SITUATION, 2, "Situation", "Vous devez créer un moment sensuel sans parler pendant une minute. Qui prend l'initiative et comment ?", "", false),
            CuratedCard(CardKind.SITUATION, 2, "Situation", "L'un veut du teasing, l'autre veut de la proximité. Trouvez une action qui répond aux deux envies en même temps.", "", false),
            CuratedCard(CardKind.SITUATION, 2, "Situation", "La règle pour la prochaine minute : aucune précipitation. Quel geste choisissez-vous volontairement de ralentir ?", "", false),
            CuratedCard(CardKind.SITUATION, 2, "Situation", "Vous pouvez choisir seulement trois éléments : lumière, musique, tenue, parfum, boisson, lieu. Lesquels créent la meilleure ambiance ?", "", false),
            CuratedCard(CardKind.SITUATION, 3, "Situation", "Une personne mène, l'autre ne peut donner que trois types de réponse : oui, plus lent, stop. Quelle première action choisissez-vous ?", "", false),
            CuratedCard(CardKind.SITUATION, 3, "Situation", "Vous devez faire monter la température sans enlever un seul vêtement pendant deux minutes. Comment vous y prenez-vous ?", "", false),
            CuratedCard(CardKind.SITUATION, 3, "Situation", "Chacun choisit secrètement : mots, regard, baisers ou mains. Révélez en même temps et construisez la prochaine minute autour des réponses.", "", false),
            CuratedCard(CardKind.SITUATION, 3, "Situation", "Vous êtes interrompus dans quinze minutes. Quel type de jeu rendrait ces quinze minutes excitantes sans donner l'impression de courir ?", "", false),
            CuratedCard(CardKind.SITUATION, 3, "Situation", "Vous rejouez une carte que vous avez aimée, mais l'un doit décider du rythme et l'autre de la durée.", "", false),
            CuratedCard(CardKind.SITUATION, 3, "Situation", "Vous devez faire ressentir “je te désire” sans prononcer cette phrase. Comment chacun le ferait ?", "", false),
            CuratedCard(CardKind.SITUATION, 4, "Situation", "Pendant les deux prochaines minutes, une personne est responsable de la tension, l'autre de fixer les limites et le rythme. Quel rôle choisissez-vous ?", "", false),
            CuratedCard(CardKind.SITUATION, 4, "Situation", "Vous devez choisir entre contrôle, teasing, lenteur extrême ou surprise. Le choix devient la règle de la prochaine carte.", "", false),
            CuratedCard(CardKind.SITUATION, 4, "Situation", "Vous pouvez rejouer un souvenir intime réussi ou inventer quelque chose de nouveau. Chacun vote secrètement puis révélez.", "", false),
            CuratedCard(CardKind.SITUATION, 4, "Situation", "Une personne doit provoquer l'envie pendant 90 secondes sans utiliser la zone préférée de l'autre. Quelle stratégie choisit-elle ?", "", false),
            CuratedCard(CardKind.SITUATION, 4, "Situation", "Vous devez créer un mini scénario en trois mots seulement. Choisissez les trois mots, puis jouez la version la plus simple de ce scénario.", "", false),
            CuratedCard(CardKind.SITUATION, 5, "Situation", "Construisez une finale de cinq minutes en trois actes : attente, contrôle, liberté. Décidez qui mène chaque acte.", "", false),
            CuratedCard(CardKind.SITUATION, 5, "Situation", "Chacun choisit une envie et une limite pour le moment présent. Votre mission est de créer une carte qui reste entièrement dans la zone commune.", "", false),
            CuratedCard(CardKind.SITUATION, 5, "Situation", "Vous devez choisir une seule chose à intensifier : mots, rythme, proximité, contrôle ou durée. Tout le reste reste volontairement simple.", "", false),
            CuratedCard(CardKind.TENTATION, 2, "Tentation hot", "Gardez cette carte : envoyez dans les 48 heures un message qui crée de l'anticipation pour un moment précis, pas juste un compliment vague.", "", true),
            CuratedCard(CardKind.TENTATION, 2, "Tentation hot", "Gardez cette carte : créez ensemble une mini playlist de trois morceaux pour une prochaine soirée.", "", true),
            CuratedCard(CardKind.TENTATION, 2, "Tentation hot", "Gardez cette carte : choisissez un vêtement ou une tenue que l'autre aime et gardez l'idée pour une prochaine occasion.", "", true),
            CuratedCard(CardKind.TENTATION, 3, "Tentation hot", "Gardez cette carte : lors d'un prochain moment, commencez par deux minutes de teasing sans aller plus loin.", "", true),
            CuratedCard(CardKind.TENTATION, 3, "Tentation hot", "Gardez cette carte : écrivez chacun trois choses simples qui vous font vous sentir désiré(e). Comparez plus tard.", "", true),
            CuratedCard(CardKind.TENTATION, 3, "Tentation hot", "Gardez cette carte : préparez une ambiance volontairement différente de d'habitude — lumière, lieu ou musique — pour une prochaine soirée.", "", true),
            CuratedCard(CardKind.TENTATION, 4, "Tentation hot", "Gardez cette carte : planifiez une session où l'un mène la première moitié et l'autre la seconde.", "", true),
            CuratedCard(CardKind.TENTATION, 4, "Tentation hot", "Gardez cette carte : choisissez une carte hot favorite et rejouez-la plus tard avec une seule nouvelle règle.", "", true)
        ),
        GameMode.SECRET to listOf(
            CuratedCard(CardKind.QUESTION, 3, "Secret · préférence", "Quand tu te laisses guider, qu'est-ce qui te met le plus en confiance : des consignes claires, un rythme lent, beaucoup de contact ou la possibilité de reprendre le contrôle facilement ?", "", false),
            CuratedCard(CardKind.QUESTION, 3, "Secret · préférence", "Quel type de pouvoir t'attire le plus dans un jeu adulte : choisir le rythme, choisir la position, choisir quand on peut continuer ou choisir ce qui est interdit temporairement ?", "", false),
            CuratedCard(CardKind.QUESTION, 3, "Secret · préférence", "Quelle part du plaisir vient pour toi de l'anticipation par rapport à l'action elle-même ?", "", false),
            CuratedCard(CardKind.QUESTION, 3, "Secret · préférence", "Quel scénario te semble excitant surtout parce qu'il change les rôles habituels entre vous ?", "", false),
            CuratedCard(CardKind.QUESTION, 3, "Secret · préférence", "Tu préfères une ambiance très dirigée ou une règle simple qui laisse beaucoup de liberté à l'intérieur ?", "", false),
            CuratedCard(CardKind.QUESTION, 3, "Secret · préférence", "Quelle chose aimerais-tu oser demander plus directement dans un moment adulte ?", "", false),
            CuratedCard(CardKind.QUESTION, 3, "Secret · préférence", "Quelle famille de positions t'attire le plus en ce moment : face à face, côté, dessus, assise, debout ou avec appui ?", "", false),
            CuratedCard(CardKind.QUESTION, 3, "Secret · préférence", "Quel type de teasing te semble le plus puissant : attendre, interrompre, interdire temporairement ou recommencer plus lentement ?", "", false),
            CuratedCard(CardKind.QUESTION, 3, "Secret · préférence", "Y a-t-il une règle simple qui rend immédiatement un moment plus intense pour toi ?", "", false),
            CuratedCard(CardKind.QUESTION, 3, "Secret · préférence", "Qu'est-ce qui te permet de te sentir libre de dire “pas ça” sans casser l'ambiance ?", "", false),
            CuratedCard(CardKind.QUESTION, 4, "Secret · aveu", "Quel fantasme te plaît davantage à imaginer qu'à réaliser — et qu'est-ce qui le rend séduisant dans ta tête ?", "", false),
            CuratedCard(CardKind.QUESTION, 4, "Secret · aveu", "Quelle dynamique te surprendrait le plus si tu découvrais qu'elle plaît beaucoup à l'autre ?", "", false),
            CuratedCard(CardKind.QUESTION, 4, "Secret · aveu", "Y a-t-il une chose que tu classerais aujourd'hui en “peut-être”, alors qu'elle était clairement “non” il y a quelques années ?", "", false),
            CuratedCard(CardKind.QUESTION, 4, "Secret · aveu", "Quel élément de contrôle est excitant pour toi tant qu'il reste facile à arrêter immédiatement ?", "", false),
            CuratedCard(CardKind.QUESTION, 4, "Secret · aveu", "Quelle nouveauté aimerais-tu explorer d'abord par une conversation, avant même de décider si vous la testez ?", "", false),
            CuratedCard(CardKind.QUESTION, 4, "Secret · aveu", "Tu préfères être surpris(e) à l'intérieur de limites déjà fixées, ou savoir à l'avance ce qui va se passer ?", "", false),
            CuratedCard(CardKind.QUESTION, 4, "Secret · aveu", "Quelle tenue, lumière ou mise en scène change le plus ton état d'esprit dans un moment très adulte ?", "", false),
            CuratedCard(CardKind.QUESTION, 4, "Secret · aveu", "Parmi les mots, le regard, le contrôle du rythme et la contrainte volontaire, lequel a le plus de pouvoir sur toi ?", "", false),
            CuratedCard(CardKind.QUESTION, 4, "Secret · aveu", "Qu'est-ce qui te ferait dire qu'une session a été “très hot” même si elle n'a pas été particulièrement longue ?", "", false),
            CuratedCard(CardKind.QUESTION, 4, "Secret · aveu", "Quelle limite mérite selon toi d'être dite très clairement même quand vous vous connaissez depuis longtemps ?", "", false),
            CuratedCard(CardKind.QUESTION, 5, "Secret · fantasme", "Si vous construisiez un scénario adulte entièrement sur mesure, quels seraient le rôle de A, le rôle de B et la règle principale ?", "", false),
            CuratedCard(CardKind.QUESTION, 5, "Secret · fantasme", "Quel fantasme pourrait être adapté en version réaliste, courte et confortable sans perdre ce qui le rend excitant ?", "", false),
            CuratedCard(CardKind.QUESTION, 5, "Secret · fantasme", "Quelle combinaison te paraît la plus forte : contrôle + attente, rôle + tenue, position + regard, ou mots + interdiction temporaire ?", "", false),
            CuratedCard(CardKind.QUESTION, 5, "Secret · fantasme", "Quel niveau de lâcher-prise te plaît vraiment : léger, marqué, très dirigé, ou variable selon le moment ?", "", false),
            CuratedCard(CardKind.QUESTION, 5, "Secret · fantasme", "Qu'est-ce qui serait plus excitant pour toi : ne pas savoir quelle carte arrive ou savoir exactement ce qui arrive mais devoir attendre ?", "", false),
            CuratedCard(CardKind.QUESTION, 5, "Secret · fantasme", "Quel type de finale te donnerait le plus envie de refaire une session Secret un autre soir ?", "", false),
            CuratedCard(CardKind.QUESTION, 5, "Secret · fantasme", "S'il fallait choisir une seule chose à pousser vraiment plus loin tout en gardant le reste familier, ce serait quoi ?", "", false),
            CuratedCard(CardKind.QUESTION, 5, "Secret · fantasme", "Quel mot ou signal pourrait devenir votre manière privée de dire “continue exactement comme ça” ?", "", false),
            CuratedCard(CardKind.QUESTION, 5, "Secret · fantasme", "Quelle position vous semble attirante mais mérite d'abord d'être comprise tranquillement avant d'être testée ?", "", false),
            CuratedCard(CardKind.QUESTION, 5, "Secret · fantasme", "Dans un scénario de contrôle consenti, quelle règle te semblerait la plus excitante tout en restant simple à respecter ?", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi Secret", "Pendant une minute, une personne mène entièrement les baisers et le rythme. L'autre ne peut utiliser que trois mots : plus lent, pareil, stop.", "Rôles clairs, sortie claire.", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi Secret", "Une personne reste immobile pendant 20 secondes pendant que l'autre crée l'anticipation avec proximité, regard et toucher sur des zones déjà confortables. Ensuite seulement, elle peut répondre.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi Secret", "Choisissez deux zones autorisées. Pendant 60 secondes, la personne qui mène alterne entre les deux sans annoncer quand elle change.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi Secret", "L'un donne trois consignes sensuelles courtes. L'autre en accepte deux, en refuse ou modifie une, puis les joue dans l'ordre de son choix.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi Secret", "Pendant 90 secondes, gardez une règle unique : une personne choisit le rythme, l'autre choisit où le contact est autorisé.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi Secret", "Choisissez une position confortable de la bibliothèque. Installez-vous sans commencer tout de suite et restez 20 secondes à trouver le meilleur angle et les meilleurs appuis.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi Secret", "Une personne ferme les yeux si elle en a envie. L'autre annonce avant chaque nouveau type de contact ce qu'elle va faire. Après 45 secondes, inversez.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi Secret", "Pendant une minute, la personne qui reçoit guide la main de l'autre au lieu de donner des explications. Pas de devinette : soyez précis.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi Secret", "Choisissez un mot-clé qui signifie “continue exactement comme ça”. Pendant 60 secondes, la personne qui reçoit n'a droit qu'à ce mot, “moins” ou “stop”.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi Secret", "Une personne choisit une carte Hot favorite. L'autre doit la rendre plus intense sans ajouter de nouvelle zone : seulement avec rythme, regard ou parole.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi Secret", "Retirez chacun un vêtement si vous le souhaitez. Pendant 45 secondes, l'un reste debout pendant que l'autre crée la tension sans se précipiter vers la suite.", "", false),
            CuratedCard(CardKind.CHALLENGE, 3, "Défi Secret", "Choisissez un rôle pour une minute : celui qui provoque et celui qui résiste volontairement. Au bout d'une minute, échangez ou arrêtez.", "", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi Secret", "Si vous êtes tous les deux d'accord avec l'idée, une personne garde les mains derrière le dos sans être attachée pendant 45 secondes. L'autre mène et reste attentive à toute demande de changement.", "", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi Secret", "Une personne choisit une position de niveau 2 ou 3. L'autre choisit la règle : très lent, pauses imposées ou regard maintenu.", "", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi Secret", "Pendant deux minutes, la personne qui mène peut augmenter l'intensité une seule fois. La personne qui reçoit décide quand cette montée a lieu.", "", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi Secret", "Choisissez trois actions déjà appréciées dans cette session. Une personne décide de l'ordre, l'autre décide de la durée de chacune.", "", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi Secret", "Si le bandeau fait partie de vos envies communes, utilisez-le pendant une minute. Sinon, la personne qui reçoit ferme simplement les yeux. La règle : annoncer tout changement important avant de le faire.", "", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi Secret", "Une personne n'a pas le droit d'initier pendant 60 secondes. Elle peut seulement accepter, ralentir, modifier ou arrêter ce que propose l'autre.", "", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi Secret", "Choisissez un accessoire ou vêtement que vous trouvez excitant. Mettez-le en scène pendant une minute avant de passer à autre chose.", "", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi Secret", "Pendant 90 secondes, la personne qui mène utilise volontairement des pauses de 5 secondes pour créer de la frustration. La personne qui reçoit peut supprimer une seule pause.", "", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi Secret", "Choisissez une position de la bibliothèque que vous connaissez déjà. Testez sa variante la plus lente et la plus confortable pendant une courte séquence.", "", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi Secret", "Une personne chuchote trois envies réalistes. L'autre répond à chacune par oui maintenant, peut-être plus tard, ou non. Jouez uniquement le premier “oui maintenant”.", "", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi Secret", "Pendant une minute, l'un guide uniquement par des phrases courtes : viens plus près, reste là, plus lent, attends, continue. L'autre garde le droit de modifier immédiatement.", "", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi Secret", "Choisissez un moment que vous trouvez très excitant habituellement et imposez une règle de stop-start : 20 secondes, 5 secondes de pause, 20 secondes, 5 secondes, puis libre.", "", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi Secret", "Si vous avez un jouet que vous utilisez déjà ensemble et que les deux en ont envie maintenant, intégrez-le pendant une minute. Sinon, remplacez cette carte par votre accessoire préféré.", "Aucune obligation d'introduire quelque chose de nouveau.", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi Secret", "Une personne choisit la tenue ou ce qui reste habillé. L'autre choisit le rythme. Gardez ces deux décisions pendant deux minutes.", "", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi Secret", "Placez-vous face à un miroir si vous en avez un et si ça vous plaît. Pendant 60 secondes, utilisez surtout le regard et la proximité plutôt que la vitesse.", "", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi Secret", "La personne qui reçoit choisit une zone favorite et une zone à éviter. La personne qui mène doit créer une minute très intense en respectant strictement ces deux informations.", "", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi Secret", "Choisissez un mot interdit pendant deux minutes. Chaque fois que quelqu'un le prononce, il doit s'arrêter trois secondes avant de reprendre.", "", false),
            CuratedCard(CardKind.CHALLENGE, 4, "Défi Secret", "Une personne donne une consigne. L'autre a trois options : oui, version plus douce, autre chose. Continuez jusqu'à avoir construit trois consignes acceptées.", "", false),
            CuratedCard(CardKind.CHALLENGE, 5, "Défi Secret", "Construisez une séquence de quatre minutes : 60 secondes d'attente, 60 secondes de guidage, 60 secondes de liberté, puis 60 secondes choisies par celui ou celle qui a reçu le moins de contrôle jusque-là.", "", false),
            CuratedCard(CardKind.CHALLENGE, 5, "Défi Secret", "Choisissez une position de niveau 4 ou 5 qui vous semble réaliste aujourd'hui. Prenez le temps de l'installer correctement, puis testez-la brièvement avant de décider si vous continuez.", "", false),
            CuratedCard(CardKind.CHALLENGE, 5, "Défi Secret", "Une personne mène pendant deux minutes avec une règle : elle doit maintenir la tension sans aller immédiatement vers ce que l'autre préfère le plus. La personne qui reçoit décide quand la règle prend fin.", "", false),
            CuratedCard(CardKind.CHALLENGE, 5, "Défi Secret", "Si une pratique précise fait déjà partie de votre oui-list commune, choisissez-en une et donnez-lui une règle nouvelle : rythme imposé, pauses, regard ou durée. Sinon, choisissez une carte position.", "", false),
            CuratedCard(CardKind.CHALLENGE, 5, "Défi Secret", "L'un choisit trois mots de commande acceptables pour les deux. Pendant 90 secondes, ce sont les seuls mots qu'il peut utiliser pour guider l'autre.", "", false),
            CuratedCard(CardKind.CHALLENGE, 5, "Défi Secret", "Une personne décide de la position. L'autre décide de la vitesse et peut la modifier trois fois maximum pendant deux minutes.", "", false),
            CuratedCard(CardKind.CHALLENGE, 5, "Défi Secret", "Jouez une minute d'abandon consenti : une personne suit le cadre décidé avant de commencer, l'autre reste responsable de respecter exactement ce cadre. Fin immédiate au moindre “stop”.", "", false),
            CuratedCard(CardKind.CHALLENGE, 5, "Défi Secret", "Choisissez ensemble une règle très hot mais simple : ne pas toucher une zone pendant une minute, attendre un signal avant de continuer, ou devoir demander avant chaque changement majeur. Jouez-la deux minutes.", "", false),
            CuratedCard(CardKind.CHALLENGE, 5, "Défi Secret", "La personne qui reçoit annonce ce qu'elle veut le plus maintenant. La personne qui mène construit une minute entière autour de l'attente avant de l'accorder.", "", false),
            CuratedCard(CardKind.CHALLENGE, 5, "Défi Secret", "Choisissez un scénario de rôle très simple : leader / invité(e), inconnu(e) / séduction, ordre / choix. Fixez une limite claire puis jouez seulement 90 secondes du scénario.", "", false),
            CuratedCard(CardKind.CHALLENGE, 5, "Défi Secret", "Si le sexe oral fait partie de vos envies communes du moment, la personne qui reçoit décide entièrement du rythme et peut interrompre à tout instant. Sinon, remplacez cette carte par une séquence de baisers et de mains sur vos zones préférées.", "", false),
            CuratedCard(CardKind.CHALLENGE, 5, "Défi Secret", "Une personne n'a pas le droit de demander “et maintenant ?” pendant deux minutes. Elle doit mener avec confiance dans les limites déjà connues, tout en restant attentive aux réactions et aux mots-clés.", "", false),
            CuratedCard(CardKind.CHALLENGE, 5, "Défi Secret", "Rejouez la carte la plus excitante de la soirée, mais ajoutez deux règles compatibles : une sur le rythme et une sur le contrôle. Rien d'autre ne change.", "", false),
            CuratedCard(CardKind.CHALLENGE, 5, "Défi Secret", "Choisissez votre position favorite dans la bibliothèque puis donnez-lui un scénario : très lent, dominant doux, silencieux ou regard constant. Jouez seulement la version choisie.", "", false),
            CuratedCard(CardKind.CHALLENGE, 5, "Défi Secret", "Finale libre : chacun dit une envie “oui maintenant”. Si elles sont compatibles, combinez-les. Sinon, choisissez celle qui demande le moins d'intensité comme point de départ.", "", false),
            CuratedCard(CardKind.SITUATION, 3, "Scénario Secret", "Vous avez quinze minutes seuls et vous voulez surtout créer de l'anticipation. Décidez d'une règle qui empêche volontairement d'aller trop vite.", "", false),
            CuratedCard(CardKind.SITUATION, 3, "Scénario Secret", "Vous êtes dans une chambre d'hôtel et l'un de vous veut être guidé. Définissez d'abord trois mots : continue, ralentis, stop. Ensuite seulement, choisissez qui mène.", "", false),
            CuratedCard(CardKind.SITUATION, 3, "Scénario Secret", "Une personne veut être surprise mais pas prise au dépourvu. Définissez ensemble la zone de jeu autorisée, puis laissez l'autre improviser à l'intérieur.", "", false),
            CuratedCard(CardKind.SITUATION, 3, "Scénario Secret", "Vous devez créer une scène adulte intense sans enlever tous vos vêtements. Quels éléments gardez-vous volontairement ?", "", false),
            CuratedCard(CardKind.SITUATION, 3, "Scénario Secret", "Vous voulez essayer une position nouvelle. Avant de la jouer, chacun doit pouvoir expliquer comment il pense s'installer et où seront ses appuis.", "", false),
            CuratedCard(CardKind.SITUATION, 3, "Scénario Secret", "Vous n'avez droit qu'à une seule consigne à la fois. Construisez une séquence de trois consignes qui monte progressivement.", "", false),
            CuratedCard(CardKind.SITUATION, 3, "Scénario Secret", "Vous devez rendre la prochaine minute très hot en utilisant surtout le regard et les mots. Qui prend le rôle le plus direct ?", "", false),
            CuratedCard(CardKind.SITUATION, 3, "Scénario Secret", "L'un veut du contrôle, l'autre veut garder beaucoup de liberté. Trouvez une règle qui crée du contrôle sans retirer la possibilité de choisir.", "", false),
            CuratedCard(CardKind.SITUATION, 4, "Scénario Secret", "Vous avez préparé une soirée avec une tenue ou un accessoire spécial. Décidez de la manière la plus lente de le faire entrer dans le jeu.", "", false),
            CuratedCard(CardKind.SITUATION, 4, "Scénario Secret", "Vous devez choisir une dynamique pour trois minutes : leader clair, alternance de contrôle, teasing strict ou exploration de position.", "", false),
            CuratedCard(CardKind.SITUATION, 4, "Scénario Secret", "Une personne veut qu'on lui dise quoi faire, mais seulement avec des consignes qu'elle a déjà validées. Donnez trois exemples acceptables avant de commencer.", "", false),
            CuratedCard(CardKind.SITUATION, 4, "Scénario Secret", "Imaginez une scène où l'un a le droit de dire “attends” autant qu'il veut, mais l'autre décide toujours quand reprendre après le signal “continue”.", "", false),
            CuratedCard(CardKind.SITUATION, 4, "Scénario Secret", "Vous voulez intégrer un objet, un accessoire ou un jouet déjà connu. Quel rôle précis lui donnez-vous pour éviter qu'il prenne toute la place dans la scène ?", "", false),
            CuratedCard(CardKind.SITUATION, 4, "Scénario Secret", "Vous devez créer un jeu de frustration sans utiliser la vitesse. Choisissez entre interdiction temporaire, pause, distance ou changement de rôle.", "", false),
            CuratedCard(CardKind.SITUATION, 4, "Scénario Secret", "Vous rejouez une expérience intime réussie, mais avec une différence nette : autre lieu, autre rythme, autre rôle ou autre position. Choisissez une seule différence.", "", false),
            CuratedCard(CardKind.SITUATION, 4, "Scénario Secret", "Une personne choisit la position, l'autre choisit quand elle commence et quand elle s'arrête. Qui prend quel choix ?", "", false),
            CuratedCard(CardKind.SITUATION, 4, "Scénario Secret", "Vous devez construire une scène autour d'un seul mot : contrôle, attente, obéissance, provocation ou abandon. Choisissez le mot qui correspond le mieux à vos limites communes.", "", false),
            CuratedCard(CardKind.SITUATION, 5, "Scénario Secret", "Vous avez une heure sans interruption. Construisez une session en quatre phases : teasing, montée, position, finale. Fixez une limite claire avant de commencer.", "", false),
            CuratedCard(CardKind.SITUATION, 5, "Scénario Secret", "Une personne veut lâcher prise davantage que d'habitude. Quelles deux garanties rendent cette idée excitante plutôt qu'inquiétante ?", "", false),
            CuratedCard(CardKind.SITUATION, 5, "Scénario Secret", "Vous choisissez une pratique déjà appréciée et vous la transformez en jeu de contrôle avec une règle unique. Quelle règle crée le plus de tension sans compliquer la scène ?", "", false),
            CuratedCard(CardKind.TENTATION, 3, "Tentation Secret", "Gardez cette carte : chacun prépare en privé une liste Oui / Peut-être / Non de cinq idées adultes, puis vous ne révélez que les correspondances Oui/Oui et Peut-être/Peut-être.", "", true),
            CuratedCard(CardKind.TENTATION, 3, "Tentation Secret", "Gardez cette carte : choisissez une position de la bibliothèque que vous voulez simplement étudier ensemble avant de décider si vous la testez.", "", true),
            CuratedCard(CardKind.TENTATION, 3, "Tentation Secret", "Gardez cette carte : préparez une tenue ou un détail d'ambiance que l'autre trouvera seulement au moment choisi.", "", true),
            CuratedCard(CardKind.TENTATION, 4, "Tentation Secret", "Gardez cette carte : planifiez une soirée où l'un mène la première moitié et l'autre la seconde, avec un mot de pause défini avant de commencer.", "", true),
            CuratedCard(CardKind.TENTATION, 4, "Tentation Secret", "Gardez cette carte : choisissez un fantasme et écrivez chacun séparément ce qui vous attire dedans et ce qui ne vous attire pas. Comparez ensuite.", "", true),
            CuratedCard(CardKind.TENTATION, 4, "Tentation Secret", "Gardez cette carte : préparez une session où la règle principale sera l'attente plutôt que la vitesse.", "", true),
            CuratedCard(CardKind.TENTATION, 4, "Tentation Secret", "Gardez cette carte : sélectionnez trois positions favorites et classez-les chacun en “ce soir”, “une autre fois”, “juste curieux”.", "", true),
            CuratedCard(CardKind.TENTATION, 5, "Tentation Secret", "Gardez cette carte : organisez une vraie session Secret de 30 à 60 minutes avec ambiance, rôle de départ, limite commune et finale libre.", "", true),
            CuratedCard(CardKind.TENTATION, 5, "Tentation Secret", "Gardez cette carte : choisissez une dynamique de contrôle consenti à explorer une prochaine fois et définissez précisément ce qui la rend acceptable pour chacun.", "", true),
            CuratedCard(CardKind.TENTATION, 5, "Tentation Secret", "Gardez cette carte : préparez une scène courte autour d'une position, d'une tenue et d'une règle de rythme — rien de plus. La simplicité doit rendre la scène plus intense.", "", true)
        )
    )



    // v12: contenu additionnel rédigé carte par carte. Les mécaniques s'inspirent
    // de patterns courants des jeux de couple (réponse privée, choix mutuel,
    // deviner l'autre, scénarios à embranchements), sans reprendre leur texte.
    private val v12Extras: Map<GameMode, List<CuratedCard>> = mapOf(
        GameMode.RELAX to listOf(
            CuratedCard(CardKind.QUESTION,1,"Choix calme","Sans vous concerter, montrez en même temps 1, 2 ou 3 doigts : 1 = silence ensemble, 2 = parler dix minutes, 3 = contact physique calme. Si vous avez le même chiffre, gardez cette idée pour ce soir.","Une mini compatibilité, sans bonne réponse."),
            CuratedCard(CardKind.QUESTION,1,"Ce qui aide vraiment","Quand tu es tendu(e), quelle phrase de ma part aide vraiment — et quelle phrase bien intentionnée t'agace plutôt ?","Donnez un exemple concret."),
            CuratedCard(CardKind.QUESTION,2,"Devine-moi","Devine lequel me ferait le plus de bien maintenant : qu'on m'écoute, qu'on m'aide, qu'on me fasse rire ou qu'on me laisse tranquille. Je réponds seulement après ton choix.","Pas de justification avant la révélation."),
            CuratedCard(CardKind.QUESTION,2,"Mode d'emploi","Quel signe discret montre que tu as besoin de ralentir avant même que tu le dises ?","L'autre peut poser une seule question pour mieux comprendre."),
            CuratedCard(CardKind.QUESTION,2,"À protéger","Quelle heure ou quel moment de notre semaine devrait devenir une petite zone protégée où on évite les tâches et les écrans ?","Choisissez quelque chose de réaliste."),
            CuratedCard(CardKind.CHALLENGE,1,"Deux minutes pour redescendre","Réglez un minuteur sur deux minutes. La première minute, restez côte à côte sans parler. La seconde, chacun dit une seule chose qu'il aimerait ne plus porter seul ce soir.","Pas besoin de résoudre le problème immédiatement."),
            CuratedCard(CardKind.CHALLENGE,1,"Le bon rythme","Une personne masse les épaules de l'autre pendant 45 secondes. À 15 et 30 secondes, la personne qui reçoit choisit seulement entre « plus lent », « pareil » ou « plus ferme ». Puis inversez.","Le jeu consiste à ajuster, pas à deviner."),
            CuratedCard(CardKind.CHALLENGE,2,"Service cinq étoiles","Demande : « Qu'est-ce qui te ferait gagner 10 % de confort maintenant ? » Puis fais exactement cette petite chose si elle est réalisable en moins de trois minutes.","Petit et concret."),
            CuratedCard(CardKind.CHALLENGE,2,"Déconnexion express","Posez les téléphones hors de portée pendant cinq minutes. Faites-vous une boisson ou installez-vous confortablement, puis choisissez ensemble une seule chose à ne pas faire ce soir.","Créer de l'espace compte aussi."),
            CuratedCard(CardKind.SITUATION,1,"Soirée sans programme","Il est 20 h, tout est annulé et personne n'attend rien de vous demain matin. Chacun propose sa soirée idéale en trois éléments maximum, puis cherchez le meilleur mélange des deux."),
            CuratedCard(CardKind.SITUATION,2,"Recharge","Vous avez exactement 90 minutes pour vous sentir mieux avant une semaine chargée. Interdiction de faire des corvées. Comment utilisez-vous ce temps ?"),
            CuratedCard(CardKind.TENTATION,1,"À garder · pause surprise","Gardez cette carte. Dans les sept prochains jours, l'un peut l'utiliser pour demander dix minutes ensemble sans téléphone, sans avoir à justifier pourquoi.",canSave=true),
            CuratedCard(CardKind.TENTATION,2,"À garder · délestage","Gardez cette carte. Une fois cette semaine, prenez spontanément à votre charge une petite tâche que l'autre déteste et dites simplement « celle-ci, je la prends ».",canSave=true)
        ),
        GameMode.FUN to listOf(
            CuratedCard(CardKind.QUESTION,1,"Devine avant moi","Quel talent totalement inutile est-ce que je pense avoir ? Écris mentalement ta réponse, puis je donne la mienne.","Un point imaginaire si ça correspond."),
            CuratedCard(CardKind.QUESTION,1,"Qui de nous deux ?","Qui de nous deux survivrait le mieux à 24 heures sans téléphone ? Comptez jusqu'à trois et pointez quelqu'un en même temps.","Si vous n'êtes pas d'accord, chacun plaide sa cause en 20 secondes."),
            CuratedCard(CardKind.QUESTION,2,"Classement secret","Classe en secret ces trois options pour une soirée improvisée : jeu, sortie, nourriture. Révélez vos classements en même temps et inventez une soirée avec vos deux premiers choix."),
            CuratedCard(CardKind.QUESTION,2,"Mauvaise idée parfaite","Quelle activité complètement ridicule accepterais-tu quand même de faire avec moi parce que ça deviendrait probablement un bon souvenir ?"),
            CuratedCard(CardKind.QUESTION,3,"Vrai ou bluff","Raconte deux petites anecdotes vraies sur toi et invente-en une troisième. L'autre doit trouver le bluff et peut poser deux questions maximum."),
            CuratedCard(CardKind.CHALLENGE,1,"Duel de regard","Regardez-vous sans parler. Le premier qui rit perd. Le gagnant choisit : prochain type de carte ou prochaine chanson.","Pas de grimace volontaire pendant les cinq premières secondes."),
            CuratedCard(CardKind.CHALLENGE,1,"Publicité absurde","Tu as 30 secondes pour vendre à l'autre un objet banal présent dans la pièce comme s'il coûtait 10 000 €. L'autre donne ensuite une note de conviction sur 5."),
            CuratedCard(CardKind.CHALLENGE,2,"Imitation ciblée","Imite une habitude reconnaissable de l'autre sans parler. Dès qu'elle est trouvée, l'autre doit en citer une de toi qu'il trouve attachante plutôt qu'agaçante."),
            CuratedCard(CardKind.CHALLENGE,2,"Trois choix, un piège","Propose trois mini-défis faisables maintenant. Deux doivent être réellement acceptables pour toi, un doit être volontairement absurde. L'autre choisit avant de savoir lequel était le piège."),
            CuratedCard(CardKind.CHALLENGE,2,"Quiz flash","Pose cinq questions ultra-courtes sur tes habitudes : boisson, série, plat, tic, heure préférée. Un point par bonne réponse. À trois points ou plus, le gagnant choisit la prochaine carte."),
            CuratedCard(CardKind.CHALLENGE,3,"Mission personnage","Pendant deux minutes, vous devez continuer la conversation en jouant chacun un personnage choisi par l'autre. Interdiction de casser le personnage sauf pour dire stop."),
            CuratedCard(CardKind.SITUATION,1,"Le pire hôtel","Vous venez d'arriver dans un hôtel catastrophique mais déjà payé. Chacun invente le détail le plus absurde. Assemblez les deux pour créer l'avis Google le plus drôle possible."),
            CuratedCard(CardKind.SITUATION,2,"Plan B","Votre sortie idéale vient d'être annulée au dernier moment. Vous avez 30 € et deux heures. Chacun propose un plan B puis combinez les meilleurs éléments."),
            CuratedCard(CardKind.SITUATION,2,"Jeu télévisé","Vous êtes en finale d'un jeu sur votre couple. La dernière manche contient trois thèmes : habitudes, souvenirs, goûts. Quel thème chacun choisit-il pour répondre sur l'autre ?"),
            CuratedCard(CardKind.SITUATION,3,"Échange de rôles","Pendant dix minutes demain, chacun doit volontairement adopter une petite habitude de l'autre. Laquelle choisiriez-vous pour que ce soit drôle sans être blessant ?"),
            CuratedCard(CardKind.TENTATION,1,"À garder · joker fun","Gardez cette carte. À n'importe quel moment d'une prochaine partie, son propriétaire peut remplacer un défi par un défi drôle inventé sur place, accepté par les deux.",canSave=true),
            CuratedCard(CardKind.TENTATION,2,"À garder · pari","Gardez cette carte. Choisissez un mini pari pour la semaine. Le perdant prépare le dessert, le snack ou la boisson du gagnant.",canSave=true)
        ),
        GameMode.ROMANTIC to listOf(
            CuratedCard(CardKind.QUESTION,1,"Souvenir précis","Quel détail très précis d'un de nos premiers rendez-vous ou débuts de relation est resté dans ta tête alors qu'il semblerait insignifiant à quelqu'un d'autre ?"),
            CuratedCard(CardKind.QUESTION,1,"Devine ce qui compte","Devine laquelle de ces choses compte le plus pour moi aujourd'hui : du temps seul à deux, davantage de petites attentions, plus de projets, plus de spontanéité. Je révèle après ton choix."),
            CuratedCard(CardKind.QUESTION,2,"Manière d'aimer","Quand tu te sens aimé(e) par moi, qu'est-ce qui fait la différence : l'intention, la régularité, la surprise, les mots ou le contact ? Donne un exemple réel."),
            CuratedCard(CardKind.QUESTION,2,"Futur concret","Imagine-nous dans un an lors d'une semaine vraiment réussie. Qu'est-ce qui a changé dans notre quotidien, même légèrement ?"),
            CuratedCard(CardKind.QUESTION,2,"Ce que tu gardes","Quelle habitude de moi pensais-tu banale au début mais que tu serais triste de perdre aujourd'hui ?"),
            CuratedCard(CardKind.QUESTION,3,"Ce que je ne vois pas","Dans quelle situation te sens-tu parfois seul(e) même quand je suis physiquement là ?","Répondez avec un besoin, pas une accusation."),
            CuratedCard(CardKind.QUESTION,3,"Sécurité","Qu'est-ce que je pourrais faire plus souvent pour que tu te sentes libre de me dire une chose difficile sans craindre ma réaction ?"),
            CuratedCard(CardKind.QUESTION,3,"Version de nous","Quelle version de notre couple aimerais-tu retrouver un peu plus : celle qui sortait, celle qui parlait tard, celle qui improvisait, celle qui riait pour rien — ou une autre ?"),
            CuratedCard(CardKind.CHALLENGE,1,"Merci, mais précisément","Chacun remercie l'autre pour une chose faite au cours des sept derniers jours. Interdiction de répondre par quelque chose de général comme « merci d'être là »."),
            CuratedCard(CardKind.CHALLENGE,1,"Photo mentale","Fermez les yeux dix secondes. Pensez au même souvenir choisi ensemble, puis chacun décrit trois détails dont il se rappelle. Comparez ce que vos mémoires ont gardé."),
            CuratedCard(CardKind.CHALLENGE,2,"Lettre en trois phrases","Chacun prépare mentalement trois phrases : « J'aime quand… », « J'aimerais davantage… », « Je veux protéger… ». Dites-les sans interrompre l'autre."),
            CuratedCard(CardKind.CHALLENGE,2,"Le rendez-vous réaliste","Vous avez chacun 60 secondes pour inventer un rendez-vous faisable dans les 14 prochains jours pour moins de 50 €. Choisissez ensuite celui que vous avez réellement envie de planifier."),
            CuratedCard(CardKind.CHALLENGE,2,"Contact choisi","L'un choisit parmi main, bras, nuque, dos ou câlin. L'autre offre une minute de contact sans changer de zone. Puis inversez les rôles."),
            CuratedCard(CardKind.CHALLENGE,3,"Une demande claire","Chacun formule une seule demande positive pour les prochains jours : quelque chose que l'autre peut faire, plutôt qu'une chose qu'il devrait arrêter."),
            CuratedCard(CardKind.SITUATION,2,"Retrouvailles","Imaginez que vous avez passé trois semaines séparés et que vous avez seulement une soirée ensemble. Quelles sont les trois choses que vous voudriez vraiment faire ?"),
            CuratedCard(CardKind.SITUATION,3,"Capsule temporelle","Vous pouvez laisser à votre couple du futur une note de quatre lignes à lire dans cinq ans. Que doit-elle absolument rappeler ?"),
            CuratedCard(CardKind.TENTATION,2,"À garder · rendez-vous surprise","Gardez cette carte. Dans le mois, son propriétaire organise un mini rendez-vous dont il ne révèle que la durée et la tenue utile, pas l'activité.",canSave=true),
            CuratedCard(CardKind.TENTATION,3,"À garder · question différée","Gardez cette carte. Écrivez mentalement une question que vous aimeriez poser dans un moment calme. Utilisez la carte lorsque vous aurez vraiment le temps d'écouter la réponse.",canSave=true)
        ),
        GameMode.HOT to listOf(
            CuratedCard(CardKind.QUESTION,2,"Oui / Peut-être / Non","Chacun choisit en silence : « être guidé(e) sans savoir la suite pendant deux minutes ». Révélez seulement Oui, Peut-être ou Non. Si vous avez deux Oui, gardez l'idée pour plus tard dans la partie."),
            CuratedCard(CardKind.QUESTION,2,"Ce qui crée la tension","Qu'est-ce qui te fait le plus monter en envie avant même qu'il se passe quelque chose : le regard, l'attente, les mots, la tenue, le contexte ou le toucher ?"),
            CuratedCard(CardKind.QUESTION,2,"Devine mon choix","Selon toi, qu'est-ce que je préfère quand on flirte : que tu prennes l'initiative, que tu me provoques puis attends, que tu me demandes clairement ou que tu me laisses venir ? Je réponds après ta prédiction."),
            CuratedCard(CardKind.QUESTION,3,"Rythme","Quel changement de rythme te fait le plus d'effet : ralentir quand ça devient intense, accélérer brièvement, faire une pause volontaire ou garder exactement le même tempo ?"),
            CuratedCard(CardKind.QUESTION,3,"Contexte","Quel endroit réaliste de la maison change le plus l'ambiance pour toi, même sans rien faire de particulièrement différent ?"),
            CuratedCard(CardKind.QUESTION,3,"À refaire","Pense à un moment intime particulièrement réussi entre nous. Sans raconter toute la scène, quel ingrédient précis aimerais-tu retrouver : spontanéité, lenteur, initiative, parole, nouveauté ou autre ?"),
            CuratedCard(CardKind.QUESTION,4,"Permission","Y a-t-il quelque chose que tu aimerais que j'ose davantage initier sans avoir à te demander à chaque seconde, à condition qu'on ait défini clairement le cadre avant ?"),
            CuratedCard(CardKind.QUESTION,4,"Signal privé","Quel geste ou mot pourrait devenir notre signal privé pour dire « j'en veux davantage » sans casser le moment ?"),
            CuratedCard(CardKind.CHALLENGE,2,"Tension en trois étapes","30 secondes de regard et proximité sans toucher. Puis 30 secondes de baisers seulement. Ensuite, celui ou celle qui a le plus envie de continuer choisit la prochaine étape."),
            CuratedCard(CardKind.CHALLENGE,2,"Guide-moi","Une personne place la main de l'autre exactement là où elle veut un contact confortable. Pendant 45 secondes, pas de devinette : la personne qui reçoit ajuste le rythme avec sa propre main."),
            CuratedCard(CardKind.CHALLENGE,2,"Deux zones","Choisissez ensemble deux zones que vous avez envie d'inclure maintenant. Pendant une minute, la personne qui mène ne peut utiliser que ces deux zones et doit jouer uniquement sur le rythme et l'attente."),
            CuratedCard(CardKind.CHALLENGE,3,"Stop-start","Choisissez une activité intime déjà familière. Faites 20 secondes, pause de cinq secondes sans s'éloigner, puis 20 secondes. La personne qui reçoit décide si la troisième séquence est plus lente, identique ou plus intense."),
            CuratedCard(CardKind.CHALLENGE,3,"Choix caché","Chacun choisit en silence entre A : mener, B : recevoir, C : alterner. Révélez ensemble. Si vos choix se complètent, jouez-les 90 secondes. Sinon, faites C."),
            CuratedCard(CardKind.CHALLENGE,3,"Le mot utile","Pendant 90 secondes, la personne qui reçoit ne guide qu'avec quatre mots : « continue », « plus lent », « change », « stop ». L'autre écoute au lieu d'essayer d'impressionner."),
            CuratedCard(CardKind.CHALLENGE,3,"Interdit de se presser","Choisissez ce que vous faites naturellement quand l'envie monte. Cette fois, interdiction d'y aller directement pendant une minute : restez juste avant et faites durer l'anticipation."),
            CuratedCard(CardKind.CHALLENGE,3,"Inversion","Une personne mène pendant 45 secondes. Au signal, vous échangez immédiatement les rôles en gardant exactement le même niveau d'intensité."),
            CuratedCard(CardKind.CHALLENGE,4,"Trois consignes","La personne qui mène propose trois consignes courtes et concrètes. L'autre répond à chacune par « oui », « plus doux » ou « autre chose ». Jouez seulement ce qui a obtenu un oui clair."),
            CuratedCard(CardKind.CHALLENGE,4,"Contrôle partagé","Pendant deux minutes, l'un choisit la position ou la proximité, l'autre contrôle entièrement le rythme. À la moitié, échangez ces deux pouvoirs."),
            CuratedCard(CardKind.CHALLENGE,4,"Pause imposée","Une personne peut imposer trois pauses de cinq secondes pendant les deux prochaines minutes. L'autre peut annuler une seule pause quand elle le souhaite."),
            CuratedCard(CardKind.CHALLENGE,4,"Le partenaire choisit","La personne qui reçoit donne trois options qu'elle apprécierait réellement maintenant. La personne qui mène en choisit une et la développe pendant 90 secondes au lieu de changer constamment."),
            CuratedCard(CardKind.SITUATION,2,"Le message","Vous êtes dans deux pièces différentes et vous avez droit à un seul message pour faire comprendre à l'autre que vous voulez une soirée plus chaude. Qu'écrivez-vous sans être cru ni vague ?"),
            CuratedCard(CardKind.SITUATION,3,"Retour à la maison","Vous savez tous les deux depuis l'après-midi que vous aurez enfin du temps seuls ce soir. Comment entretenez-vous l'anticipation sans tout révéler ? Chacun propose une idée."),
            CuratedCard(CardKind.SITUATION,3,"Règle de soirée","Vous pouvez imposer une seule règle sensuelle pendant 20 minutes : lenteur, initiative alternée, interdiction de se déshabiller trop vite, parole obligatoire ou silence. Laquelle choisissez-vous ?"),
            CuratedCard(CardKind.SITUATION,4,"Scénario à deux choix","Une personne choisit l'ambiance : tendre ou dominante légère. L'autre choisit le cadre : canapé ou chambre. Construisez une mini-scène de trois minutes avec ces deux décisions."),
            CuratedCard(CardKind.TENTATION,2,"À garder · invitation","Gardez cette carte. Dans les sept jours, envoyez à l'autre un message qui propose clairement un moment intime plus tard, avec une seule indication sur l'ambiance souhaitée.",canSave=true),
            CuratedCard(CardKind.TENTATION,3,"À garder · oui privé","Gardez cette carte. Chacun note mentalement une envie qu'il n'ose pas toujours proposer. Plus tard, révélez seulement si elle est dans votre zone Oui, Peut-être ou Non avant d'en parler davantage.",canSave=true),
            CuratedCard(CardKind.TENTATION,4,"À garder · carte blanche encadrée","Gardez cette carte. À utiliser un jour où vous en avez tous les deux envie : l'un reçoit cinq minutes d'initiative totale à l'intérieur de limites définies ensemble juste avant.",canSave=true)
        ),
        GameMode.SECRET to listOf(
            CuratedCard(CardKind.QUESTION,3,"Secret · Oui / Peut-être / Non","Répondez chacun sans commenter : « laisser l'autre décider du rythme pendant trois minutes ». Révélez Oui, Peut-être ou Non en même temps. Deux Oui = idée compatible ; sinon, discutez seulement si les deux en ont envie."),
            CuratedCard(CardKind.QUESTION,3,"Secret · rôle","Lequel t'attire le plus ce soir : mener, te laisser guider, alterner, ou rester totalement égalitaires ? Donne aussi ce qui rendrait ce rôle confortable pour toi."),
            CuratedCard(CardKind.QUESTION,3,"Secret · intensité","Sur une échelle de 1 à 5, où est ton envie d'expérimenter ce soir ? Révélez vos chiffres ensemble et jouez au niveau le plus bas des deux."),
            CuratedCard(CardKind.QUESTION,3,"Secret · permission","Quelle initiative très concrète serais-tu content(e) que je prenne plus souvent quand le contexte est clairement intime ?"),
            CuratedCard(CardKind.QUESTION,3,"Secret · frein","Qu'est-ce qui peut casser ton excitation le plus vite : aller trop vite, trop parler, ne pas assez parler, changer trop souvent, manque de confort ou autre ?"),
            CuratedCard(CardKind.QUESTION,4,"Secret · fantasme réaliste","Parmi tes envies, laquelle pourrait réellement être essayée à la maison sans achat, sans préparation compliquée et sans dépasser nos limites ?"),
            CuratedCard(CardKind.QUESTION,4,"Secret · contrôle","Dans un jeu de contrôle consenti, qu'est-ce qui t'attire vraiment : attendre, recevoir des consignes, en donner, avoir une règle, ne pas connaître la prochaine étape ou autre ?"),
            CuratedCard(CardKind.QUESTION,4,"Secret · langage","Quels mots ou quel ton te font de l'effet, et lesquels te sortent immédiatement du moment ?","Il est utile de connaître les deux."),
            CuratedCard(CardKind.QUESTION,4,"Secret · exclusivité","Y a-t-il une chose que tu aimerais garder comme un code uniquement entre nous : un mot, une tenue, un rituel, une règle ou un endroit ?"),
            CuratedCard(CardKind.QUESTION,5,"Secret · limite excitante","Quelle limite claire rendrait une expérience plus excitante justement parce que tu saurais exactement jusqu'où elle peut aller ?"),
            CuratedCard(CardKind.QUESTION,5,"Secret · à essayer un jour","Quelle idée t'excite en imagination mais demanderait une vraie discussion avant d'être essayée ? Ne décidez rien maintenant : nommez seulement ce qui devrait être clarifié."),
            CuratedCard(CardKind.CHALLENGE,3,"Secret · choix compatible","Chacun choisit en silence A : guider, B : être guidé, C : alterner. Révélez ensemble. Si A rencontre B, jouez 90 secondes ; sinon faites C pendant une minute."),
            CuratedCard(CardKind.CHALLENGE,3,"Secret · menu trois options","La personne qui reçoit donne trois choses qu'elle apprécierait maintenant. La personne qui mène en choisit une. Pendant 90 secondes, elle reste sur cette idée et l'affine au lieu de multiplier les changements."),
            CuratedCard(CardKind.CHALLENGE,3,"Secret · attente contrôlée","Pendant une minute, approchez-vous de ce que vous savez que l'autre aime sans y aller directement. La personne qui reçoit peut dire « maintenant » une seule fois pour mettre fin à l'attente."),
            CuratedCard(CardKind.CHALLENGE,3,"Secret · yeux fermés","Si la personne qui reçoit le souhaite, elle ferme les yeux pendant 60 secondes. Chaque changement important est annoncé juste avant. Elle peut répondre « oui », « plus doux », « autre chose » ou « stop »."),
            CuratedCard(CardKind.CHALLENGE,3,"Secret · miroir de rythme","Une personne choisit un rythme pendant 30 secondes. Après une pause de cinq secondes, l'autre reprend le même rythme pendant 30 secondes puis choisit une seule variation."),
            CuratedCard(CardKind.CHALLENGE,3,"Secret · position comprise","Ouvrez la bibliothèque de positions et choisissez-en une de difficulté 1 à 3. Regardez l'illustration ensemble, identifiez les appuis, puis décidez si vous voulez seulement l'essayer brièvement ou la garder pour une autre fois."),
            CuratedCard(CardKind.CHALLENGE,4,"Secret · trois règles","Choisissez ensemble trois règles pour deux minutes : une sur le rythme, une sur qui mène et une sur un mot d'arrêt ou d'ajustement. Ensuite jouez exactement ce cadre sans rajouter de règle en cours de route."),
            CuratedCard(CardKind.CHALLENGE,4,"Secret · contrôle partagé","Pendant trois minutes, l'un décide de ce qui se passe, l'autre décide de la vitesse et peut demander trois changements maximum. À mi-parcours, échangez les rôles si vous le souhaitez."),
            CuratedCard(CardKind.CHALLENGE,4,"Secret · frustration choisie","La personne qui reçoit choisit ce qu'elle voudrait le plus. La personne qui mène doit attendre 90 secondes avant de l'inclure, en restant uniquement sur des choses déjà appréciées. Le mot « maintenant » annule l'attente."),
            CuratedCard(CardKind.CHALLENGE,4,"Secret · consignes utiles","La personne qui mène dispose de cinq consignes : viens plus près, reste là, plus lent, encore, attends. Pendant 90 secondes, elle ne peut guider qu'avec ces mots. Toute demande de modification de l'autre passe avant la règle."),
            CuratedCard(CardKind.CHALLENGE,4,"Secret · carte position","Choisissez une position illustrée qui vous attire. Une personne règle les appuis et le confort, l'autre choisit le rythme. Après 45 secondes, faites un check rapide : continuer, ajuster ou changer."),
            CuratedCard(CardKind.CHALLENGE,4,"Secret · scénario chambre d'hôtel","Imaginez que vous vous retrouvez après plusieurs jours sans intimité. Pendant trois minutes, jouez surtout l'anticipation : arrivée, regard, rapprochement, choix de qui prend l'initiative. Vous pouvez arrêter le scénario dès qu'il devient artificiel."),
            CuratedCard(CardKind.CHALLENGE,4,"Secret · règle du vêtement","Chacun choisit un vêtement de l'autre qu'il aimerait garder plus longtemps. Pendant deux minutes, vous ne pouvez pas retirer ces deux éléments. Jouez sur le contraste plutôt que sur la vitesse."),
            CuratedCard(CardKind.CHALLENGE,4,"Secret · cinq minutes promises","Décidez maintenant d'une séquence de cinq minutes pour plus tard : 1 minute lente, 1 minute guidée, 1 minute libre, 1 minute avec une position choisie, 1 minute décidée sur le moment. Gardez la carte si vous préférez la faire un autre jour.",canSave=true),
            CuratedCard(CardKind.CHALLENGE,5,"Secret · montée en quatre actes","Construisez quatre étapes d'une minute : anticipation, initiative d'une personne, inversion des rôles, puis finale choisie ensemble. Avant de commencer, chacun nomme une chose qu'il veut et une chose qu'il ne veut pas dans la séquence."),
            CuratedCard(CardKind.CHALLENGE,5,"Secret · choix de pouvoir","Une personne choisit entre contrôler le rythme ou contrôler les changements de position. L'autre reçoit l'autre pouvoir. Pendant trois minutes, aucun ne prend la décision de l'autre."),
            CuratedCard(CardKind.CHALLENGE,5,"Secret · oui-list commune","Chacun cite trois choses qu'il serait heureux d'inclure maintenant. Gardez seulement l'intersection de vos listes. La personne qui mène construit deux minutes uniquement avec cette intersection."),
            CuratedCard(CardKind.CHALLENGE,5,"Secret · position avancée","Choisissez une position illustrée de difficulté 4 ou 5 uniquement si elle paraît physiquement réaliste aujourd'hui. Prenez 30 secondes pour les appuis, testez-la doucement, puis décidez ensemble de continuer, simplifier ou changer."),
            CuratedCard(CardKind.CHALLENGE,5,"Secret · le droit d'attendre","Pendant deux minutes, une personne mène mais n'a pas le droit d'aller immédiatement vers ce qu'elle sait être le plus efficace. La personne qui reçoit peut lever cette règle à tout moment avec le mot choisi avant de commencer."),
            CuratedCard(CardKind.CHALLENGE,5,"Secret · inversion surprise","Commencez avec un rôle clairement défini : meneur et receveur. Après une durée choisie entre 45 et 90 secondes par le receveur, celui-ci annonce « inverse » et les rôles changent immédiatement."),
            CuratedCard(CardKind.SITUATION,3,"Secret · message privé","Vous êtes séparés pendant la journée. Quel message pourrait créer de l'anticipation pour ce soir tout en laissant à l'autre une vraie possibilité de répondre qu'il ou elle n'est pas dans le mood ?"),
            CuratedCard(CardKind.SITUATION,3,"Secret · porte fermée","Vous avez enfin 20 minutes sans interruption. Chacun choisit secrètement entre parler d'une envie, jouer une carte chaude, essayer une position ou simplement se rapprocher. Révélez ensemble."),
            CuratedCard(CardKind.SITUATION,4,"Secret · scénario inconnu","L'un choisit un contexte parmi hôtel, rendez-vous clandestin fictif, retrouvailles ou jeu de pouvoir léger. L'autre choisit qui mène. Jouez seulement l'ouverture de la scène pendant trois minutes."),
            CuratedCard(CardKind.SITUATION,4,"Secret · interdiction","Vous pouvez instaurer une seule interdiction temporaire et consensuelle pendant cinq minutes : ne pas accélérer, ne pas changer de rôle, ne pas enlever un vêtement précis, ou ne pas utiliser un mot. Laquelle crée le plus de tension ?"),
            CuratedCard(CardKind.SITUATION,5,"Secret · carte blanche","Vous avez dix minutes et une vraie carte blanche à l'intérieur de votre oui-list commune. Avant de commencer, chacun donne un « je veux », un « peut-être » et un « pas ce soir ». Construisez la scène uniquement avec ce qui reste."),
            CuratedCard(CardKind.TENTATION,3,"À garder · désir compatible","Gardez cette carte. Chacun pense à une envie intime. À un moment calme, révélez d'abord seulement Oui / Peut-être / Non à l'idée de l'entendre. Si vous avez deux Oui, partagez ensuite les envies.",canSave=true),
            CuratedCard(CardKind.TENTATION,4,"À garder · rôle réservé","Gardez cette carte. Lors d'une prochaine soirée, son propriétaire choisit à l'avance s'il préfère mener ou être guidé. L'autre peut accepter, proposer l'inverse ou reporter sans justification.",canSave=true),
            CuratedCard(CardKind.TENTATION,4,"À garder · position à tester","Gardez cette carte sur une position de la bibliothèque qui vous attire tous les deux. Avant de l'essayer, relisez ensemble la fiche et décidez d'une variante de confort.",canSave=true),
            CuratedCard(CardKind.TENTATION,5,"À garder · scénario choisi","Gardez cette carte. Chacun écrit mentalement un scénario qu'il aimerait jouer. La prochaine fois, révélez seulement les thèmes ; si l'un plaît aux deux, celui qui ne l'a pas proposé choisit les limites et la durée.",canSave=true)
        )
    )


    private val destinyCards = listOf(
        CuratedCard(CardKind.DESTINY, 1, "Roue du destin", "La prochaine carte se joue en silence pendant 30 secondes.", "Adaptez la durée si nécessaire."),
        CuratedCard(CardKind.DESTINY, 1, "Roue du destin", "Inversez les rôles sur la prochaine carte.", ""),
        CuratedCard(CardKind.DESTINY, 1, "Roue du destin", "La prochaine carte peut être remplacée par une carte favorite déjà jouée ce soir.", ""),
        CuratedCard(CardKind.DESTINY, 1, "Roue du destin", "Choisissez maintenant : plus doux, plus drôle, plus romantique ou plus intense. La prochaine carte doit respecter ce choix.", ""),
        CuratedCard(CardKind.DESTINY, 1, "Roue du destin", "Faites une pause de 20 secondes avant de révéler la prochaine carte. Aucun téléphone, aucune discussion logistique.", ""),
        CuratedCard(CardKind.DESTINY, 2, "Wildcard", "La prochaine réponse doit contenir un exemple réel et précis, pas seulement une opinion.", ""),
        CuratedCard(CardKind.DESTINY, 2, "Wildcard", "La prochaine carte se joue deux fois : première version naturelle, deuxième version améliorée selon le retour de l'autre.", ""),
        CuratedCard(CardKind.DESTINY, 2, "Wildcard", "L'un choisit la durée, l'autre choisit le rythme de la prochaine carte.", ""),
        CuratedCard(CardKind.DESTINY, 2, "Wildcard", "Avant la prochaine manche, chacun annonce une chose qu'il veut davantage et une chose qu'il ne veut pas maintenant.", ""),
        CuratedCard(CardKind.DESTINY, 2, "Wildcard", "La prochaine carte doit être transformée en version de 30 secondes maximum.", ""),
        CuratedCard(CardKind.DESTINY, 3, "Twist Duo", "La prochaine carte devient un choix secret : chacun décide jouer / adoucir / passer, puis révélez en même temps.", ""),
        CuratedCard(CardKind.DESTINY, 3, "Twist Duo", "Reprenez une carte appréciée plus tôt, mais changez un seul élément : rôle, durée, rythme ou ambiance.", ""),
        CuratedCard(CardKind.DESTINY, 3, "Twist Duo", "La personne qui a le moins parlé depuis deux manches choisit le type de prochaine carte.", ""),
        CuratedCard(CardKind.DESTINY, 3, "Twist Duo", "La prochaine carte ne commence qu'après que chacun a dit ce qui la rendrait meilleure pour lui ou elle.", ""),
        CuratedCard(CardKind.DESTINY, 4, "Twist Duo", "La prochaine carte est jouée avec une règle supplémentaire choisie ensemble : lenteur, silence, regard, contrôle ou pause.", "")
    )

    private val memoryTemplates = listOf(
        "Racontez chacun votre version de : %s. Commencez par le détail que l'autre a probablement oublié.",
        "À propos de : %s, chacun dit d'abord l'émotion principale ressentie à ce moment-là, puis le souvenir précis.",
        "Pour : %s, choisissez le moment exact où vous vous êtes sentis le plus “équipe”.",
        "À partir de : %s, racontez chacun ce que vous pensiez à ce moment-là mais que vous n'avez probablement pas dit.",
        "Rejouez verbalement : %s. Qui se souvient le mieux du décor, du son ou de l'ambiance ?",
        "À partir de : %s, dites chacun ce que vous aimeriez revivre presque à l'identique et ce que vous changeriez légèrement.",
        "Pour : %s, chacun choisit le détail le plus tendre, le plus drôle ou le plus surprenant.",
        "À propos de : %s, dites ce que ce souvenir raconte sur votre couple aujourd'hui."
    )

    private val positions = listOf(
        SecretPosition(
            "Missionnaire", 1, "Face à face",
            "Une personne est allongée, l'autre au-dessus. Commencez avec des appuis simples et utilisez un coussin sous le bassin seulement si cela améliore réellement le confort.", 0,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Wiki-missionary.png",
            "Seedfeeder", "CC BY-SA 3.0",
            "https://commons.wikimedia.org/wiki/File:Wiki-missionary.png"
        ),
        SecretPosition(
            "Cuillère", 1, "Côté",
            "Les deux partenaires sont allongés sur le côté dans la même direction. Très stable, peu exigeante physiquement et facile à ralentir ou interrompre.", 1,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Wiki-spoons-sp.png",
            "Seedfeeder", "CC BY-SA 3.0",
            "https://commons.wikimedia.org/wiki/File:Wiki-spoons-sp.png"
        ),
        SecretPosition(
            "Lotus assis", 2, "Assise face à face",
            "Une personne s'assoit de façon stable, l'autre s'installe face à elle. Cherchez d'abord une position confortable pour les hanches et le dos avant de penser au mouvement.", 2,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Wiki-sitting-sp.png",
            "Seedfeeder", "CC BY-SA 3.0",
            "https://commons.wikimedia.org/wiki/File:Wiki-sitting-sp.png"
        ),
        SecretPosition(
            "Chevauchement", 2, "Dessus",
            "Une personne est allongée tandis que l'autre s'installe au-dessus. La personne au-dessus contrôle naturellement davantage l'angle et le rythme ; utilisez vos mains comme appuis si nécessaire.", 3,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Wiki-cowgirl.png",
            "Seedfeeder", "CC BY-SA 3.0",
            "https://commons.wikimedia.org/wiki/File:Wiki-cowgirl.png"
        ),
        SecretPosition(
            "Latérale croisée", 3, "Côté",
            "Les deux corps sont placés de côté avec un angle croisé. Prenez quelques secondes pour placer les jambes sans torsion et gardez un coussin à portée si le bassin manque d'appui.", 4,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Wiki-lcp.png",
            "Seedfeeder", "CC BY-SA 3.0",
            "https://commons.wikimedia.org/wiki/File:Wiki-lcp.png"
        ),
        SecretPosition(
            "Arrière à genoux", 3, "Arrière",
            "Une personne prend appui sur les mains, avant-bras ou des coussins, l'autre se place derrière. Ajustez la hauteur du bassin plutôt que de forcer le dos.", 5,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Wiki-dstyle.png",
            "Seedfeeder", "CC BY-SA 3.0",
            "https://commons.wikimedia.org/wiki/File:Wiki-dstyle.png"
        ),
        SecretPosition(
            "Arrière allongée", 2, "Arrière allongée",
            "Variante plus basse de la position arrière : la personne devant reste davantage allongée. Elle réduit l'effort des bras et peut être plus simple à maintenir longtemps.", 6,
            "https://commons.wikimedia.org/wiki/Special:FilePath/A%20tergo%20-%20doggy%20style%20-%20lying%20sex%20position.png",
            "Sciencia58", "CC0 1.0",
            "https://commons.wikimedia.org/wiki/File:A_tergo_-_doggy_style_-_lying_sex_position.png"
        ),
        SecretPosition(
            "T latéral", 3, "Perpendiculaire",
            "Une personne reste allongée pendant que l'autre se place approximativement à angle droit. Installez les jambes avant de bouger et simplifiez l'angle si une hanche tire.", 7,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Wiki-T-square.png",
            "Seedfeeder", "CC BY-SA 3.0",
            "https://commons.wikimedia.org/wiki/File:Wiki-T-square.png"
        ),
        SecretPosition(
            "Enclume / jambes relevées", 4, "Face à face avancée",
            "Variante face à face où les jambes sont davantage relevées. N'essayez pas de reproduire une amplitude maximale : utilisez uniquement l'ouverture de hanche confortable pour vous.", 8,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Wiki-Wiener-auster.png",
            "Seedfeeder", "CC BY-SA 3.0",
            "https://commons.wikimedia.org/wiki/File:Wiki-Wiener-auster.png"
        ),
        SecretPosition(
            "Debout porté", 5, "Debout avancée",
            "Une personne reste debout et soutient une partie importante du poids de l'autre. À réserver aux couples pour qui la différence de taille, la force et l'équilibre rendent réellement la position sûre.", 9,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Wiki-standing.png",
            "Seedfeeder", "CC BY-SA 3.0",
            "https://commons.wikimedia.org/wiki/File:Wiki-standing.png"
        ),
        SecretPosition(
            "Flanquette", 3, "Latérale",
            "Position latérale où les corps sont décalés. Placez d'abord le bassin et les jambes, puis utilisez un petit mouvement plutôt qu'une grande amplitude.", 10,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Flanquette%20-%20Sexposition%201.png",
            "Sciencia58", "CC0 1.0",
            "https://commons.wikimedia.org/wiki/File:Flanquette_-_Sexposition_1.png"
        ),
        SecretPosition(
            "Rocking face à face", 2, "Face à face",
            "Ici l'intérêt est surtout le mouvement de bascule et le contact continu plutôt qu'un grand va-et-vient. Cherchez une pression confortable et régulière, puis ajustez ensemble.", 11,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Vaginal%20intercourse%20-%20Rocking%201.png",
            "Sciencia58", "CC0 1.0",
            "https://commons.wikimedia.org/wiki/File:Vaginal_intercourse_-_Rocking_1.png"
        ),
        SecretPosition(
            "Assise compacte", 2, "Assise",
            "Position assise compacte, utile pour explorer un angle différent avec peu d'espace. Vérifiez surtout les appuis des pieds et du dos avant de bouger.", 12,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Sex%20position%20-%20sitting%201.png",
            "Sciencia58", "CC0 1.0",
            "https://commons.wikimedia.org/wiki/File:Sex_position_-_sitting_1.png"
        ),
        SecretPosition(
            "Assise inversée", 3, "Assise",
            "Une variante assise dans laquelle l'orientation des partenaires change. Commencez lentement pour trouver un angle de hanches confortable avant d'augmenter le mouvement.", 13,
            "https://commons.wikimedia.org/wiki/Special:FilePath/Sex%20position%20-%20sitting%202.png",
            "Sciencia58", "CC BY-SA 4.0",
            "https://commons.wikimedia.org/wiki/File:Sex_position_-_sitting_2.png"
        )
    )

    fun positionById(poseId:Int): SecretPosition? = positions.firstOrNull { it.poseId == poseId }

    fun secretPositions(): List<SecretPosition> = positions

    fun intensityWord(intensity:Int):String = when(intensity.coerceIn(1,5)){
        1 -> "très doux"
        2 -> "doux"
        3 -> "intense"
        4 -> "très intense"
        else -> "extrême"
    }

    private fun effectiveIntensity(mode: GameMode, selected: Int): Int {
        val i = selected.coerceIn(1,5)
        return if (mode == GameMode.SECRET) i.coerceAtLeast(3) else i
    }

    private fun candidates(mode: GameMode, kind: CardKind, selectedIntensity: Int): List<CuratedCard> {
        val target = effectiveIntensity(mode, selectedIntensity)
        val all = (modeCards.getValue(mode) + v12Extras[mode].orEmpty()).filter { it.kind == kind }
        if (all.isEmpty()) return emptyList()
        val close = all.filter { it.intensity in (target - 1).coerceAtLeast(1)..target }
        return if (close.isNotEmpty()) close else all.filter { it.intensity <= target }.ifEmpty { all }
    }

    fun chooseKind(mode:GameMode, round:Int, memories:List<String>):CardKind {
        val hasMemory = memories.any { it.isNotBlank() }
        if (mode == GameMode.SECRET && round % 4 == 0) return CardKind.SECRET_POSITION
        if (hasMemory && round % 7 == 0 && mode != GameMode.SECRET) return CardKind.MEMORY
        val r = Random.nextInt(100)
        return when(mode) {
            GameMode.RELAX -> when(r){ in 0..29->CardKind.CHALLENGE; in 30..54->CardKind.QUESTION; in 55..79->CardKind.SITUATION; in 80..91->CardKind.TENTATION; else->CardKind.DESTINY }
            GameMode.FUN -> when(r){ in 0..34->CardKind.CHALLENGE; in 35..54->CardKind.QUESTION; in 55..79->CardKind.SITUATION; in 80..89->CardKind.TENTATION; else->CardKind.DESTINY }
            GameMode.ROMANTIC -> when(r){ in 0..34->CardKind.CHALLENGE; in 35..62->CardKind.QUESTION; in 63..79->CardKind.SITUATION; in 80..91->CardKind.TENTATION; else->CardKind.DESTINY }
            GameMode.HOT -> when(r){ in 0..39->CardKind.CHALLENGE; in 40..59->CardKind.QUESTION; in 60..77->CardKind.SITUATION; in 78..90->CardKind.TENTATION; else->CardKind.DESTINY }
            GameMode.SECRET -> when(r){ in 0..44->CardKind.CHALLENGE; in 45..59->CardKind.QUESTION; in 60..75->CardKind.SITUATION; in 76..87->CardKind.TENTATION; in 88..95->CardKind.SECRET_POSITION; else->CardKind.DESTINY }
        }
    }

    fun challenge(mode:GameMode, intensity:Int, actionRoll:Int, zoneRoll:Int):GameCard = specialCard(CardKind.CHALLENGE, mode, intensity, emptyList())

    fun specialCard(kind:CardKind, mode:GameMode, intensity:Int, memories:List<String>):GameCard = when(kind) {
        CardKind.MEMORY -> {
            val memory = memories.filter { it.isNotBlank() }.randomOrNull() ?: "un de vos meilleurs souvenirs"
            GameCard(kind, "Souvenir de nous", memoryTemplates.random().format(memory), "Comparez vos versions : les différences rendent souvent le souvenir plus intéressant.", intensity = 1)
        }
        CardKind.SECRET_POSITION -> {
            val maxDifficulty = effectiveIntensity(GameMode.SECRET, intensity)
            val eligible = positions.filter { it.difficulty <= maxDifficulty }
            val p = eligible.random()
            GameCard(
                kind,
                "Position guidée",
                p.name,
                "${p.category} · difficulté ${p.difficulty}/5\n${p.description}\nRegardez d'abord l'illustration et vos appuis. Vous pouvez essayer, simplifier ou passer.",
                false,
                p.poseId,
                p.difficulty
            )
        }
        CardKind.DESTINY -> destinyCards.random().toGameCard()
        CardKind.CHALLENGE, CardKind.QUESTION, CardKind.SITUATION, CardKind.TENTATION -> {
            val pool = candidates(mode, kind, intensity)
            pool.random().toGameCard()
        }
    }

    private fun CuratedCard.toGameCard() = GameCard(kind, title, text, detail, canSave, -1, intensity)

    fun contentStats(): Map<String,Int> {
        val all = modeCards.values.flatten() + v12Extras.values.flatten()
        return mapOf(
            "questions" to all.count { it.kind == CardKind.QUESTION },
            "situations" to all.count { it.kind == CardKind.SITUATION },
            "challenges" to all.count { it.kind == CardKind.CHALLENGE },
            "temptations" to all.count { it.kind == CardKind.TENTATION },
            "destiny" to destinyCards.size,
            "memories" to memoryTemplates.size,
            "positions" to positions.size,
            "total_curated" to (all.size + destinyCards.size + memoryTemplates.size + positions.size)
        )
    }
}
