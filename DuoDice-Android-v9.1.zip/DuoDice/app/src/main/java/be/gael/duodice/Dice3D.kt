package be.gael.duodice

import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.MotionEvent
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

class DiceGLSurfaceView(context: Context) : GLSurfaceView(context) {
    private val diceRenderer = DiceRenderer()
    var lastRollSignal: Int = 0
    private var lastX = 0f
    private var lastY = 0f

    init {
        setEGLContextClientVersion(2)
        setRenderer(diceRenderer)
        renderMode = RENDERMODE_CONTINUOUSLY
        preserveEGLContextOnPause = true
    }

    fun setDice(sides: Int) {
        queueEvent { diceRenderer.setSides(sides) }
    }

    fun setTheme(
        accentR: Float, accentG: Float, accentB: Float,
        backgroundR: Float, backgroundG: Float, backgroundB: Float
    ) {
        queueEvent {
            diceRenderer.setTheme(
                accentR, accentG, accentB,
                backgroundR, backgroundG, backgroundB
            )
        }
    }

    fun roll(result: Int) {
        queueEvent { diceRenderer.roll(result) }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x
                lastY = event.y
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - lastX
                val dy = event.y - lastY
                lastX = event.x
                lastY = event.y
                queueEvent { diceRenderer.drag(dy * 0.32f, dx * 0.32f) }
                return true
            }
        }
        return super.onTouchEvent(event)
    }
}

private class DiceRenderer : GLSurfaceView.Renderer {
    private var program = 0
    private var mesh: DiceMesh? = null
    private val shadowMesh: DiceMesh = createShadowMesh()
    private var sides = 6

    private var angleX = 22f
    private var angleY = 28f
    private var angleZ = 4f

    private var startX = angleX
    private var startY = angleY
    private var startZ = angleZ
    private var endX = angleX
    private var endY = angleY
    private var endZ = angleZ

    private var rollStartNanos = 0L
    private var rolling = false
    private var travelStartX = 0f
    private var travelX = 0f
    private var lift = 0f
    private var impact = 0f

    private val projection = FloatArray(16)
    private val view = FloatArray(16)
    private val model = FloatArray(16)
    private val vp = FloatArray(16)
    private val mvp = FloatArray(16)

    private var aPosition = -1
    private var aNormal = -1
    private var aColor = -1
    private var uMvp = -1
    private var uModel = -1
    private var uAlpha = -1
    private var uTint = -1

    private var accentR = 0.56f
    private var accentG = 0.77f
    private var accentB = 1.00f
    private var backgroundR = 0.055f
    private var backgroundG = 0.065f
    private var backgroundB = 0.085f

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(backgroundR, backgroundG, backgroundB, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)

        program = buildProgram(VERTEX_SHADER, FRAGMENT_SHADER)
        aPosition = GLES20.glGetAttribLocation(program, "aPosition")
        aNormal = GLES20.glGetAttribLocation(program, "aNormal")
        aColor = GLES20.glGetAttribLocation(program, "aColor")
        uMvp = GLES20.glGetUniformLocation(program, "uMvp")
        uModel = GLES20.glGetUniformLocation(program, "uModel")
        uAlpha = GLES20.glGetUniformLocation(program, "uAlpha")
        uTint = GLES20.glGetUniformLocation(program, "uTint")

        mesh = DiceGeometry.create(sides)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        val ratio = if (height == 0) 1f else width.toFloat() / height.toFloat()
        Matrix.perspectiveM(projection, 0, 36f, ratio, 0.1f, 20f)
        Matrix.setLookAtM(
            view, 0,
            0f, 1.0f, 4.65f,
            0f, -0.05f, 0f,
            0f, 1f, 0f
        )
        Matrix.multiplyMM(vp, 0, projection, 0, view, 0)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClearColor(backgroundR, backgroundG, backgroundB, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        updateAnimation()
        GLES20.glUseProgram(program)

        // Soft floor shadow. It gets lighter and slightly broader while the die is airborne.
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, travelX, -1.18f, 0f)
        val shadowScale = 1f + lift * 0.12f
        Matrix.scaleM(model, 0, shadowScale, 1f, shadowScale)
        GLES20.glDepthMask(false)
        drawMesh(shadowMesh, model, (0.44f / (1f + lift * 1.8f)).coerceAtLeast(0.12f))
        GLES20.glDepthMask(true)

        val currentMesh = mesh ?: return
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, travelX, lift, 0f)

        // Very small squash on impact: enough to sell the weight, not enough to look rubbery.
        val squashY = 1f - 0.075f * impact
        val squashXZ = 1f + 0.0375f * impact
        Matrix.scaleM(model, 0, squashXZ, squashY, squashXZ)

        Matrix.rotateM(model, 0, angleX, 1f, 0f, 0f)
        Matrix.rotateM(model, 0, angleY, 0f, 1f, 0f)
        Matrix.rotateM(model, 0, angleZ, 0f, 0f, 1f)

        drawMesh(currentMesh, model, 1f)
    }

    fun setSides(newSides: Int) {
        if (newSides == sides) return
        sides = newSides
        mesh = DiceGeometry.create(sides)
    }

    fun setTheme(
        ar: Float, ag: Float, ab: Float,
        br: Float, bg: Float, bb: Float
    ) {
        accentR = ar
        accentG = ag
        accentB = ab
        backgroundR = br
        backgroundG = bg
        backgroundB = bb
    }

    fun roll(result: Int) {
        startX = angleX
        startY = angleY
        startZ = angleZ

        val seed = result * 97 + sides * 31
        travelStartX = if (seed % 2 == 0) -0.62f else 0.62f
        travelX = travelStartX

        endX = startX + 1080f + (seed % 137)
        endY = startY + 1260f + ((seed * 5) % 181)
        endZ = startZ + 900f + ((seed * 11) % 149)

        rollStartNanos = System.nanoTime()
        rolling = true
    }

    fun drag(dx: Float, dy: Float) {
        if (rolling) return
        angleX += dx
        angleY += dy
    }

    private fun updateAnimation() {
        if (!rolling) {
            travelX = 0f
            lift = 0f
            impact = 0f
            return
        }

        val elapsed = (System.nanoTime() - rollStartNanos) / 1_000_000_000f
        val duration = 1.90f
        val t = (elapsed / duration).coerceIn(0f, 1f)

        // Fast initial rotation with a long, weighted deceleration.
        val spinEase = 1f - (1f - t).pow(4)
        val settleT = ((t - 0.68f) / 0.32f).coerceIn(0f, 1f)
        val settleWobble = if (t > 0.68f) {
            sin(settleT * PI.toFloat() * 3.0f) * (1f - settleT) * 6.0f
        } else 0f

        angleX = lerp(startX, endX, spinEase) + settleWobble
        angleY = lerp(startY, endY, spinEase) - settleWobble * 0.72f
        angleZ = lerp(startZ, endZ, spinEase) + settleWobble * 0.38f

        // Small horizontal travel into the center so it looks thrown rather than spun in place.
        travelX = travelStartX * (1f - t).pow(2) +
            sin(t * PI.toFloat() * 2.6f) * 0.09f * (1f - t)

        // One main airborne arc followed by three quickly damped bounces.
        lift = if (t < 0.48f) {
            val p = t / 0.48f
            0.88f * 4f * p * (1f - p)
        } else {
            val u = ((t - 0.48f) / 0.52f).coerceIn(0f, 1f)
            abs(sin(u * PI.toFloat() * 3f)) * 0.22f * (1f - u).pow(1.65f)
        }

        // Impact pulses drive a subtle squash/stretch.
        impact = min(
            1f,
            gaussian(t, 0.48f, 0.027f) +
                gaussian(t, 0.65f, 0.024f) * 0.68f +
                gaussian(t, 0.82f, 0.022f) * 0.42f
        )

        if (t >= 1f) {
            angleX %= 360f
            angleY %= 360f
            angleZ %= 360f
            travelX = 0f
            lift = 0f
            impact = 0f
            rolling = false
        }
    }

    private fun gaussian(x: Float, center: Float, width: Float): Float {
        val q = (x - center) / width
        return exp((-q * q).toDouble()).toFloat()
    }

    private fun drawMesh(target: DiceMesh, modelMatrix: FloatArray, alpha: Float) {
        Matrix.multiplyMM(mvp, 0, vp, 0, modelMatrix, 0)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(uModel, 1, false, modelMatrix, 0)
        GLES20.glUniform1f(uAlpha, alpha)
        GLES20.glUniform3f(uTint, accentR, accentG, accentB)

        target.positionBuffer.position(0)
        GLES20.glEnableVertexAttribArray(aPosition)
        GLES20.glVertexAttribPointer(aPosition, 3, GLES20.GL_FLOAT, false, 0, target.positionBuffer)

        target.normalBuffer.position(0)
        GLES20.glEnableVertexAttribArray(aNormal)
        GLES20.glVertexAttribPointer(aNormal, 3, GLES20.GL_FLOAT, false, 0, target.normalBuffer)

        target.colorBuffer.position(0)
        GLES20.glEnableVertexAttribArray(aColor)
        GLES20.glVertexAttribPointer(aColor, 4, GLES20.GL_FLOAT, false, 0, target.colorBuffer)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, target.vertexCount)

        GLES20.glDisableVertexAttribArray(aPosition)
        GLES20.glDisableVertexAttribArray(aNormal)
        GLES20.glDisableVertexAttribArray(aColor)
    }

    private fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t

    private fun buildProgram(vertexSource: String, fragmentSource: String): Int {
        val vertex = compileShader(GLES20.GL_VERTEX_SHADER, vertexSource)
        val fragment = compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentSource)
        return GLES20.glCreateProgram().also { p ->
            GLES20.glAttachShader(p, vertex)
            GLES20.glAttachShader(p, fragment)
            GLES20.glLinkProgram(p)
        }
    }

    private fun compileShader(type: Int, source: String): Int {
        return GLES20.glCreateShader(type).also { shader ->
            GLES20.glShaderSource(shader, source)
            GLES20.glCompileShader(shader)
        }
    }

    companion object {
        private const val VERTEX_SHADER = """
            uniform mat4 uMvp;
            uniform mat4 uModel;
            uniform float uAlpha;
            attribute vec3 aPosition;
            attribute vec3 aNormal;
            attribute vec4 aColor;
            varying vec3 vNormal;
            varying vec4 vColor;
            varying float vAlpha;
            void main() {
                gl_Position = uMvp * vec4(aPosition, 1.0);
                vNormal = normalize((uModel * vec4(aNormal, 0.0)).xyz);
                vColor = aColor;
                vAlpha = uAlpha;
            }
        """

        private const val FRAGMENT_SHADER = """
            precision mediump float;
            uniform vec3 uTint;
            varying vec3 vNormal;
            varying vec4 vColor;
            varying float vAlpha;
            void main() {
                vec3 n = normalize(vNormal);
                vec3 lightDir = normalize(vec3(0.42, 0.86, 0.72));
                vec3 viewDir = normalize(vec3(0.0, 0.20, 1.0));
                vec3 halfDir = normalize(lightDir + viewDir);

                float diffuse = max(dot(n, lightDir), 0.0);
                float specular = pow(max(dot(n, halfDir), 0.0), 24.0);
                float rim = pow(1.0 - max(dot(n, viewDir), 0.0), 2.4);

                vec3 base = mix(vColor.rgb, vColor.rgb * uTint * 1.35, 0.72);
                vec3 lit = base * (0.30 + 0.70 * diffuse)
                         + vec3(0.38) * specular
                         + base * rim * 0.14;

                gl_FragColor = vec4(lit, vColor.a * vAlpha);
            }
        """
    }
}

private fun createShadowMesh(): DiceMesh {
    val segments = 48
    val positions = mutableListOf<Float>()
    val normals = mutableListOf<Float>()
    val colors = mutableListOf<Float>()

    fun addVertex(x: Float, y: Float, z: Float, alpha: Float) {
        positions += x; positions += y; positions += z
        normals += 0f; normals += 1f; normals += 0f
        colors += 0f; colors += 0f; colors += 0f; colors += alpha
    }

    for (i in 0 until segments) {
        val a0 = (2.0 * PI * i / segments).toFloat()
        val a1 = (2.0 * PI * (i + 1) / segments).toFloat()
        addVertex(0f, 0f, 0f, 0.55f)
        addVertex(cos(a0.toDouble()).toFloat() * 0.92f, 0f, sin(a0.toDouble()).toFloat() * 0.64f, 0f)
        addVertex(cos(a1.toDouble()).toFloat() * 0.92f, 0f, sin(a1.toDouble()).toFloat() * 0.64f, 0f)
    }

    return DiceMesh(
        positionBuffer = makeFloatBuffer(positions),
        normalBuffer = makeFloatBuffer(normals),
        colorBuffer = makeFloatBuffer(colors),
        vertexCount = positions.size / 3
    )
}

private fun makeFloatBuffer(values: List<Float>): FloatBuffer {
    val buffer = ByteBuffer.allocateDirect(values.size * 4)
        .order(ByteOrder.nativeOrder())
        .asFloatBuffer()
    values.forEach { buffer.put(it) }
    buffer.position(0)
    return buffer
}

private data class DiceMesh(
    val positionBuffer: FloatBuffer,
    val normalBuffer: FloatBuffer,
    val colorBuffer: FloatBuffer,
    val vertexCount: Int
)

private data class V3(val x: Float, val y: Float, val z: Float) {
    operator fun plus(o: V3) = V3(x + o.x, y + o.y, z + o.z)
    operator fun minus(o: V3) = V3(x - o.x, y - o.y, z - o.z)
    operator fun times(s: Float) = V3(x * s, y * s, z * s)
    operator fun div(s: Float) = V3(x / s, y / s, z / s)
    fun dot(o: V3) = x * o.x + y * o.y + z * o.z
    fun cross(o: V3) = V3(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x)
    fun length() = sqrt(dot(this))
    fun normalized(): V3 {
        val len = length()
        return if (len < 1e-7f) V3(0f, 0f, 1f) else this / len
    }
}

private object DiceGeometry {
    private const val EPS = 1e-4f

    private val palette = arrayOf(
        floatArrayOf(0.24f, 0.56f, 0.92f, 1f),
        floatArrayOf(0.93f, 0.45f, 0.27f, 1f),
        floatArrayOf(0.36f, 0.75f, 0.60f, 1f),
        floatArrayOf(0.67f, 0.46f, 0.89f, 1f),
        floatArrayOf(0.94f, 0.70f, 0.25f, 1f),
        floatArrayOf(0.28f, 0.74f, 0.83f, 1f)
    )

    fun create(sides: Int): DiceMesh {
        val vertices = when (sides) {
            4 -> d4()
            6 -> d6()
            8 -> d8()
            10 -> d10()
            12 -> d12()
            20 -> d20()
            else -> d6()
        }

        val normalized = normalizeRadius(vertices, 1.18f)
        val faces = convexFaces(normalized)
        val positions = mutableListOf<Float>()
        val normals = mutableListOf<Float>()
        val colors = mutableListOf<Float>()

        faces.forEachIndexed { faceIndex, face ->
            val ordered = orderFace(normalized, face)
            if (ordered.size < 3) return@forEachIndexed
            val p0 = normalized[ordered[0]]
            val p1 = normalized[ordered[1]]
            val p2 = normalized[ordered[2]]
            var normal = (p1 - p0).cross(p2 - p0).normalized()
            val centroid = ordered.map { normalized[it] }.reduce { a, b -> a + b } / ordered.size.toFloat()
            if (normal.dot(centroid) < 0f) normal = normal * -1f
            val color = palette[faceIndex % palette.size]

            for (i in 1 until ordered.size - 1) {
                val tri = listOf(ordered[0], ordered[i], ordered[i + 1])
                tri.forEach { index ->
                    val p = normalized[index]
                    positions += p.x; positions += p.y; positions += p.z
                    normals += normal.x; normals += normal.y; normals += normal.z
                    colors += color[0]; colors += color[1]; colors += color[2]; colors += color[3]
                }
            }
        }

        return DiceMesh(
            positionBuffer = floatBuffer(positions),
            normalBuffer = floatBuffer(normals),
            colorBuffer = floatBuffer(colors),
            vertexCount = positions.size / 3
        )
    }

    private fun d4() = listOf(
        V3(1f, 1f, 1f), V3(-1f, -1f, 1f), V3(-1f, 1f, -1f), V3(1f, -1f, -1f)
    )

    private fun d6(): List<V3> {
        val out = mutableListOf<V3>()
        for (x in listOf(-1f, 1f)) for (y in listOf(-1f, 1f)) for (z in listOf(-1f, 1f)) {
            out += V3(x, y, z)
        }
        return out
    }

    private fun d8() = listOf(
        V3(1f, 0f, 0f), V3(-1f, 0f, 0f), V3(0f, 1f, 0f),
        V3(0f, -1f, 0f), V3(0f, 0f, 1f), V3(0f, 0f, -1f)
    )

    private fun d10(): List<V3> {
        val n = 5
        val radius = 1f
        val h = 0.65f
        val top = (0 until n).map { i ->
            val a = (2.0 * PI * i / n).toFloat()
            V3(radius * cos(a.toDouble()).toFloat(), radius * sin(a.toDouble()).toFloat(), h)
        }
        val bottom = (0 until n).map { i ->
            val a = (2.0 * PI * i / n + PI / n).toFloat()
            V3(radius * cos(a.toDouble()).toFloat(), radius * sin(a.toDouble()).toFloat(), -h)
        }
        val source = top + bottom
        val sourceFaces = mutableListOf<List<Int>>()
        sourceFaces += listOf(0, 1, 2, 3, 4)
        sourceFaces += listOf(9, 8, 7, 6, 5)
        for (i in 0 until n) {
            val next = (i + 1) % n
            sourceFaces += listOf(i, 5 + i, next)
            sourceFaces += listOf(next, 5 + i, 5 + next)
        }

        return sourceFaces.map { face ->
            val a = source[face[0]]
            val b = source[face[1]]
            val c = source[face[2]]
            var normal = (b - a).cross(c - a).normalized()
            val centroid = face.map { source[it] }.reduce { p, q -> p + q } / face.size.toFloat()
            if (normal.dot(centroid) < 0f) normal = normal * -1f
            val d = max(0.0001f, normal.dot(a))
            normal / d
        }
    }

    private fun d12(): List<V3> {
        val phi = ((1.0 + sqrt(5.0)) / 2.0).toFloat()
        val inv = 1f / phi
        val out = mutableListOf<V3>()
        for (x in listOf(-1f, 1f)) for (y in listOf(-1f, 1f)) for (z in listOf(-1f, 1f)) out += V3(x, y, z)
        for (y in listOf(-inv, inv)) for (z in listOf(-phi, phi)) out += V3(0f, y, z)
        for (x in listOf(-inv, inv)) for (y in listOf(-phi, phi)) out += V3(x, y, 0f)
        for (x in listOf(-phi, phi)) for (z in listOf(-inv, inv)) out += V3(x, 0f, z)
        return out
    }

    private fun d20(): List<V3> {
        val phi = ((1.0 + sqrt(5.0)) / 2.0).toFloat()
        val out = mutableListOf<V3>()
        for (y in listOf(-1f, 1f)) for (z in listOf(-phi, phi)) out += V3(0f, y, z)
        for (x in listOf(-1f, 1f)) for (y in listOf(-phi, phi)) out += V3(x, y, 0f)
        for (x in listOf(-phi, phi)) for (z in listOf(-1f, 1f)) out += V3(x, 0f, z)
        return out
    }

    private fun normalizeRadius(points: List<V3>, radius: Float): List<V3> {
        val maxLen = points.maxOf { it.length() }
        val scale = radius / maxLen
        return points.map { it * scale }
    }

    private fun convexFaces(points: List<V3>): List<List<Int>> {
        val found = linkedMapOf<String, List<Int>>()
        val n = points.size
        for (i in 0 until n - 2) {
            for (j in i + 1 until n - 1) {
                for (k in j + 1 until n) {
                    val a = points[i]
                    val normalRaw = (points[j] - a).cross(points[k] - a)
                    if (normalRaw.length() < EPS) continue
                    val normal = normalRaw.normalized()
                    var positive = false
                    var negative = false
                    val coplanar = mutableListOf<Int>()

                    for (p in points.indices) {
                        val d = (points[p] - a).dot(normal)
                        if (d > EPS) positive = true
                        else if (d < -EPS) negative = true
                        else coplanar += p
                        if (positive && negative) break
                    }

                    if (!(positive && negative) && coplanar.size >= 3) {
                        val sorted = coplanar.sorted()
                        found[sorted.joinToString(",")] = sorted
                    }
                }
            }
        }
        return found.values.toList()
    }

    private fun orderFace(points: List<V3>, face: List<Int>): List<Int> {
        val centroid = face.map { points[it] }.reduce { a, b -> a + b } / face.size.toFloat()
        val p0 = points[face[0]]
        val p1 = points[face[1]]
        val p2 = points[face[2]]
        var normal = (p1 - p0).cross(p2 - p0).normalized()
        if (normal.dot(centroid) < 0f) normal = normal * -1f

        var u = (points[face[0]] - centroid).normalized()
        if (u.length() < EPS) u = V3(1f, 0f, 0f)
        val v = normal.cross(u).normalized()

        val ordered = face.sortedBy { idx ->
            val r = points[idx] - centroid
            atan2(r.dot(v).toDouble(), r.dot(u).toDouble())
        }.toMutableList()

        if (ordered.size >= 3) {
            val a = points[ordered[0]]
            val b = points[ordered[1]]
            val c = points[ordered[2]]
            if ((b - a).cross(c - a).dot(normal) < 0f) ordered.reverse()
        }
        return ordered
    }

    private fun floatBuffer(values: List<Float>): FloatBuffer {
        val buffer = ByteBuffer.allocateDirect(values.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
        values.forEach { buffer.put(it) }
        buffer.position(0)
        return buffer
    }
}
