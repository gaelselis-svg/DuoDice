# DuoDice v13 — Wikimedia assets

All position illustrations are fetched from Wikimedia Commons during the GitHub build and embedded in the APK.

## Modern instructional illustrations
- `Wiki-missionary.png` — Seedfeeder — CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Wiki-missionary.png
- `Vaginal intercourse - Rocking 1.png` — Sciencia58 — CC0 1.0 — https://commons.wikimedia.org/wiki/File:Vaginal_intercourse_-_Rocking_1.png
- `Wiki-Wiener-auster.png` — Seedfeeder — CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Wiki-Wiener-auster.png
- `Wiki-cowgirl.png` — Seedfeeder — CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Wiki-cowgirl.png
- `Sex position - sitting 1.png` — Sciencia58 — CC0 1.0 — https://commons.wikimedia.org/wiki/File:Sex_position_-_sitting_1.png
- `Sex position - sitting 2.png` — Sciencia58 — CC BY-SA 4.0 — https://commons.wikimedia.org/wiki/File:Sex_position_-_sitting_2.png
- `Wiki-sitting-sp.png` — Seedfeeder — CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Wiki-sitting-sp.png
- `Wiki-spoons-sp.png` — Seedfeeder — CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Wiki-spoons-sp.png
- `Wiki-T-square.png` — Seedfeeder — CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Wiki-T-square.png
- `Flanquette - Sexposition 1.png` — Sciencia58 — CC0 1.0 — https://commons.wikimedia.org/wiki/File:Flanquette_-_Sexposition_1.png
- `Wiki-lcp.png` — Seedfeeder — CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Wiki-lcp.png
- `Wiki-dstyle.png` — Seedfeeder — CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Wiki-dstyle.png
- `A tergo - doggy style - lying sex position.png` — Sciencia58 — CC0 1.0 — https://commons.wikimedia.org/wiki/File:A_tergo_-_doggy_style_-_lying_sex_position.png
- `Wiki-standing.png` — Seedfeeder — CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Wiki-standing.png

## Historical Kama Sutra illustrations
Positions without a modern instructional diagram use a distinct historical Kama Sutra plate from `KamaSutra02.jpg` through `KamaSutra37.jpg`. These files are listed on Wikimedia Commons as faithful reproductions of public-domain works (PD-Art).

- `KamaSutra02.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra02.jpg
- `KamaSutra03.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra03.jpg
- `KamaSutra04.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra04.jpg
- `KamaSutra05.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra05.jpg
- `KamaSutra06.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra06.jpg
- `KamaSutra07.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra07.jpg
- `KamaSutra08.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra08.jpg
- `KamaSutra09.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra09.jpg
- `KamaSutra10.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra10.jpg
- `KamaSutra11.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra11.jpg
- `KamaSutra12.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra12.jpg
- `KamaSutra13.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra13.jpg
- `KamaSutra14.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra14.jpg
- `KamaSutra15.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra15.jpg
- `KamaSutra16.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra16.jpg
- `KamaSutra17.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra17.jpg
- `KamaSutra18.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra18.jpg
- `KamaSutra19.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra19.jpg
- `KamaSutra20.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra20.jpg
- `KamaSutra21.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra21.jpg
- `KamaSutra22.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra22.jpg
- `KamaSutra23.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra23.jpg
- `KamaSutra24.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra24.jpg
- `KamaSutra25.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra25.jpg
- `KamaSutra26.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra26.jpg
- `KamaSutra27.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra27.jpg
- `KamaSutra28.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra28.jpg
- `KamaSutra29.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra29.jpg
- `KamaSutra30.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra30.jpg
- `KamaSutra31.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra31.jpg
- `KamaSutra32.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra32.jpg
- `KamaSutra33.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra33.jpg
- `KamaSutra34.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra34.jpg
- `KamaSutra35.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra35.jpg
- `KamaSutra36.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra36.jpg
- `KamaSutra37.jpg` — unknown 19th-century author — public domain / PD-Art — https://commons.wikimedia.org/wiki/File:KamaSutra37.jpg
