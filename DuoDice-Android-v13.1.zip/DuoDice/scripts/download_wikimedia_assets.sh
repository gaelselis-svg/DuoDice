#!/usr/bin/env bash
set -euo pipefail
OUT="app/src/main/res/drawable-nodpi"
mkdir -p "$OUT"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
UA='DuoDice/7.0 Android app (licensed Wikimedia asset fetch for build)'

python3 -m pip install --quiet pillow

cat > "$TMP/assets.tsv" <<'EOF'
00	Wiki-missionary.png
01	KamaSutra02.jpg
02	KamaSutra03.jpg
03	Vaginal intercourse - Rocking 1.png
04	KamaSutra04.jpg
05	Wiki-Wiener-auster.png
06	KamaSutra05.jpg
07	KamaSutra06.jpg
08	Wiki-cowgirl.png
09	KamaSutra07.jpg
10	KamaSutra08.jpg
11	KamaSutra09.jpg
12	KamaSutra10.jpg
13	KamaSutra11.jpg
14	Sex position - sitting 1.png
15	Sex position - sitting 2.png
16	Wiki-sitting-sp.png
17	KamaSutra12.jpg
18	KamaSutra13.jpg
19	KamaSutra14.jpg
20	KamaSutra15.jpg
21	KamaSutra16.jpg
22	KamaSutra17.jpg
23	KamaSutra18.jpg
24	Wiki-spoons-sp.png
25	KamaSutra19.jpg
26	KamaSutra20.jpg
27	Wiki-T-square.png
28	Flanquette - Sexposition 1.png
29	KamaSutra21.jpg
30	KamaSutra22.jpg
31	Wiki-lcp.png
32	Wiki-dstyle.png
33	KamaSutra23.jpg
34	A tergo - doggy style - lying sex position.png
35	KamaSutra24.jpg
36	KamaSutra25.jpg
37	KamaSutra26.jpg
38	KamaSutra27.jpg
39	KamaSutra28.jpg
40	Wiki-standing.png
41	KamaSutra29.jpg
42	KamaSutra30.jpg
43	KamaSutra31.jpg
44	KamaSutra32.jpg
45	KamaSutra33.jpg
46	KamaSutra34.jpg
47	KamaSutra35.jpg
48	KamaSutra36.jpg
49	KamaSutra37.jpg
EOF

while IFS=$'\t' read -r idx filename; do
  echo "Downloading position_$idx: $filename"
  encoded=$(python3 - "$filename" <<'PY2'
import sys, urllib.parse
print(urllib.parse.quote(sys.argv[1], safe=''))
PY2
)
  curl --fail --location --silent --show-error \
       --retry 4 --retry-delay 2 --connect-timeout 20 --max-time 120 \
       --user-agent "$UA" \
       "https://commons.wikimedia.org/wiki/Special:Redirect/file/$encoded" \
       -o "$TMP/raw_$idx"
  test -s "$TMP/raw_$idx"
  python3 - "$TMP/raw_$idx" "$OUT/position_$idx.webp" <<'PY3'
import sys
from PIL import Image, ImageOps
src,dst=sys.argv[1:3]
with Image.open(src) as im:
    im=ImageOps.exif_transpose(im)
    if im.mode in ('RGBA','LA') or ('transparency' in im.info):
        bg=Image.new('RGBA',im.size,'white'); bg.alpha_composite(im.convert('RGBA')); im=bg.convert('RGB')
    else:
        im=im.convert('RGB')
    im.thumbnail((900,900), Image.Resampling.LANCZOS)
    im.save(dst,'WEBP',quality=84,method=6)
PY3
  test -s "$OUT/position_$idx.webp"
done < "$TMP/assets.tsv"

echo "Embedded $(find "$OUT" -name 'position_*.webp' -type f | wc -l) Wikimedia illustrations."
