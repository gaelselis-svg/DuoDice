# DuoDice v13 — Extreme + Kamasutra 50

## Contenu
- 48 cartes Détente
- 48 cartes Fun
- 48 cartes Romantique
- 48 cartes Hot
- 48 cartes Secret
- 50 cartes Extrême, écrites manuellement
- 50 positions Kamasutra avec 50 illustrations Wikimedia distinctes
- Mode classique de dés conservé
- Espace privé PIN : Secret puis Extrême

## Principes
- Pas de génération action + zone aléatoire.
- Cartes Action/Vérité complètes et directes.
- Extrême : vocabulaire sexuel cru mais limites et arrêt toujours possibles.
- Les images sont téléchargées au build, redimensionnées en WebP puis embarquées dans l’APK.

Voir `THIRD_PARTY_ASSETS.md` pour les crédits et licences.
